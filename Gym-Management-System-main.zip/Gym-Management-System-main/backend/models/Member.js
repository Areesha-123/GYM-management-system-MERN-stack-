import mongoose from 'mongoose';

const historyEntrySchema = new mongoose.Schema({
    date: { type: String, required: true },
    event: { type: String, required: true },
    details: { type: String, default: '' },
    amountPaid: { type: Number },
    planId: { type: String, default: null },
    planName: { type: String, default: null },
}, { _id: true, timestamps: { createdAt: 'entryCreatedAt', updatedAt: false } });

const memberSchema = new mongoose.Schema({
    name: {
        type: String,
        required: [true, 'Member name is required.'],
        trim: true,
    },
    displayMemberId: {
        type: Number,
        required: true,
    },
    email: {
        type: String,
        trim: true,
        lowercase: true,
    },
    phone: {
        type: String,
        required: [true, 'Member phone number is required.'],
        trim: true,
    },
    gender: {
        type: String,
        enum: ['Male', 'Female', 'Other'],
        default: 'Male',
    },
    dob: {
        type: String,
    },
    joiningDate: {
        type: String,
        required: [true, 'Joining date is required.'],
    },
    currentPlanId: {
        type: String,
        required: [true, 'Current subscription plan ID is required.'],
    },
    endDate: {
        type: String,
        required: true,
    },
    paymentDueDate: {
        type: String,
        required: true,
    },
    status: {
        type: String,
        enum: ['Active', 'Inactive', 'Expired', 'Frozen'],
        default: 'Active',
    },
    history: [historyEntrySchema],
    lastPaymentDate: {
        type: String,
    },
    trainerId: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Trainer',
        default: null,
    },
    trainerName: {
        type: String,
        default: null,
    },
    goal: {
        type: String,
        trim: true,
        default: null,
    },
    branchId: {
        type: mongoose.Schema.Types.ObjectId,
        required: true,
        ref: 'Branch',
    },
    gymOwner: {
        type: mongoose.Schema.Types.ObjectId,
        required: true,
        ref: 'GymRegistrationInfo',
    },
}, {
    timestamps: true,
});

memberSchema.index({ branchId: 1, gymOwner: 1 });
memberSchema.index({ branchId: 1, displayMemberId: 1 }, { unique: true });
memberSchema.index({ name: 'text', email: 'text', phone: 'text' });

memberSchema.index({ email: 1, gymOwner: 1 }, { unique: true, partialFilterExpression: { email: { $type: "string" } } });

const Member = mongoose.model('Member', memberSchema);

export default Member;
