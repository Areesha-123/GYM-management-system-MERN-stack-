import mongoose from 'mongoose';

const paymentSchema = new mongoose.Schema(
    {
        gymOwner: {
            type: mongoose.Schema.Types.ObjectId,
            required: true,
            ref: 'User',
        },
        branchId: {
            type: mongoose.Schema.Types.ObjectId,
            required: true,
            ref: 'Branch',
        },
        memberId: {
            type: mongoose.Schema.Types.ObjectId,
            ref: 'Member',
            default: null,
        },
        trainerId: {
            type: mongoose.Schema.Types.ObjectId,
            ref: 'Trainer',
            default: null,
        },
        amount: {
            type: Number,
            required: true,
        },
        paymentDate: {
            type: String,
            required: true,
            match: [/^\d{4}-\d{2}-\d{2}$/, 'Please use YYYY-MM-DD format for paymentDate.'],
        },
        paymentMonth: {
            type: String,
            required: function() { return this.paymentType === 'TrainerSalary'; },
            match: [/^\d{4}-\d{2}$/, 'Please use YYYY-MM format for paymentMonth.'],
        },
        paymentType: {
            type: String,
            required: true,
            enum: ['MemberSubscription', 'TrainerSalary', 'OtherFee', 'ProductSale'],
        },
        planId: {
            type: String,
            default: null,
        },
        planName: {
            type: String,
            default: null,
        },
        notes: {
            type: String,
            trim: true,
        },
        recordedBy: {
            type: mongoose.Schema.Types.ObjectId,
            ref: 'User',
        },
    },
    {
        timestamps: true,
    }
);

paymentSchema.index({ gymOwner: 1, branchId: 1 });
paymentSchema.index({ memberId: 1 });
paymentSchema.index({ trainerId: 1 });
paymentSchema.index({ paymentDate: -1 });
paymentSchema.index({ paymentMonth: 1, paymentType: 1 });

paymentSchema.pre('save', function (next) {
    if ((this.paymentType === 'MemberSubscription' && !this.memberId) ||
        (this.paymentType === 'TrainerSalary' && !this.trainerId)) {
        if (this.paymentType === 'MemberSubscription') {
            next(new Error('Member ID is required for member subscription payments.'));
        } else if (this.paymentType === 'TrainerSalary') {
             next(new Error('Trainer ID is required for trainer salary payments.'));
        }
    }
    if (this.memberId && this.trainerId) {
        next(new Error('A payment cannot be linked to both a member and a trainer simultaneously.'));
    }
    next();
});

const Payment = mongoose.model('Payment', paymentSchema);

export default Payment;
