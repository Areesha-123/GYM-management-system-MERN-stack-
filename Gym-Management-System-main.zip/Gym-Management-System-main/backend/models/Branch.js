import mongoose from 'mongoose';

const branchSchema = new mongoose.Schema({
  name: {
    type: String,
    required: [true, 'Branch name is required.'],
    trim: true,
  },
  gymOwner: {
    type: mongoose.Schema.Types.ObjectId,
    required: true,
    ref: 'GymRegistrationInfo',
  },
}, {
  timestamps: true,
});

const Branch = mongoose.model('Branch', branchSchema);

export default Branch;
