import mongoose from 'mongoose';

const scheduledClassSchema = new mongoose.Schema({
  title: {
    type: String,
    required: [true, 'Class title is required.'],
    trim: true,
  },
  description: {
    type: String,
    required: [true, 'Class description is required.'],
    trim: true,
  },
  date: {
    type: String,
    required: [true, 'Class date is required.'],
  },
  time: {
    type: String,
    required: [true, 'Class time is required.'],
  },
  imageUrl: {
    type: String,
    trim: true,
    default: null,
  },
  status: {
    type: String,
    enum: ['upcoming', 'completed', 'cancelled'],
    default: 'upcoming',
  },
  branchId: {
    type: mongoose.Schema.Types.ObjectId,
    required: true,
    ref: 'Branch',
  },
  gymOwner: {
    type: mongoose.Schema.Types.ObjectId,
    required: true,
    ref: 'GymRegistrationInfo',
  },
}, {
  timestamps: true,
});

scheduledClassSchema.index({ branchId: 1, date: 1, time: 1 });
scheduledClassSchema.index({ gymOwner: 1, date: 1 });
scheduledClassSchema.index({ status: 1 });

const ScheduledClass = mongoose.model('ScheduledClass', scheduledClassSchema);

export default ScheduledClass;
