import mongoose from 'mongoose';

const historyEventSchema = new mongoose.Schema({
    date: {
        type: String,
        required: true,
    },
    event: {
        type: String,
        required: true,
        enum: ['Joined', 'Salary Paid', 'Profile Updated', 'Status Changed', 'Left', 'Rejoined', 'Warning Issued', 'Promotion', 'Other', 'Assigned to Member', 'Unassigned from Member', 'Trainer Unassigned'],
    },
    details: {
        type: String,
        trim: true,
    },
    amount: {
        type: Number,
    },
    memberId: { type: String },
    memberName: { type: String },
}, { _id: true });

const trainerSchema = new mongoose.Schema({
    gymOwner: {
        type: mongoose.Schema.Types.ObjectId,
        required: [true, "Gym Owner ID is required."],
        ref: 'GymRegistrationInfo',
    },
    branchId: {
        type: mongoose.Schema.Types.ObjectId,
        required: [true, "Branch ID is required."],
        ref: 'Branch',
    },
    name: {
        type: String,
        required: [true, "Trainer's name is required."],
        trim: true,
    },
    email: {
        type: String,
        required: [true, "Trainer's email is required."],
        trim: true,
        lowercase: true,
        match: [/\S+@\S+\.\S+/, 'Please use a valid email address.'],
    },
    phone: {
        type: String,
        trim: true,
    },
    specialization: {
        type: String,
        required: [true, "Trainer's specialization is required."],
        trim: true,
    },
    address: {
        street: { type: String, trim: true },
        city: { type: String, trim: true },
        state: { type: String, trim: true },
        zipCode: { type: String, trim: true },
    },
    cnic: {
        type: String,
        trim: true,
    },
    dateOfJoining: {
        type: String,
        required: [true, "Date of joining is required."],
    },
    salary: {
        type: Number,
        required: [true, "Trainer's salary is required."],
        min: [0, "Salary cannot be negative."],
    },
    fee: {
        type: Number,
        min: [0, "Fee cannot be negative."],
        default: 0,
    },
    status: {
        type: String,
        enum: ['Active', 'Inactive', 'On Leave', 'Terminated'],
        default: 'Active',
        required: true,
    },
    profileImage: {
        type: String,
        trim: true,
        default: '',
    },
    notes: {
        type: String,
        trim: true,
    },
    emergencyContact: {
        name: { type: String, trim: true },
        phone: { type: String, trim: true },
        relation: { type: String, trim: true },
    },
    history: [historyEventSchema],
}, {
    timestamps: true,
});

trainerSchema.index({ gymOwner: 1, branchId: 1, email: 1 }, { unique: true, partialFilterExpression: { email: { $type: "string" } } });
trainerSchema.index({ gymOwner: 1, branchId: 1, cnic: 1 }, { unique: true, partialFilterExpression: { cnic: { $type: "string" } } });
trainerSchema.index({ branchId: 1 });
trainerSchema.index({ gymOwner: 1, status: 1 });
trainerSchema.index({ name: 'text', specialization: 'text' });

trainerSchema.pre('save', function(next) {
    if (this.isModified('email') && this.email) {
        this.email = this.email.toLowerCase();
    }
    next();
});

const Trainer = mongoose.model('Trainer', trainerSchema);

export default Trainer;
