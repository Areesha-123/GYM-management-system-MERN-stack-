import mongoose from 'mongoose';
import bcrypt from 'bcryptjs';

const gymRegistrationSchema = new mongoose.Schema({
  ownerName: {
    type: String,
    required: [true, 'The name of the gym owner is required.'],
    trim: true,
  },
  gymName: {
    type: String,
    required: [true, 'The name of the gym is required.'],
    trim: true,
  },
  branchName: {
    type: String,
    required: [true, 'The branch name or location is required.'],
    trim: true,
  },
  email: {
    type: String,
    required: [true, 'An email address is required.'],
    unique: true,
    lowercase: true,
    match: [
      /^\w+([.-]?\w+)*@\w+([.-]?\w+)*(\.\w{2,3})+$/,
      'Please enter a valid email address.',
    ],
  },
  password: {
    type: String,
    required: [true, 'A password is required.'],
    minlength: [6, 'Password should be at least 6 characters long.'],
  },
}, {
  timestamps: true,
});

gymRegistrationSchema.pre('save', async function (next) {
  if (!this.isModified('password')) {
    return next();
  }

  const salt = await bcrypt.genSalt(10);
  this.password = await bcrypt.hash(this.password, salt);
  next();
});

gymRegistrationSchema.methods.matchPassword = async function (enteredPassword) {
  return await bcrypt.compare(enteredPassword, this.password);
};

const GymRegistrationInfo = mongoose.model('GymRegistrationInfo', gymRegistrationSchema);

export default GymRegistrationInfo;
