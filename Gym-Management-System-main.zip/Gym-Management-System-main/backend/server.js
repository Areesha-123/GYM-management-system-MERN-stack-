// This file sets up and starts the backend server for the Gym System.

// Import necessary libraries and modules
import express from 'express'; // Framework for building web applications
import dotenv from 'dotenv'; // To load environment variables from a .env file
import cors from 'cors'; // Middleware to enable Cross-Origin Resource Sharing
import connectDB from './config/db.js'; // Function to connect to the database
import path from 'path'; // Module to work with file and directory paths
import { fileURLToPath } from 'url'; // Helper to get file path in ES modules

// Import the route files for different parts of the API
import gymRegistrationRoutes from './routes/gymRegistrationAPI.js';
import gymDetailsRoutes from './routes/gymDetailsAPI.js';
import branchRoutes from './routes/branchRoutes.js';
import memberRoutes from './routes/memberRoutes.js';
import trainerRoutes from './routes/trainerRoutes.js';
import scheduleRoutes from './routes/scheduleRoutes.js';

// Load environment variables from the .env file into process.env
dotenv.config();

// Create an Express application instance
const app = express();

// Connect the application to the MongoDB database
connectDB();

// --- Middleware Setup ---
// Middleware are functions that run before your route handlers.

// Enable CORS for all origins, allowing frontend to communicate with backend
app.use(cors());
// Parse incoming JSON requests and put the resulting object on req.body
app.use(express.json());
// Parse incoming requests with URL-encoded payloads
app.use(express.urlencoded({ extended: true }));

// Define __dirname for use with ES modules (like import/export)
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// --- API Routes Setup ---
// Link specific URL paths to the imported route handlers

// Routes for gym registration and login
app.use('/api/register-my-gym', gymRegistrationRoutes);
// Routes for fetching gym owner and branch details
app.use('/api/my-gym', gymDetailsRoutes);
// Routes for managing branches
app.use('/api/branches', branchRoutes);
// Routes for managing members (nested under branches)
app.use('/api/branches/:branchId/members', memberRoutes);
// Routes for managing trainers (nested under branches)
app.use('/api/branches/:branchId/trainers', trainerRoutes);
// Routes for managing class schedules (nested under branches)
app.use('/api/branches/:branchId/schedule', scheduleRoutes);


// --- Serve Frontend in Production ---
// In production, serve the static files from the frontend's build folder
if (process.env.NODE_ENV === 'production') {
    // Serve static files from the 'frontend/build' directory
    app.use(express.static(path.join(__dirname, '../frontend/build')));

    // For any other GET request, send the frontend's index.html file
    // This allows frontend routing to work
    app.get('*', (req, res) => res.sendFile(path.resolve(__dirname, '../frontend/build', 'index.html')));
} else {
    // In development, provide a simple response for the root URL
    app.get('/', (req, res) => {
        res.send('Gym System Backend API is running in development...');
    });
}

// --- Error Handling Middleware (Optional but Recommended) ---
// These would typically handle 404 Not Found and other errors.
// Ensure you have these files and uncomment if needed.
// app.use(notFound);
// app.use(errorHandler);

// --- Start the Server ---
// Define the port the server will listen on, using environment variable or default
const PORT = process.env.PORT || 5001;

// Start the Express server and listen on the defined port
app.listen(PORT, () => {
    // Log a message indicating the server has started
    console.log(`Server running in ${process.env.NODE_ENV || 'development'} mode on Port: ${PORT}`);

    // Check if MONGODB_URI is set in the environment variables (critical for database connection)
    if (!process.env.MONGODB_URI) {
        console.error('----------------------------------------------------');
        console.error('FATAL ERROR: MONGODB_URI is not defined in .env file.');
        console.error('Database connection will likely fail.');
        console.error('----------------------------------------------------');
    }
});
