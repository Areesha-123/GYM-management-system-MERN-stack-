// File: gymsystem/backend/controllers/trainerController.js

// Import necessary models and modules
import Trainer from '../models/Trainer.js';
import Branch from '../models/Branch.js';
import Payment from '../models/Payment.js';
import mongoose from 'mongoose';
import Member from '../models/Member.js'; // Import Member model for unassigning

// --- Controller Functions ---

/**
 * @desc Add a new trainer to a specific branch for the authenticated gym owner
 * @route POST /api/branches/:branchId/trainers
 * @access Private (Gym Owner)
 */
export const addTrainerToBranch = async (req, res) => {
    // Extract branch ID from parameters and gym owner ID from authenticated user
    const { branchId } = req.params;
    const gymOwnerId = req.user._id;

    try {
        // Validate Branch ID format
        if (!mongoose.Types.ObjectId.isValid(branchId)) {
            return res.status(400).json({ success: false, message: 'Invalid Branch ID format.' });
        }

        // Validate branch existence and authorization
        const branch = await Branch.findOne({ _id: branchId, gymOwner: gymOwnerId });
        if (!branch) {
            return res.status(404).json({ success: false, message: 'Branch not found or you are not authorized to add trainers to this branch.' });
        }

        // Extract trainer details from the request body
        const {
            name, email, phone, specialization, address, cnic,
            dateOfJoining, salary, fee, status, notes,
            emergencyContact, profileImage
        } = req.body;

        // --- Basic Input Validation ---
        if (!name || !email || !specialization || !dateOfJoining || salary === undefined) {
            return res.status(400).json({ success: false, message: 'Name, email, specialization, date of joining, and salary are required.' });
        }

        // Validate salary format
        if (isNaN(parseFloat(salary)) || parseFloat(salary) < 0) {
            return res.status(400).json({ success: false, message: 'Salary must be a non-negative number.'});
        }

        // Validate fee format if provided
        if (fee !== undefined && (isNaN(parseFloat(fee)) || parseFloat(fee) < 0)) {
            return res.status(400).json({ success: false, message: 'Fee must be a non-negative number if provided.'});
        }

        // Validate date of joining format (YYYY-MM-DD)
        if (typeof dateOfJoining !== 'string' || !dateOfJoining.match(/^\d{4}-\d{2}-\d{2}$/)) {
            return res.status(400).json({ success: false, message: 'Invalid date of joining format. Please use Paribas-MM-DD.' });
        }

        // Validate email format
        if (!/\S+@\S+\.\S+/.test(email)) {
            return res.status(400).json({ success: false, message: 'Invalid email format.' });
        }

        // Check for existing trainer with the same email in this branch
        const existingTrainerByEmail = await Trainer.findOne({ email: email.toLowerCase(), gymOwner: gymOwnerId, branchId: branchId });
        if (existingTrainerByEmail) {
            return res.status(400).json({ success: false, message: `A trainer with email ${email} already exists in this branch.` });
        }

        // Check for existing trainer with the same CNIC in this branch if CNIC is provided
        if (cnic) {
            const existingTrainerByCNIC = await Trainer.findOne({ cnic, gymOwner: gymOwnerId, branchId: branchId });
            if (existingTrainerByCNIC) {
                 return res.status(400).json({ success: false, message: `A trainer with CNIC ${cnic} already exists in this branch.` });
            }
        }

        // --- Create New Trainer Object ---
        const newTrainerData = {
            gymOwner: gymOwnerId,
            branchId,
            name,
            email: email.toLowerCase(), // Store email in lowercase
            specialization,
            dateOfJoining,
            salary: parseFloat(salary),
            fee: fee !== undefined ? parseFloat(fee) : 0, // Default fee to 0 if not provided
            status: status || 'Active', // Default status to 'Active'
            phone: phone || undefined, // Store undefined if not provided
            address: address || undefined, // Store undefined if not provided
            cnic: cnic || undefined, // Store undefined if not provided
            notes: notes || undefined, // Store undefined if not provided
            emergencyContact: emergencyContact || undefined, // Store undefined if not provided
            profileImage: profileImage || undefined, // Store undefined if not provided
            // Add initial history entry for joining
            history: [{
                date: new Date().toISOString().split('T')[0], // Today's date
                event: 'Joined',
                details: `Trainer joined on ${dateOfJoining}. Initial salary: ${parseFloat(salary)}, Fee: ${fee !== undefined ? parseFloat(fee) : 0}.`
            }]
        };

        // --- Save New Trainer to Database ---
        const newTrainer = new Trainer(newTrainerData);
        await newTrainer.save();

        // --- Respond with Success ---
        res.status(201).json({
            success: true,
            message: `Trainer ${newTrainer.name} added successfully to branch ${branch.name}.`,
            trainer: newTrainer // Send the full new trainer object back
        });

    } catch (error) {
        // Log the error for server diagnostics
        console.error(`Error in addTrainerToBranch for branch ${branchId}:`, error);

        // --- Handle Specific Errors ---
        // Mongoose validation errors
        if (error.name === 'ValidationError') {
            const messages = Object.values(error.errors).map(val => val.message);
            return res.status(400).json({ success: false, message: `Validation Error: ${messages.join(', ')}` });
        }
        // Handle other server errors
        res.status(500).json({ success: false, message: 'Server Error: Could not add trainer.' });
    }
};

/**
 * @desc Get all trainers for a specific branch for the authenticated gym owner, with optional search
 * @route GET /api/branches/:branchId/trainers?search=term
 * @access Private (Gym Owner)
 */
export const getTrainersForBranch = async (req, res) => {
    // Extract branch ID from parameters, gym owner ID from user, and search query from query string
    const { branchId } = req.params;
    const gymOwnerId = req.user._id;
    const { search } = req.query;

    try {
        // Validate Branch ID format
        if (!mongoose.Types.ObjectId.isValid(branchId)) {
            return res.status(400).json({ success: false, message: 'Invalid Branch ID format.' });
        }

        // Validate branch existence and authorization
        const branch = await Branch.findOne({ _id: branchId, gymOwner: gymOwnerId });
        if (!branch) {
            return res.status(404).json({ success: false, message: 'Branch not found or you are not authorized to view its trainers.' });
        }

        // Build the base query to find trainers in the specified branch for the gym owner
        let query = { branchId: branchId, gymOwner: gymOwnerId };

        // Apply search filter if a search term is provided
        if (search) {
            const trimmedSearch = search.trim().toLowerCase();
            const searchRegex = new RegExp(trimmedSearch, 'i'); // Case-insensitive regex

            // Search across name, email, and specialization fields
            query.$or = [
                { name: searchRegex },
                { email: searchRegex },
                { specialization: searchRegex },
            ];

            // If the search term looks like an ObjectId, also search by _id
            if (mongoose.Types.ObjectId.isValid(trimmedSearch)) {
                 query.$or.push({ _id: trimmedSearch });
            }
        }

        // Execute the query and sort by name
        const trainers = await Trainer.find(query).sort({ name: 1 });

        // --- Respond with the list of trainers ---
        res.status(200).json({
            success: true,
            count: trainers.length,
            trainers: trainers // Send the list of trainers
        });

    } catch (error) {
        // Log the error for server diagnostics
        console.error(`Error in getTrainersForBranch for branch ${branchId} (search: ${search}):`, error);
        // Handle server errors
        res.status(500).json({ success: false, message: 'Server Error: Could not fetch trainers.' });
    }
};

/**
 * @desc Get details of a specific trainer in a branch
 * @route GET /api/branches/:branchId/trainers/:trainerId
 * @access Private (Gym Owner)
 */
export const getTrainerDetails = async (req, res) => {
    // Extract branch and trainer IDs from parameters, gym owner ID from user
    const { branchId, trainerId } = req.params;
    const gymOwnerId = req.user._id;

    try {
        // Validate ID formats
        if (!mongoose.Types.ObjectId.isValid(branchId) || !mongoose.Types.ObjectId.isValid(trainerId)) {
            return res.status(400).json({ success: false, message: 'Invalid Branch or Trainer ID format.' });
        }

        // Validate branch existence and authorization
        const branch = await Branch.findOne({ _id: branchId, gymOwner: gymOwnerId });
        if (!branch) {
             return res.status(404).json({ success: false, message: 'Branch not found or not authorized.' });
        }

        // Find the trainer by ID within the specified branch and gym owner
        const trainer = await Trainer.findOne({ _id: trainerId, branchId: branchId, gymOwner: gymOwnerId });
        if (!trainer) {
            return res.status(404).json({ success: false, message: 'Trainer not found in this branch or not authorized.' });
        }

        // --- Respond with the trainer details ---
        res.status(200).json({ success: true, trainer: trainer });

    } catch (error) {
        // Log the error for server diagnostics
        console.error(`Error in getTrainerDetails for trainer ${trainerId}:`, error);

        // --- Handle Specific Errors ---
        // Cast error for invalid ObjectId formats
        if (error.name === 'CastError' && error.kind === 'ObjectId') {
            return res.status(400).json({ success: false, message: 'Invalid ID format.' });
        }
        // Handle other server errors
        res.status(500).json({ success: false, message: 'Server Error: Could not fetch trainer details.' });
    }
};

/**
 * @desc Update a trainer's details in a specific branch
 * @route PUT /api/branches/:branchId/trainers/:trainerId
 * @access Private (Gym Owner)
 */
export const updateTrainerInBranch = async (req, res) => {
    // Extract branch and trainer IDs from parameters, gym owner ID from user, and update data from body
    const { branchId, trainerId } = req.params;
    const gymOwnerId = req.user._id;
    const updateData = req.body;

    try {
        // Validate ID formats
        if (!mongoose.Types.ObjectId.isValid(branchId) || !mongoose.Types.ObjectId.isValid(trainerId)) {
            return res.status(400).json({ success: false, message: 'Invalid Branch or Trainer ID format.' });
        }

        // Find the trainer to update and ensure authorization
        let trainer = await Trainer.findOne({ _id: trainerId, branchId: branchId, gymOwner: gymOwnerId });
        if (!trainer) {
            return res.status(404).json({ success: false, message: 'Trainer not found or not authorized for update.' });
        }

        // Store original status for history logging
        const originalStatus = trainer.status;

        // Prevent updating restricted fields via the updateData object
        delete updateData.gymOwner;
        delete updateData.branchId;
        delete updateData.history;

        // --- Validate Update Data ---
        // Validate salary format if provided
        if (updateData.salary !== undefined && (isNaN(parseFloat(updateData.salary)) || parseFloat(updateData.salary) < 0)) {
            return res.status(400).json({ success: false, message: 'Salary must be a non-negative number.'});
        }
        // Validate fee format if provided
        if (updateData.fee !== undefined && (isNaN(parseFloat(updateData.fee)) || parseFloat(updateData.fee) < 0)) {
            return res.status(400).json({ success: false, message: 'Fee must be a non-negative number if provided.'});
        }
        // Validate date of joining format if provided
        if (updateData.dateOfJoining && (typeof updateData.dateOfJoining !== 'string' || !updateData.dateOfJoining.match(/^\d{4}-\d{2}-\d{2}$/))) {
            return res.status(400).json({ success: false, message: 'Invalid date of joining format. Please use Paribas-MM-DD.' });
        }
        // Validate email format if provided
        if (updateData.email && !/\S+@\S+\.\S+/.test(updateData.email)) {
             return res.status(400).json({ success: false, message: 'Invalid email format.' });
        }

        // --- Process and Validate Specific Fields ---
        // Convert salary and fee to numbers if provided
        if (updateData.salary !== undefined) updateData.salary = parseFloat(updateData.salary);
        if (updateData.fee !== undefined) updateData.fee = parseFloat(updateData.fee);
        // Convert email to lowercase if provided
        if (updateData.email) updateData.email = updateData.email.toLowerCase();

        // Check for duplicate email if email is being updated
        if (updateData.email && updateData.email !== trainer.email) {
            const existingTrainerByEmail = await Trainer.findOne({
                email: updateData.email,
                gymOwner: gymOwnerId,
                branchId: branchId,
                _id: { $ne: trainerId } // Exclude the current trainer
            });
            if (existingTrainerByEmail) {
                return res.status(400).json({ success: false, message: `Another trainer with email ${updateData.email} already exists in this branch.` });
            }
        }

        // Check for duplicate CNIC if CNIC is being updated
        if (updateData.cnic && updateData.cnic !== trainer.cnic) {
            const existingTrainerByCNIC = await Trainer.findOne({
                cnic: updateData.cnic,
                gymOwner: gymOwnerId,
                branchId: branchId,
                _id: { $ne: trainerId } // Exclude the current trainer
            });
            if (existingTrainerByCNIC) {
                 return res.status(400).json({ success: false, message: `Another trainer with CNIC ${updateData.cnic} already exists in this branch.` });
            }
        }

        // --- Apply Updates to the Trainer Document ---
        // Use Object.assign to merge updateData into the trainer document
        Object.assign(trainer, updateData);

        // --- Prepare History Entry ---
        let historyEntry = null;
        // Check if status has changed
        if (updateData.status && updateData.status !== originalStatus) {
            if (updateData.status === 'Terminated') {
                historyEntry = {
                    date: new Date().toISOString().split('T')[0], // Today's date
                    event: 'Left',
                    details: `Trainer status changed from ${originalStatus} to Terminated.`,
                };
            } else {
                historyEntry = {
                    date: new Date().toISOString().split('T')[0], // Today's date
                    event: 'Status Changed',
                    details: `Trainer status changed from ${originalStatus} to ${updateData.status}.`,
                };
            }
        } else {
            // If status didn't change, check if any other fields were modified
            let changesMade = false;
            // Iterate through updateData keys to see if values are different from current trainer values
            for (const key in updateData) {
                // Compare values, excluding the 'status' field which was handled above
                if (JSON.stringify(trainer[key]) !== JSON.stringify(updateData[key]) && key !== 'status') {
                    changesMade = true;
                    break; // Stop checking once a change is found
                }
            }
            // If changes were made to fields other than status, create a generic update history entry
            if (changesMade) {
                 historyEntry = {
                    date: new Date().toISOString().split('T')[0], // Today's date
                    event: 'Profile Updated',
                    details: `Trainer profile details were updated.`,
                };
            }
        }

        // Add the history entry to the trainer's history array if one was created
        if (historyEntry) {
            trainer.history.unshift(historyEntry); // Add to the beginning of the array
        }

        // --- Save the Updated Trainer Document ---
        const updatedTrainerInstance = await trainer.save();

        // --- Respond with Success ---
        res.status(200).json({ success: true, message: `Trainer ${updatedTrainerInstance.name}'s details updated.`, trainer: updatedTrainerInstance });

    } catch (error) {
        // Log the error for server diagnostics
        console.error(`Error in updateTrainerInBranch for trainer ${trainerId}:`, error);

        // --- Handle Specific Errors ---
        // Mongoose validation errors
        if (error.name === 'ValidationError') {
            const messages = Object.values(error.errors).map(val => val.message);
            return res.status(400).json({ success: false, message: `Validation Error: ${messages.join(', ')}` });
        }
         // Cast error for invalid ObjectId formats
        if (error.name === 'CastError' && error.kind === 'ObjectId') {
            return res.status(400).json({ success: false, message: 'Invalid ID format.' });
        }
        // Handle other server errors
        res.status(500).json({ success: false, message: 'Server Error: Could not update trainer details.' });
    }
};

/**
 * @desc Delete a trainer from a specific branch
 * @route DELETE /api/branches/:branchId/trainers/:trainerId
 * @access Private (Gym Owner)
 */
export const deleteTrainerFromBranch = async (req, res) => {
    // Extract branch and trainer IDs from parameters, gym owner ID from user
    const { branchId, trainerId } = req.params;
    const gymOwnerId = req.user._id;

    try {
        // Validate ID formats
        if (!mongoose.Types.ObjectId.isValid(branchId) || !mongoose.Types.ObjectId.isValid(trainerId)) {
            return res.status(400).json({ success: false, message: 'Invalid Branch or Trainer ID format.' });
        }

        // Find the trainer to delete and ensure authorization
        const trainer = await Trainer.findOne({ _id: trainerId, branchId: branchId, gymOwner: gymOwnerId });
        if (!trainer) {
            return res.status(404).json({ success: false, message: 'Trainer not found or not authorized for deletion.' });
        }

        // --- Unassign Trainer from Members and Log History ---
        // Find all members assigned to this trainer in this branch and gym owner
        await Member.updateMany(
            { trainerId: trainerId, branchId: branchId, gymOwner: gymOwnerId },
            {
                // Set the trainerId field to null
                $set: { trainerId: null, trainerName: null }, // Also clear trainerName
                // Push a history entry to each affected member's history array
                $push: {
                    history: {
                        $each: [{
                            date: new Date().toISOString().split('T')[0], // Today's date
                            event: 'Trainer Unassigned',
                            details: `Trainer ${trainer.name} (ID: ${trainer._id}) was deleted from the system.`,
                        }],
                        $position: 0 // Add to the beginning of the array
                    }
                }
            }
        );

        // --- Delete the Trainer from the Database ---
        await Trainer.deleteOne({ _id: trainerId, branchId: branchId, gymOwner: gymOwnerId });

        // --- Respond with Success ---
        res.status(200).json({ success: true, message: `Trainer ${trainer.name} deleted successfully and unassigned from members in this branch.` });

    } catch (error) {
        // Log the error for server diagnostics
        console.error(`Error deleting trainer ${req.params.trainerId}:`, error);

        // --- Handle Specific Errors ---
        // Cast error for invalid ObjectId formats
        if (error.name === 'CastError' && error.kind === 'ObjectId') {
            return res.status(400).json({ success: false, message: 'Invalid ID format.' });
        }
        // Handle other server errors
        res.status(500).json({ success: false, message: 'Server Error: Could not delete trainer.' });
    }
};

/**
 * @desc Record a payment for a specific trainer
 * @route POST /api/branches/:branchId/trainers/:trainerId/payments
 * @access Private (Gym Owner)
 */
export const recordTrainerPayment = async (req, res) => {
    // Extract branch and trainer IDs from parameters, gym owner ID from user
    const { branchId, trainerId } = req.params;
    const gymOwnerId = req.user._id;

    // Extract payment details from the request body
    // paymentDate is expected as YYYY-MM-DD from frontend
    // paymentMonth is optional (YYYY-MM), derived from paymentDate if not provided
    const { amount, paymentDate, paymentMonth, notes } = req.body;

    try {
        // Validate ID formats
        if (!mongoose.Types.ObjectId.isValid(branchId) || !mongoose.Types.ObjectId.isValid(trainerId)) {
            return res.status(400).json({ success: false, message: 'Invalid Branch or Trainer ID.' });
        }

        // Validate payment amount
        if (!amount || isNaN(parseFloat(amount)) || parseFloat(amount) <= 0) {
            return res.status(400).json({ success: false, message: 'Invalid payment amount. Amount must be a positive number.' });
        }

        // Validate paymentDate format (YYYY-MM-DD)
        if (!paymentDate || !paymentDate.match(/^\d{4}-\d{2}-\d{2}$/)) {
            return res.status(400).json({ success: false, message: 'Invalid payment date format. Use Paribas-MM-DD.' });
        }

        // Determine the payment month (YYYY-MM)
        // Use the provided paymentMonth if valid, otherwise derive from paymentDate
        const derivedPaymentMonth = paymentDate.substring(0, 7);
        const finalPaymentMonth = paymentMonth && paymentMonth.match(/^\d{4}-\d{2}$/) ? paymentMonth : derivedPaymentMonth;

        // Find the trainer to record payment for and ensure authorization
        const trainer = await Trainer.findOne({ _id: trainerId, branchId, gymOwner: gymOwnerId });
        if (!trainer) {
            return res.status(404).json({ success: false, message: 'Trainer not found or not authorized.' });
        }

        // --- Create New Payment Record ---
        const payment = await Payment.create({
            gymOwner: gymOwnerId,
            branchId,
            trainerId,
            memberId: null, // This payment is for a trainer, not a member
            amount: parseFloat(amount),
            paymentDate: paymentDate, // Use the provided paymentDate
            paymentMonth: finalPaymentMonth, // Use the determined payment month
            paymentType: 'TrainerSalary', // Payment type is Trainer Salary
            notes: notes || `Salary payment for ${trainer.name}`, // Use provided notes or a default
            recordedBy: req.user._id // Record which user made the payment
        });

        // --- Add Payment Event to Trainer's History ---
        trainer.history.unshift({
            date: paymentDate, // History entry date is the payment date
            event: 'Salary Paid',
            details: `Payment of ${parseFloat(amount)} for ${finalPaymentMonth} recorded. Notes: ${notes || 'N/A'}`,
            amount: parseFloat(amount), // Include amount in history details
        });
        await trainer.save(); // Save the updated trainer document

        // --- Respond with Success ---
        res.status(201).json({ success: true, message: 'Trainer payment recorded successfully.', payment });

    } catch (error) {
        // Log the error for server diagnostics
        console.error(`Error in recordTrainerPayment for trainer ${trainerId}:`, error);

        // --- Handle Specific Errors ---
        // Mongoose validation errors
        if (error.name === 'ValidationError') {
            const messages = Object.values(error.errors).map(val => val.message);
            return res.status(400).json({ success: false, message: `Validation Error: ${messages.join(', ')}` });
        }
        // Handle other server errors
        res.status(500).json({ success: false, message: 'Server error while recording trainer payment.' });
    }
};


/**
 * @desc Get payment history for a specific trainer
 * @route GET /api/branches/:branchId/trainers/:trainerId/payments
 * @access Private (Gym Owner)
 */
export const getTrainerPaymentHistory = async (req, res) => {
    // Extract branch and trainer IDs from parameters, gym owner ID from user
    const { branchId, trainerId } = req.params;
    const gymOwnerId = req.user._id;

    try {
        // Validate ID formats
        if (!mongoose.Types.ObjectId.isValid(branchId) || !mongoose.Types.ObjectId.isValid(trainerId)) {
            return res.status(400).json({ success: false, message: 'Invalid Branch or Trainer ID.' });
        }

        // Find the trainer to fetch payment history for and ensure authorization
        const trainer = await Trainer.findOne({ _id: trainerId, branchId, gymOwner: gymOwnerId });
        if (!trainer) {
            return res.status(404).json({ success: false, message: 'Trainer not found or not authorized.' });
        }

        // Find all payments associated with this trainer, branch, and gym owner
        const payments = await Payment.find({
            trainerId: trainerId,
            branchId: branchId,
            gymOwner: gymOwnerId
        })
        // Sort payments by payment date (descending) and then creation date (descending)
        .sort({ paymentDate: -1, createdAt: -1 });

        // --- Respond with the payment history ---
        res.status(200).json({
            success: true,
            count: payments.length,
            payments: payments // Send the list of payments
        });

    } catch (error) {
        // Log the error for server diagnostics
        console.error(`Error fetching payment history for trainer ${trainerId}:`, error);
        // Handle server errors
        res.status(500).json({ success: false, message: 'Server error while fetching trainer payment history.' });
    }
};
