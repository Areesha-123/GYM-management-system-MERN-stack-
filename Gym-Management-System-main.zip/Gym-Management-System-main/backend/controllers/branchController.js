// File: gymsystem/backend/controllers/branchController.js

// Import the Branch model for database operations
import Branch from '../models/Branch.js';

/**
 * @desc Add a new branch for the authenticated gym owner
 * @route POST /api/branches
 * @access Private (Gym Owner)
 */
export const addBranch = async (req, res) => {
  try {
    // Extract branch name from request body and gym owner ID from authenticated user
    const { name } = req.body;
    const gymOwnerId = req.user._id;

    // Validate if branch name is provided
    if (!name) {
      return res.status(400).json({ success: false, message: 'Branch name is required.' });
    }

    // Check if a branch with the same name already exists for this gym owner
    const existingBranch = await Branch.findOne({ name, gymOwner: gymOwnerId });
    if (existingBranch) {
      return res.status(400).json({ success: false, message: `A branch named '${name}' already exists.` });
    }

    // Create a new branch in the database
    const newBranch = await Branch.create({
      name,
      gymOwner: gymOwnerId,
    });

    // Respond based on the creation result
    if (newBranch) {
      // Success: Branch created
      res.status(201).json({
        success: true,
        message: 'Branch added successfully!',
        branch: {
          id: newBranch._id,
          name: newBranch.name,
        },
      });
    } else {
      // Failure: Invalid data provided
      res.status(400).json({ success: false, message: 'Invalid branch data, branch not created.' });
    }
  } catch (error) {
    // Log server error for diagnostics
    console.error('Error adding branch:', error);

    // Handle Mongoose validation errors
    if (error.name === 'ValidationError') {
       const messages = Object.values(error.errors).map(val => val.message);
       return res.status(400).json({ success: false, message: messages.join(', ') });
    }

    // Handle other server errors
    res.status(500).json({ success: false, message: 'Server Error: Could not add branch.' });
  }
};

/**
 * @desc Get all branches for the authenticated gym owner
 * @route GET /api/branches
 * @access Private (Gym Owner)
 */
export const getMyBranches = async (req, res) => {
    try {
        // Find all branches belonging to the authenticated gym owner, sorted by creation date
        const branches = await Branch.find({ gymOwner: req.user._id }).sort({ createdAt: 1 });

        // Respond with the list of branches
        res.status(200).json({
            success: true,
            count: branches.length,
            branches: branches.map(branch => ({
                id: branch._id,
                name: branch.name,
            })),
        });
    } catch (error) {
        // Log server error for diagnostics
        console.error('Error fetching branches:', error);

        // Handle server errors
        res.status(500).json({ success: false, message: 'Server Error: Could not fetch branches.' });
    }
};

/**
 * @desc Delete a specific branch for the authenticated gym owner
 * @route DELETE /api/branches/:branchId
 * @access Private (Gym Owner)
 */
export const deleteBranch = async (req, res) => {
  try {
    // Extract branch ID from request parameters and gym owner ID from authenticated user
    const branchId = req.params.branchId;
    const gymOwnerId = req.user._id;

    // Find the branch by ID and ensure it belongs to the authenticated gym owner
    const branch = await Branch.findOne({ _id: branchId, gymOwner: gymOwnerId });
    if (!branch) {
      // Branch not found or does not belong to the user
      return res.status(404).json({ success: false, message: 'Branch not found or you are not authorized to delete it.' });
    }

    // Check if this is the last remaining branch for the user
    const allUserBranches = await Branch.find({ gymOwner: gymOwnerId });
    if (allUserBranches.length <= 1) {
        // Prevent deleting the last branch
        return res.status(400).json({ success: false, message: 'Cannot delete the last remaining branch. Add another branch before deleting this one, or consider renaming it.' });
    }

    // Delete the branch
    await Branch.findByIdAndDelete(branchId);

    // TODO: Implement cascading deletes for associated data (members, classes, trainers for this branchId)

    // Respond with success message
    res.status(200).json({ success: true, message: 'Branch deleted successfully.' });
  } catch (error) {
    // Log server error for diagnostics
    console.error('Error deleting branch:', error);

    // Handle invalid MongoDB ObjectId format
    if (error.name === 'CastError' && error.kind === 'ObjectId' && error.path === '_id') {
        return res.status(400).json({ success: false, message: 'Invalid branch ID format.' });
    }

    // Handle other server errors
    res.status(500).json({ success: false, message: 'Server Error: Could not delete branch.' });
  }
};
