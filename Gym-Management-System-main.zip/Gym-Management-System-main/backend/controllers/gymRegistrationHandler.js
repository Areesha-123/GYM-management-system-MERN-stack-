// File: gymsystem/backend/controllers/gymRegistrationHandler.js

// Import necessary models and libraries
import GymRegistrationInfo from '../models/GymRegistrationInfo.js';
import Branch from '../models/Branch.js';
import jwt from 'jsonwebtoken';

/**
 * @desc Generate a JSON Web Token for user authentication
 * @param {string} id - The user ID to include in the token payload
 * @returns {string} The generated JWT
 */
const generateToken = (id) => {
  // Sign the token with the user ID, JWT secret, and expiry
  return jwt.sign({ id }, process.env.JWT_SECRET, {
    expiresIn: process.env.JWT_EXPIRES_IN || '30d', // Default to 30 days if not specified in environment variables
  });
};

/**
 * @desc Handle the registration of a new gym owner and their initial branch
 * @route POST /api/register
 * @access Public
 */
export const handleNewGymRegistration = async (req, res) => {
  try {
    // Extract registration details from the request body
    const { ownerName, gymName, branchName, email, password } = req.body;

    // Validate if all required fields are provided
    if (!ownerName || !gymName || !branchName || !email || !password) {
      return res.status(400).json({
        success: false,
        message: 'Oops! Please fill out all the fields to register.',
      });
    }

    // Check if a gym with the provided email already exists
    const existingGym = await GymRegistrationInfo.findOne({ email: email });
    if (existingGym) {
      return res.status(400).json({
        success: false,
        message: 'It looks like a gym with this email is already registered. Try a different email or login.',
      });
    }

    // Create a new gym owner entry in the database
    const newGymOwner = await GymRegistrationInfo.create({
      ownerName,
      gymName,
      branchName, // Storing initial branch name in GymRegistrationInfo might be redundant if Branch model is used for all branches
      email,
      password,
    });

    // If gym owner creation is successful, create the initial branch
    if (newGymOwner) {
      try {
        await Branch.create({
          name: branchName,
          gymOwner: newGymOwner._id, // Link the branch to the newly created gym owner
        });
      } catch (branchError) {
        // Log the branch creation error on the server for diagnostics (Critical issue)
        console.error('CRITICAL: Gym owner created but initial branch creation failed:', branchError, 'GymOwner ID:', newGymOwner._id);
        // Inform the user about the partial success but critical issue with branch setup
        // Note: Depending on desired UX, you might return 200 with a warning instead of 500.
        return res.status(500).json({
            success: false, // Or true with a warning
            message: 'Gym registered, but there was an issue setting up the initial branch. Please contact support.',
            // Optionally return some details if you mark success: true
            // gymOwnerId: newGymOwner._id
        });
      }

      // Respond with success message and basic gym details
      res.status(201).json({
        success: true,
        message: 'Great! Your gym has been registered successfully, and your first branch is set up.',
        gymDetails: {
          id: newGymOwner._id,
          ownerName: newGymOwner.ownerName,
          gymName: newGymOwner.gymName,
          email: newGymOwner.email,
        },
      });
    } else {
      // This case implies GymRegistrationInfo.create returned falsy without throwing, which is unusual.
      res.status(400).json({
        success: false,
        message: 'Sorry, we couldn_t register your gym due to invalid data. Please check your details.',
      });
    }

  } catch (error) {
    // Log the main registration error on the server for diagnostics
    console.error('Error during gym registration main try-catch:', error);

    // Handle Mongoose validation errors
    if (error.name === 'ValidationError') {
        let errorMessages = [];
        for (let field in error.errors) {
            errorMessages.push(error.errors[field].message);
        }
        return res.status(400).json({
            success: false,
            message: `Please correct the following: ${errorMessages.join(' ')}`
        });
    }

    // Handle other server errors during registration
    res.status(500).json({
      success: false,
      message: 'Oh no! Something went wrong on our end during registration. Please try again later.',
    });
  }
};

/**
 * @desc Handle gym owner login
 * @route POST /api/login
 * @access Public
 */
export const handleGymUserLogin = async (req, res) => {
  try {
    // Extract email and password from the request body
    const { email, password } = req.body;

    // Validate if both email and password are provided
    if (!email || !password) {
      return res.status(400).json({
        success: false,
        message: 'Please provide both email and password to log in.',
      });
    }

    // Find the registered gym user by email
    const registeredGymUser = await GymRegistrationInfo.findOne({ email: email });

    // Check if a user with the provided email exists
    if (!registeredGymUser) {
      return res.status(401).json({
        success: false,
        message: 'Invalid credentials. No account found with this email.',
      });
    }

    // Compare the provided password with the stored hashed password
    const isPasswordCorrect = await registeredGymUser.matchPassword(password);

    // Check if the password is correct
    if (!isPasswordCorrect) {
      return res.status(401).json({
        success: false,
        message: 'Invalid credentials. The password you entered is incorrect.',
      });
    }

    // Generate a JWT for the authenticated user
    const token = generateToken(registeredGymUser._id);

    // Respond with success message, token, and basic user details
    res.status(200).json({
      success: true,
      message: 'Logged in successfully!',
      token: token,
      userDetails: {
        id: registeredGymUser._id,
        ownerName: registeredGymUser.ownerName,
        gymName: registeredGymUser.gymName,
        email: registeredGymUser.email,
      },
    });

  } catch (error) {
    // Log server error for login diagnostics
    console.error('Error during gym user login:', error);
    // Handle server errors during login
    res.status(500).json({
      success: false,
      message: 'Oh no! Something went wrong on our end during login. Please try again later.',
    });
  }
};
