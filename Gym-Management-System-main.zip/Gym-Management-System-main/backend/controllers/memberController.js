// File: gymsystem/backend/controllers/memberController.js

// Import necessary modules and models
import mongoose from 'mongoose';
import Member from '../models/Member.js';
import Branch from '../models/Branch.js';
import Trainer from '../models/Trainer.js';

// --- Utility functions ---

/**
 * @desc Formats a Date object or a YYYY-MM-DD string into a YYYY-MM-DD string.
 * @param {Date|string} date - The date to format.
 * @returns {string} The formatted date string (YYYY-MM-DD), or an empty string if invalid.
 */
const formatDateToYYYYMMDD = (date) => {
    // Check if the input is a valid Date object
    if (date instanceof Date && !isNaN(date.getTime())) {
        const year = date.getFullYear();
        const month = String(date.getMonth() + 1).padStart(2, '0'); // Months are 0-indexed
        const day = String(date.getDate()).padStart(2, '0');
        return `${year}-${month}-${day}`;
    }
    // Check if the input is already a valid YYYY-MM-DD string
    if (typeof date === 'string' && /^\d{4}-\d{2}-\d{2}$/.test(date)) {
        return date; // Return as is if it matches the format
    }
    // Return empty string for invalid input
    return '';
};

/**
 * @desc Calculates a future date based on a start date and number of months.
 * Handles Date objects and YYYY-MM-DD strings as start dates.
 * @param {number} months - The number of months to add.
 * @param {Date|string} [startDateInput=new Date()] - The starting date. Defaults to today.
 * @returns {string} The calculated future date string in YYYY-MM-DD format.
 */
const getFutureDateBackend = (months, startDateInput = new Date()) => {
    let startDate;

    // Determine the starting date based on input type
    if (typeof startDateInput === 'string') {
        // Parse YYYY-MM-DD string assuming UTC to avoid timezone issues
        const parts = startDateInput.split('-');
        if (parts.length === 3) {
            startDate = new Date(Date.UTC(parseInt(parts[0], 10), parseInt(parts[1], 10) - 1, parseInt(parts[2], 10)));
        } else {
             // Attempt to parse other string formats, less reliable
            startDate = new Date(startDateInput);
        }
        // Fallback to today if string parsing fails
        if (isNaN(startDate.getTime())) {
            startDate = new Date();
        }
    } else if (startDateInput instanceof Date && !isNaN(startDateInput.getTime())) {
        // Use provided valid Date object
        startDate = new Date(startDateInput.getTime());
    } else {
        // Fallback to today for invalid input
        startDate = new Date();
    }

    // Add the specified number of months (using UTC methods)
    startDate.setUTCMonth(startDate.getUTCMonth() + Number(months));

    // Return the calculated date formatted as YYYY-MM-DD
    return formatDateToYYYYMMDD(startDate);
};

/**
 * @desc Gets today's date formatted as a YYYY-MM-DD string.
 * @returns {string} Today's date string.
 */
const getTodayDateStringBackend = () => formatDateToYYYYMMDD(new Date());

// --- Subscription Pack Details (Ideally from a config or database) ---
// This array holds the details for different subscription plans.
const subscriptionPacks = [
    { id: 'student_1m', type: 'Student', durationMonths: 1, name: 'Student - 1 Month', price: 3000 },
    { id: 'student_3m', type: 'Student', durationMonths: 3, name: 'Student - 3 Months', price: 8000 },
    { id: 'solo_1m', type: 'Solo', durationMonths: 1, name: 'Solo - 1 Month', price: 5000 },
    { id: 'solo_3m', type: 'Solo', durationMonths: 3, name: 'Solo - 3 Months', price: 13500 },
    { id: 'solo_6m', type: 'Solo', durationMonths: 6, name: 'Solo - 6 Months', price: 25000 },
    { id: 'solo_12m', type: 'Solo', durationMonths: 12, name: 'Solo - 1 Year', price: 45000 },
];

/**
 * @desc Retrieves details for a subscription pack by its ID.
 * @param {string} packId - The ID of the subscription pack.
 * @returns {object|null} The pack details object, or null if not found.
 */
const getPackDetailsLocalBackend = (packId) => {
    return subscriptionPacks.find(p => p.id === packId) || null;
};
// --- End of Utility functions & Pack Details ---


/**
 * @desc Add a new member to a specific branch for the authenticated gym owner
 * @route POST /api/branches/:branchId/members
 * @access Private (Gym Owner)
 */
export const addMemberToBranch = async (req, res) => {
    try {
        // Extract branch ID from parameters and gym owner ID from authenticated user
        const { branchId } = req.params;
        const gymOwnerId = req.user._id;

        // Extract member details from the request body
        const {
            name, email, phone, gender, dob, joiningDate,
            currentPlanId,
            trainerId, // trainerId from frontend
            goal
        } = req.body;

        // --- Basic Input Validation ---
        if (!name || !joiningDate || !currentPlanId || !phone) {
            return res.status(400).json({ success: false, message: 'Member name, phone, joining date, and subscription plan are required.' });
        }

        // Validate date formats
        if (typeof joiningDate !== 'string' || !joiningDate.match(/^\d{4}-\d{2}-\d{2}$/)) {
            return res.status(400).json({ success: false, message: 'Invalid joining date format. Please use YYYY-MM-DD.' });
        }
        if (dob && (typeof dob !== 'string' || !dob.match(/^\d{4}-\d{2}-\d{2}$/))) {
            return res.status(400).json({ success: false, message: 'Invalid date of birth format. Please use YYYY-MM-DD.' });
        }

        // Validate email format and check for existing email for this gym owner
        if (email) {
            const emailRegex = /^\w+([.-]?\w+)*@\w+([.-]?\w+)*(\.\w{2,3})+$/;
            if (!emailRegex.test(email)) {
                return res.status(400).json({ success: false, message: 'Invalid email format.' });
            }
            const existingMemberByEmail = await Member.findOne({ email, gymOwner: gymOwnerId });
            if (existingMemberByEmail) {
                return res.status(400).json({ success: false, message: `A member with email ${email} already exists for this gym owner.` });
            }
        }

        // Validate branch existence and authorization
        const branch = await Branch.findOne({ _id: branchId, gymOwner: gymOwnerId });
        if (!branch) {
            return res.status(404).json({ success: false, message: 'Branch not found or you are not authorized for this branch.' });
        }

        // --- Generate Unique Display Member ID for the Branch ---
        let nextDisplayMemberId = 1001; // Starting ID
        const lastMember = await Member.findOne({ branchId: branchId, gymOwner: gymOwnerId })
                                        .sort({ displayMemberId: -1 })
                                        .limit(1);
        // If there's a last member, increment their display ID
        if (lastMember && lastMember.displayMemberId) {
            nextDisplayMemberId = lastMember.displayMemberId + 1;
        }

        // --- Validate Subscription Plan ---
        const packDetailsInfo = getPackDetailsLocalBackend(currentPlanId);
        if (!packDetailsInfo) {
            return res.status(400).json({ success: false, message: `Invalid subscription plan ID: ${currentPlanId}` });
        }
        const packDurationMonths = packDetailsInfo.durationMonths;
        if (isNaN(packDurationMonths) || packDurationMonths <= 0) {
            return res.status(400).json({ success: false, message: 'Invalid subscription plan duration.'});
        }

        // --- Calculate End Date and Payment Due Date ---
        const calculatedEndDate = getFutureDateBackend(packDurationMonths, joiningDate);
        const calculatedPaymentDueDate = calculatedEndDate; // Payment due date is the same as end date for initial payment

        // --- Prepare Initial Member History ---
        const initialHistory = [
            {
                date: joiningDate, event: 'Joined',
                details: `Joined with plan: ${packDetailsInfo.name}. Subscription valid until ${calculatedEndDate}. Display ID: ${nextDisplayMemberId}`,
                planId: currentPlanId, planName: packDetailsInfo.name
            },
            {
                date: joiningDate, event: 'Payment',
                details: `Initial payment for ${packDetailsInfo.name}.`,
                amountPaid: packDetailsInfo.price,
                planId: currentPlanId, planName: packDetailsInfo.name
            }
        ];

        // --- Handle Trainer Assignment ---
        let assignedTrainerName = null;
        let validTrainerIdToSet = null; // Variable to hold the validated trainer ObjectId

        // Check if trainerId was provided and is a valid ObjectId
        if (trainerId && mongoose.Types.ObjectId.isValid(trainerId)) {
            // Find the trainer and ensure they belong to the gym owner and branch
            const assignedTrainer = await Trainer.findOne({ _id: trainerId, gymOwner: gymOwnerId, branchId: branchId });
            if (assignedTrainer) {
                assignedTrainerName = assignedTrainer.name;
                validTrainerIdToSet = assignedTrainer._id; // Set the valid ObjectId
                // Add trainer assignment event to member history
                initialHistory.push({
                    date: joiningDate, event: 'Trainer Assigned',
                    details: `Assigned to Trainer ${assignedTrainer.name} (ID: ${assignedTrainer._id}).`
                });
            } else {
                // Log a warning if the provided trainer ID is invalid or unauthorized
                console.warn(`Trainer with ID ${trainerId} not found or not authorized for this branch during member creation.`);
                // Do not set trainerId or trainerName if trainer is not valid/found
            }
        }

        // --- Create New Member Object ---
        const newMemberData = {
            name,
            displayMemberId: nextDisplayMemberId,
            email: email || null, // Store null if email is not provided
            phone,
            gender: gender || 'Male', // Default gender
            dob: dob || null, // Store null if DOB is not provided
            joiningDate,
            currentPlanId,
            endDate: calculatedEndDate,
            paymentDueDate: calculatedPaymentDueDate,
            status: 'Active', // New members are active by default
            history: initialHistory,
            lastPaymentDate: joiningDate, // Initial payment date
            trainerId: validTrainerIdToSet, // Use the validated trainer ID (ObjectId or null)
            trainerName: assignedTrainerName, // Use the fetched trainer name (string or null)
            branchId,
            gymOwner: gymOwnerId,
            goal: goal || null, // Store null if goal is not provided
        };

        // --- Save New Member to Database ---
        const newMember = await Member.create(newMemberData);

        // --- Update Trainer's History if Assigned ---
        if (newMember.trainerId) {
            const assignedTrainer = await Trainer.findById(newMember.trainerId);
            if (assignedTrainer) {
                // Add member assignment event to the trainer's history
                assignedTrainer.history.unshift({
                    date: joiningDate, event: 'Assigned to Member',
                    details: `Assigned to new member ${newMember.name} (Display ID: ${newMember.displayMemberId}).`,
                    memberId: newMember._id.toString(), // Store member ID as string
                    memberName: newMember.name
                });
                await assignedTrainer.save(); // Save the updated trainer document
            }
        }

        // --- Respond with Success ---
        res.status(201).json({
            success: true,
            message: `Member '${name}' (ID: ${newMember.displayMemberId}) added successfully to branch '${branch.name}'!`,
            member: newMember, // Send the full new member object back
        });

    } catch (error) {
        // Log the error for server diagnostics
        console.error(`Error adding member to branch ${req.params.branchId}:`, error);

        // --- Handle Specific Errors ---
        // Mongoose validation errors
        if (error.name === 'ValidationError') {
            const messages = Object.values(error.errors).map(val => val.message);
            return res.status(400).json({ success: false, message: `Validation Error: ${messages.join(', ')}` });
        }
        // Duplicate key error for displayMemberId (unlikely with the current logic but good to handle)
        if (error.code === 11000 && error.keyPattern && error.keyPattern.displayMemberId) {
            return res.status(400).json({ success: false, message: `Failed to generate a unique Member ID for this branch. Please try again.` });
        }
        // Duplicate key error for email
        if (error.code === 11000 && error.keyPattern && error.keyPattern.email) {
             // This check is also done before creation, but included here as a fallback
            return res.status(400).json({ success: false, message: `A member with email ${req.body.email} already exists for this gym owner.` });
        }
        // Handle other server errors
        res.status(500).json({ success: false, message: 'Server Error: Could not add member.' });
    }
};

/**
 * @desc Get all members for a specific branch for the authenticated gym owner, with optional search
 * @route GET /api/branches/:branchId/members
 * @access Private (Gym Owner)
 */
export const getMembersByBranch = async (req, res) => {
    try {
        // Extract branch ID from parameters, gym owner ID from user, and search query from query string
        const { branchId } = req.params;
        const gymOwnerId = req.user._id;
        const { search } = req.query;

        // Validate Branch ID format
        if (!mongoose.Types.ObjectId.isValid(branchId)) {
            return res.status(400).json({ success: false, message: 'Invalid Branch ID format.' });
        }

        // Validate branch existence and authorization
        const branch = await Branch.findOne({ _id: branchId, gymOwner: gymOwnerId });
        if (!branch) {
            return res.status(404).json({ success: false, message: 'Branch not found or you are not authorized for this branch.' });
        }

        // Build the base query to find members in the specified branch for the gym owner
        let query = Member.find({ branchId: branchId, gymOwner: gymOwnerId });

        // Apply search filter if a search term is provided
        if (search) {
            const trimmedSearch = search.trim();
            // Check if the search term is a number (potential displayMemberId)
            if (/^\d+$/.test(trimmedSearch)) {
                const searchNumber = parseInt(trimmedSearch, 10);
                 // Add displayMemberId search to the existing query conditions
                query = query.where({ displayMemberId: searchNumber });
            } else {
                // Search by name using case-insensitive exact match regex
                const exactNameRegex = new RegExp(`^${trimmedSearch}$`, 'i');
                 // Add name search to the existing query conditions
                query = query.where({ name: exactNameRegex });
            }
        }

        // Execute the query, sort by displayMemberId, and use .lean() for faster retrieval
        const members = await query.sort({ displayMemberId: 1 }).lean();

        // Get today's date string for status check
        const today = getTodayDateStringBackend();

        // Process members to update status if subscription has expired
        const processedMembers = members.map(member => {
            // Check if member is active and end date is in the past
            if (member.status === 'Active' && member.endDate && new Date(member.endDate) < new Date(today)) {
                 // Note: This change is only in the returned object, not persisted to the database here.
                 // A separate scheduled task should ideally update statuses in the DB.
                member.status = 'Expired';
            }
            // The trainerName is already stored on the member document during creation/update,
            // so no need for population here if that process is reliable.
            return member;
        });

        // Respond with the list of members
        res.status(200).json({
            success: true,
            count: processedMembers.length,
            members: processedMembers,
        });
    } catch (error) {
        // Log the error for server diagnostics
        console.error(`Error fetching members for branch ${req.params.branchId} (search: ${req.query.search}):`, error);
        // Handle server errors
        res.status(500).json({ success: false, message: 'Server Error: Could not fetch members.' });
    }
};

/**
 * @desc Update an existing member's details in a specific branch
 * @route PUT /api/branches/:branchId/members/:memberId
 * @access Private (Gym Owner)
 */
export const updateMemberInBranch = async (req, res) => {
    try {
        // Extract branch and member IDs from parameters, gym owner ID from user
        const { branchId, memberId } = req.params;
        const gymOwnerId = req.user._id;

        // Extract update fields from the request body
        const {
            name, email, phone, gender, dob,
            joiningDate, currentPlanId, status,
            trainerId: newTrainerIdValueFromBody, // Alias trainerId from body for clarity
            goal
        } = req.body;

        // Validate ID formats
        if (!mongoose.Types.ObjectId.isValid(branchId) || !mongoose.Types.ObjectId.isValid(memberId)) {
            return res.status(400).json({ success: false, message: 'Invalid Branch or Member ID format.' });
        }

        // Validate branch existence and authorization
        const branch = await Branch.findOne({ _id: branchId, gymOwner: gymOwnerId });
        if (!branch) {
            return res.status(404).json({ success: false, message: 'Branch not found or not authorized for this branch.' });
        }

        // Find the member to update and ensure authorization
        let member = await Member.findOne({ _id: memberId, branchId: branchId, gymOwner: gymOwnerId });
        if (!member) {
            return res.status(404).json({ success: false, message: 'Member not found in this branch or not authorized.' });
        }

        // Prepare fields to update and history entries
        const updatedFields = {};
        const historyEntries = [];
        const todayForHistory = getTodayDateStringBackend();

        // Store old trainer info for history logging
        const oldTrainerId = member.trainerId ? member.trainerId.toString() : null;
        const oldTrainerName = member.trainerName;

        // --- Update Standard Fields and Log History ---

        // Update Name if changed
        if (name !== undefined && name.trim() !== '' && name.trim() !== member.name) {
            updatedFields.name = name.trim();
            historyEntries.push({ date: todayForHistory, event: 'Info Update', details: `Name changed from "${member.name}" to "${updatedFields.name}".`});
        }

        // Update Email if changed, with validation
        if (email !== undefined && email !== member.email) {
            if (email && email.trim() !== "") {
                const emailRegex = /^\w+([.-]?\w+)*@\w+([.-]?\w+)*(\.\w{2,3})+$/;
                if (!emailRegex.test(email)) return res.status(400).json({ success: false, message: 'Invalid email format.' });
                // Check if the new email already exists for another member of this gym owner
                const existingMemberByEmail = await Member.findOne({ email, gymOwner: gymOwnerId, _id: { $ne: member._id } });
                if (existingMemberByEmail) return res.status(400).json({ success: false, message: `Another member with email ${email} already exists for this gym owner.` });
                updatedFields.email = email;
            } else {
                updatedFields.email = null; // Allow clearing email
            }
            historyEntries.push({ date: todayForHistory, event: 'Info Update', details: `Email updated.`});
        }

        // Update Phone if changed, prevent empty phone
        if (phone !== undefined && phone.trim() !== '' && phone.trim() !== member.phone) {
            updatedFields.phone = phone.trim();
            historyEntries.push({ date: todayForHistory, event: 'Info Update', details: `Phone updated.`});
        } else if (phone !== undefined && phone.trim() === '' && member.phone) { // Prevent phone from being empty if it was set
              return res.status(400).json({ success: false, message: 'Phone number cannot be empty.' });
        }

        // Update Gender if changed
        if (gender !== undefined && gender !== member.gender) {
            updatedFields.gender = gender;
            historyEntries.push({ date: todayForHistory, event: 'Info Update', details: `Gender changed to ${gender}.`});
        }

        // Update Date of Birth if changed, with validation
        if (dob !== undefined && dob !== member.dob) {
            if (dob && dob.trim() !== "" && (typeof dob !== 'string' || !dob.match(/^\d{4}-\d{2}-\d{2}$/))) {
                return res.status(400).json({ success: false, message: 'Invalid date of birth format. Please use YYYY-MM-DD.' });
            }
            updatedFields.dob = dob && dob.trim() !== "" ? dob : null; // Allow clearing DOB
            historyEntries.push({ date: todayForHistory, event: 'Info Update', details: `DOB updated.`});
        }

        // Update Status if changed
        if (status !== undefined && status !== member.status) {
            updatedFields.status = status;
            historyEntries.push({ date: todayForHistory, event: 'Status Change', details: `Status changed from "${member.status}" to "${status}".`});
        }

        // Update Goal if changed
        if (goal !== undefined && goal !== member.goal) {
            updatedFields.goal = goal || null; // Allow clearing goal
            historyEntries.push({ date: todayForHistory, event: 'Info Update', details: `Goal updated.`});
        }

        // --- Handle Subscription Plan and Joining Date Updates ---
        const hasJoiningDateChanged = joiningDate && joiningDate !== member.joiningDate;
        const hasSubscriptionPackChanged = currentPlanId && currentPlanId !== member.currentPlanId;

        // If either joining date or subscription pack has changed, recalculate end date and update related fields
        if (hasJoiningDateChanged || hasSubscriptionPackChanged) {
            const newJoiningDate = hasJoiningDateChanged ? joiningDate : member.joiningDate;
            const newSubPackId = hasSubscriptionPackChanged ? currentPlanId : member.currentPlanId;

            // Get details of the new/current subscription pack
            const newPackDetails = getPackDetailsLocalBackend(newSubPackId);
            if (!newPackDetails) {
                 return res.status(400).json({ success: false, message: `Invalid subscription plan ID (${newSubPackId}) for update.` });
            }

            // Validate new joining date format if it changed
            if (hasJoiningDateChanged && (typeof newJoiningDate !== 'string' || !newJoiningDate.match(/^\d{4}-\d{2}-\d{2}$/))) {
                return res.status(400).json({ success: false, message: 'Invalid joining date format for update. Please use YYYY-MM-DD.' });
            }

            updatedFields.joiningDate = newJoiningDate;
            const packDurationMonths = newPackDetails.durationMonths;
            if (isNaN(packDurationMonths) || packDurationMonths <= 0) {
                 return res.status(400).json({ success: false, message: 'Invalid subscription plan duration for update.' });
            }

            // Calculate new end date and payment due date based on the new joining date and plan duration
            updatedFields.currentPlanId = newSubPackId;
            updatedFields.endDate = getFutureDateBackend(packDurationMonths, updatedFields.joiningDate);
            updatedFields.paymentDueDate = updatedFields.endDate; // Payment due date is the same as end date for this scenario
            updatedFields.lastPaymentDate = updatedFields.joiningDate; // Assume payment is made on the new joining/change date

            // Add history entries for subscription change and payment
            historyEntries.push({
                date: updatedFields.joiningDate, event: 'Subscription Change',
                details: `Subscription changed to ${newPackDetails.name}. Valid from ${updatedFields.joiningDate} to ${updatedFields.endDate}.`,
                planId: newSubPackId, planName: newPackDetails.name
            });
            historyEntries.push({
                date: updatedFields.joiningDate, event: 'Payment', // Log a payment for the new/changed plan
                details: `Payment for updated subscription: ${newPackDetails.name}.`,
                amountPaid: newPackDetails.price,
                planId: newSubPackId, planName: newPackDetails.name
            });
        }

        // --- Handle Trainer Assignment Update ---
        let trainerAssignmentActuallyChanged = false;
        // Check if trainerId was explicitly sent in the request body (even if null or empty string)
        if (req.body.hasOwnProperty('trainerId')) {
            let desiredNewTrainerId = newTrainerIdValueFromBody; // This is what comes from frontend (ID string, "", or null)

            // Normalize desiredNewTrainerId: empty string means null (unassign)
            if (desiredNewTrainerId === "") {
                desiredNewTrainerId = null;
            }

            // Convert desired new trainer ID to string for comparison
            const desiredNewTrainerIdString = desiredNewTrainerId ? desiredNewTrainerId.toString() : null;

            // Check if the desired new trainer ID is different from the old one
            if (desiredNewTrainerIdString !== oldTrainerId) {
                trainerAssignmentActuallyChanged = true;

                if (desiredNewTrainerId && mongoose.Types.ObjectId.isValid(desiredNewTrainerId)) {
                    // If a valid new trainer ID is provided, find the trainer
                    const newTrainer = await Trainer.findOne({ _id: desiredNewTrainerId, gymOwner: gymOwnerId, branchId: branchId });
                    if (!newTrainer) {
                        return res.status(404).json({ success: false, message: 'New trainer not found in this branch or not authorized.' });
                    }
                    // Update member's trainer fields
                    updatedFields.trainerId = newTrainer._id;
                    updatedFields.trainerName = newTrainer.name; // CRITICAL: Update trainerName
                    // Add history entry for trainer assignment
                    historyEntries.push({ date: todayForHistory, event: 'Trainer Assigned', details: `Assigned to Trainer ${newTrainer.name}.` });

                    // Update the new trainer's history
                    newTrainer.history.unshift({ date: todayForHistory, event: 'Assigned to Member', details: `Assigned to member ${member.name} (ID: ${member.displayMemberId}).`, memberId: member._id.toString(), memberName: member.name });
                    await newTrainer.save(); // Save the updated new trainer document

                } else if (desiredNewTrainerId === null) { // Explicitly unassigning trainer
                    // Clear member's trainer fields
                    updatedFields.trainerId = null;
                    updatedFields.trainerName = null; // CRITICAL: Clear trainerName
                    // Add history entry for trainer unassignment
                    historyEntries.push({ date: todayForHistory, event: 'Trainer Unassigned', details: `Trainer unassigned from ${oldTrainerName || 'previous trainer'}.` });
                } else if (desiredNewTrainerId) { // Invalid trainerId format (not null, not valid ObjectId)
                     return res.status(400).json({ success: false, message: 'Invalid Trainer ID format provided for assignment.' });
                }

                // If a trainer was previously assigned and the assignment has changed (either to a new trainer or to null)
                if (oldTrainerId) {
                    const oldTrainerDoc = await Trainer.findById(oldTrainerId);
                    if (oldTrainerDoc) {
                        // Add history entry to the old trainer's document
                        oldTrainerDoc.history.unshift({
                            date: todayForHistory,
                            event: 'Unassigned from Member',
                            details: `Unassigned from member ${member.name} (ID: ${member.displayMemberId})${updatedFields.trainerId ? ` (switched to ${updatedFields.trainerName})` : ''}.`,
                            memberId: member._id.toString(),
                            memberName: member.name
                        });
                        await oldTrainerDoc.save(); // Save the updated old trainer document
                    }
                }
            }
        }
        // If req.body does NOT have 'trainerId', no change to trainer assignment is intended.

        // --- Add History Entries to Updated Fields ---
        if (historyEntries.length > 0) {
            // Use $push with $each and $position to add new entries to the beginning of the history array
            updatedFields.$push = { history: { $each: historyEntries, $position: 0 } };
        }

        // --- Check if Any Actual Updatable Fields Were Changed ---
        // Count fields in updatedFields, excluding the $push operator for history
        const fieldsToUpdateCount = Object.keys(updatedFields).filter(key => key !== '$push').length;

        // If no fields were changed and trainer assignment didn't change, and subscription/joining date didn't change
        if (fieldsToUpdateCount === 0 && !trainerAssignmentActuallyChanged && !(hasJoiningDateChanged || hasSubscriptionPackChanged)) {
            // If there are history entries to push (e.g., an audit log without data change)
            if (historyEntries.length > 0 && updatedFields.$push) {
                 // Still perform the update just to add the history log
            } else {
                // No changes detected, return success without updating
                return res.status(200).json({ success: true, message: 'No changes detected.', member: member });
            }
        }

        // --- Perform the Database Update ---
        // Find the member by ID and update with the prepared fields
        const updatedMember = await Member.findByIdAndUpdate(
             memberId,
             updatedFields,
             { new: true, runValidators: true } // Return the updated document and run schema validators
        );

        // Check if update was successful
        if (!updatedMember) {
            // This case is unlikely if member was found before, but handle defensively
            return res.status(404).json({ success: false, message: 'Member update failed, member not found after update.' });
        }

        // --- Respond with Success ---
        res.status(200).json({
            success: true,
            message: `Member '${updatedMember.name}' (ID: ${updatedMember.displayMemberId}) updated successfully.`,
            member: updatedMember, // Send the fully updated member object
        });

    } catch (error) {
        // Log the error for server diagnostics
        console.error(`Error updating member ${req.params.memberId} in branch ${req.params.branchId}:`, error);

        // --- Handle Specific Errors ---
        // Mongoose validation errors
        if (error.name === 'ValidationError') {
            const messages = Object.values(error.errors).map(val => val.message);
            return res.status(400).json({ success: false, message: `Validation Error: ${messages.join(', ')}` });
        }
        // Duplicate key error for email
        if (error.code === 11000 && error.keyPattern && error.keyPattern.email) {
             // This check is also done before update, but included here as a fallback
            return res.status(400).json({ success: false, message: `Another member with email ${req.body.email} already exists for this gym owner.` });
        }
        // Cast error for invalid ObjectId formats
        if (error.name === 'CastError' && error.kind === 'ObjectId') {
            return res.status(400).json({ success: false, message: 'Invalid ID format for member, branch, or trainer.' });
        }
        // Handle other server errors
        res.status(500).json({ success: false, message: 'Server Error: Could not update member.' });
    }
};

/**
 * @desc Delete a member from a specific branch
 * @route DELETE /api/branches/:branchId/members/:memberId
 * @access Private (Gym Owner)
 */
export const deleteMemberFromBranch = async (req, res) => {
    try {
        // Extract branch and member IDs from parameters, gym owner ID from user
        const { branchId, memberId } = req.params;
        const gymOwnerId = req.user._id;

        // Validate ID formats
        if (!mongoose.Types.ObjectId.isValid(branchId) || !mongoose.Types.ObjectId.isValid(memberId)) {
            return res.status(400).json({ success: false, message: 'Invalid Branch or Member ID format.' });
        }

        // Find the member to delete and ensure authorization
        const member = await Member.findOne({ _id: memberId, branchId: branchId, gymOwner: gymOwnerId });
        if (!member) {
            return res.status(404).json({ success: false, message: 'Member not found in this branch or not authorized.' });
        }

        // --- Update Trainer's History if Member was Assigned to a Trainer ---
        if (member.trainerId) {
            const trainer = await Trainer.findById(member.trainerId);
            if (trainer) {
                // Add a history entry to the trainer's document indicating the member was deleted
                trainer.history.unshift({
                    date: getTodayDateStringBackend(), event: 'Unassigned from Member',
                    details: `Member ${member.name} (Display ID: ${member.displayMemberId}) was deleted.`,
                    memberId: member._id.toString(), // Store member ID as string
                    memberName: member.name
                });
                await trainer.save(); // Save the updated trainer document
            }
        }

        // --- Delete the Member from the Database ---
        await Member.findByIdAndDelete(memberId);

        // --- Respond with Success ---
        res.status(200).json({
            success: true,
            message: `Member '${member.name}' (ID: ${member.displayMemberId}) deleted successfully.`,
            memberId: memberId // Send back the ID of the deleted member
        });

    } catch (error) {
        // Log the error for server diagnostics
        console.error(`Error deleting member ${req.params.memberId} from branch ${req.params.branchId}:`, error);

        // --- Handle Specific Errors ---
        // Cast error for invalid ObjectId formats
        if (error.name === 'CastError' && error.kind === 'ObjectId') {
            return res.status(400).json({ success: false, message: 'Invalid ID format for member or branch.' });
        }
        // Handle other server errors
        res.status(500).json({ success: false, message: 'Server Error: Could not delete member.' });
    }
};

/**
 * @desc Renew a member's subscription
 * @route PUT /api/branches/:branchId/members/:memberId/renew
 * @access Private (Gym Owner)
 */
export const renewMemberSubscription = async (req, res) => {
    try {
        // Extract branch and member IDs from parameters, gym owner ID from user
        const { branchId, memberId } = req.params;
        const gymOwnerId = req.user._id;
        // Extract the new subscription pack ID from the body (optional, defaults to current)
        const { newSubscriptionPackId } = req.body;
        const todayStr = getTodayDateStringBackend();

        // Validate ID formats
        if (!mongoose.Types.ObjectId.isValid(branchId) || !mongoose.Types.ObjectId.isValid(memberId)) {
            return res.status(400).json({ success: false, message: 'Invalid Branch or Member ID format.' });
        }

        // Find the member to renew and ensure authorization
        const member = await Member.findOne({ _id: memberId, branchId: branchId, gymOwner: gymOwnerId });
        if (!member) {
            return res.status(404).json({ success: false, message: 'Member not found in this branch or not authorized.' });
        }

        // Determine which plan to renew with (new plan ID from body or current plan ID)
        const planIdToRenewWith = newSubscriptionPackId || member.currentPlanId;

        // Get details of the subscription pack
        const packDetails = getPackDetailsLocalBackend(planIdToRenewWith);
        if (!packDetails) {
            return res.status(400).json({ success: false, message: `Subscription plan (ID: ${planIdToRenewWith}) is invalid or not found.` });
        }

        // Validate pack duration
        const packDurationMonths = packDetails.durationMonths;
        if (isNaN(packDurationMonths) || packDurationMonths <= 0) {
            return res.status(400).json({ success: false, message: 'Invalid duration for the subscription plan.' });
        }

        // --- Determine Renewal Start Date ---
        let renewalStartDate = todayStr; // Default: renewal starts from today

        // If the member is currently active AND their current subscription end date is in the future or today
        if (member.status === 'Active' && member.endDate && new Date(member.endDate) >= new Date(todayStr)) {
            // Renewal starts the day AFTER the current end date
            let tempStartDate = new Date(Date.UTC(
                parseInt(member.endDate.substring(0,4)), // Year
                parseInt(member.endDate.substring(5,7)) - 1, // Month (0-indexed)
                parseInt(member.endDate.substring(8,10)) // Day
            ));
            tempStartDate.setUTCDate(tempStartDate.getUTCDate() + 1); // Add one day
            renewalStartDate = formatDateToYYYYMMDD(tempStartDate); // Format the new start date
        }
        // Otherwise (expired, inactive, or active but end date is past), renewal starts from today.

        // --- Calculate New End Date and Payment Due Date ---
        const newEndDate = getFutureDateBackend(packDurationMonths, renewalStartDate);
        const newPaymentDueDate = newEndDate; // Payment due date is the same as the new end date

        // --- Prepare History Entries ---
        // Determine the event type for history based on current status
        const historyEventText = (member.status === 'Expired' || (member.endDate && new Date(member.endDate) < new Date(todayStr))) ? 'Renewal' : 'Payment & Extension';
        const historyDetails = `Subscription ${historyEventText.toLowerCase()} for ${packDetails.name}. Valid from ${renewalStartDate} to ${newEndDate}.`;

        // History entry for the payment
        const paymentHistoryEntry = {
            date: todayStr, // Payment is made today
            event: 'Payment',
            details: `Payment received for ${packDetails.name} (${historyEventText}).`,
            amountPaid: packDetails.price,
            planId: planIdToRenewWith, planName: packDetails.name
        };
        // History entry for the renewal/extension event
        const renewalHistoryEntry = {
            date: todayStr, // Event (renewal/extension) is logged today
            event: historyEventText,
            details: historyDetails,
            planId: planIdToRenewWith, planName: packDetails.name
        };

        // --- Update Member Document ---
        member.status = 'Active'; // Member becomes active upon renewal/payment
        member.endDate = newEndDate; // Set the new subscription end date
        member.paymentDueDate = newPaymentDueDate; // Set the new payment due date
        member.lastPaymentDate = todayStr; // Record today as the last payment date
        member.currentPlanId = planIdToRenewWith; // Update the current plan ID

        // Add the new history entries to the beginning of the history array
        member.history.unshift(paymentHistoryEntry, renewalHistoryEntry);

        // Save the updated member document
        const updatedMember = await member.save();

        // --- Respond with Success ---
        res.status(200).json({
            success: true,
            message: `Member '${member.name}' (ID: ${updatedMember.displayMemberId}) subscription ${historyEventText.toLowerCase()} successfully. New end date: ${newEndDate}.`,
            member: updatedMember, // Send the full updated member object
        });

    } catch (error) {
        // Log the error for server diagnostics
        console.error(`Error renewing member ${req.params.memberId} subscription:`, error);

        // --- Handle Specific Errors ---
        // Cast error for invalid ObjectId formats
        if (error.name === 'CastError' && error.kind === 'ObjectId') {
            return res.status(400).json({ success: false, message: 'Invalid ID format for member or branch.' });
        }
        // Handle other server errors
        res.status(500).json({ success: false, message: 'Server Error: Could not renew member subscription.' });
    }
};
