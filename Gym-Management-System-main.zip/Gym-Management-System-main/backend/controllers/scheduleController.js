// File: gymsystem/backend/controllers/scheduleController.js

// Import necessary models
import ScheduledClass from '../models/ScheduledClass.js'; // Your ScheduledClass model
import Branch from '../models/Branch.js';   // To verify branch ownership
import mongoose from 'mongoose'; // Import mongoose for ObjectId validation

// --- Utility function ---

/**
 * @desc Formats a Date object or a YYYY-MM-DD string into a YYYY-MM-DD string.
 * @param {Date|string} date - The date to format.
 * @returns {string} The formatted date string (YYYY-MM-DD), or an empty string if invalid.
 */
const formatDateToYYYYMMDD = (date) => {
    // Check if the input is a valid Date object
    if (date instanceof Date && !isNaN(date.getTime())) {
        const year = date.getFullYear();
        const month = String(date.getMonth() + 1).padStart(2, '0'); // Months are 0-indexed
        const day = String(date.getDate()).padStart(2, '0');
        return `${year}-${month}-${day}`;
    }
    // Check if the input is already a valid YYYY-MM-DD string
    if (typeof date === 'string' && /^\d{4}-\d{2}-\d{2}$/.test(date)) {
        return date; // Return as is if it matches the format
    }
    // Return empty string for invalid input
    return '';
};

// --- Controller Functions ---

/**
 * @desc Add a new scheduled class to a specific branch for the authenticated gym owner
 * @route POST /api/branches/:branchId/schedule
 * @access Private (Gym Owner)
 */
export const addClassToBranch = async (req, res) => {
    try {
        // Extract branch ID from parameters and gym owner ID from authenticated user
        const { branchId } = req.params;
        const gymOwnerId = req.user._id;

        // Extract class details from the request body
        const {
            title,
            description,
            date,
            time,
            imageUrl,
            status, // Status for new class is usually 'upcoming' by default, handled later
        } = req.body;

        // --- Basic Input Validation ---
        if (!title || !description || !date || !time) {
            return res.status(400).json({ success: false, message: 'Title, description, date, and time are required for the class.' });
        }

        // Validate date format (YYYY-MM-DD)
        if (typeof date !== 'string' || !date.match(/^\d{4}-\d{2}-\d{2}$/)) {
            return res.status(400).json({ success: false, message: 'Invalid class date format. Please use YYYY-MM-DD.' });
        }

        // Validate time format (HH:MM 24-hour)
        if (typeof time !== 'string' || !time.match(/^([01]\d|2[0-3]):([0-5]\d)$/)) {
            return res.status(400).json({ success: false, message: 'Invalid class time format. Please use HH:MM (24-hour).' });
        }

        // Validate branch existence and authorization
        const branch = await Branch.findOne({ _id: branchId, gymOwner: gymOwnerId });
        if (!branch) {
            return res.status(404).json({ success: false, message: 'Branch not found or you are not authorized for this branch.' });
        }

        // --- Create New Scheduled Class Object ---
        const newScheduledClassData = {
            title,
            description,
            date,
            time,
            imageUrl: imageUrl || null, // Store null if imageUrl is not provided
            status: status || 'upcoming', // Default status to 'upcoming'
            branchId,
            gymOwner: gymOwnerId,
        };

        // --- Save New Scheduled Class to Database ---
        const newClass = await ScheduledClass.create(newScheduledClassData);

        // --- Respond with Success ---
        res.status(201).json({
            success: true,
            message: `Class '${title}' scheduled successfully for branch '${branch.name}'!`,
            scheduledClass: newClass, // Send the full new class object back
        });

    } catch (error) {
        // Log the error for server diagnostics
        console.error(`Error adding class to branch ${req.params.branchId}:`, error);

        // --- Handle Specific Errors ---
        // Mongoose validation errors
        if (error.name === 'ValidationError') {
            const messages = Object.values(error.errors).map(val => val.message);
            return res.status(400).json({ success: false, message: `Validation Error: ${messages.join(', ')}` });
        }
        // Handle other server errors
        res.status(500).json({ success: false, message: 'Server Error: Could not schedule class.' });
    }
};

/**
 * @desc Get all scheduled classes for a specific branch for the authenticated gym owner
 * @route GET /api/branches/:branchId/schedule
 * @access Private (Gym Owner)
 */
export const getClassesByBranch = async (req, res) => {
    try {
        // Extract branch ID from parameters and gym owner ID from authenticated user
        const { branchId } = req.params;
        const gymOwnerId = req.user._id;

        // Validate Branch ID format
        if (!mongoose.Types.ObjectId.isValid(branchId)) {
             return res.status(400).json({ success: false, message: 'Invalid branch ID format.' });
        }

        // Validate branch existence and authorization
        const branch = await Branch.findOne({ _id: branchId, gymOwner: gymOwnerId });
        if (!branch) {
            return res.status(404).json({ success: false, message: 'Branch not found or you are not authorized for this branch.' });
        }

        // Find all scheduled classes for the specified branch and gym owner, sorted by date and time
        const classes = await ScheduledClass.find({ branchId: branchId, gymOwner: gymOwnerId })
                                            .sort({ date: 1, time: 1 });

        // --- Respond with the list of classes ---
        res.status(200).json({
            success: true,
            count: classes.length,
            scheduledClasses: classes, // Send the list of scheduled classes
        });

    } catch (error) {
        // Log the error for server diagnostics
        console.error(`Error fetching classes for branch ${req.params.branchId}:`, error);

        // --- Handle Specific Errors ---
        // Cast error for invalid ObjectId format
        if (error.name === 'CastError' && error.kind === 'ObjectId') {
             return res.status(400).json({ success: false, message: 'Invalid branch ID format.' });
        }
        // Handle other server errors
        res.status(500).json({ success: false, message: 'Server Error: Could not fetch scheduled classes.' });
    }
};

/**
 * @desc Update an existing scheduled class in a specific branch
 * @route PUT /api/branches/:branchId/schedule/:classId
 * @access Private (Gym Owner)
 */
export const updateScheduledClass = async (req, res) => {
    try {
        // Extract branch and class IDs from parameters, gym owner ID from user
        const { branchId, classId } = req.params;
        const gymOwnerId = req.user._id;

        // Extract update fields from the request body
        const { title, description, date, time, imageUrl, status } = req.body;

        // Validate branch existence and authorization
        const branch = await Branch.findOne({ _id: branchId, gymOwner: gymOwnerId });
        if (!branch) {
            return res.status(404).json({ success: false, message: 'Branch not found or not authorized.' });
        }

        // Find the class to update and ensure authorization
        let scheduledClass = await ScheduledClass.findOne({ _id: classId, branchId: branchId, gymOwner: gymOwnerId });
        if (!scheduledClass) {
            return res.status(404).json({ success: false, message: 'Scheduled class not found or not authorized.' });
        }

        // --- Apply Updates to the Class Document ---
        // Update fields only if they are provided in the request body
        if (title !== undefined) scheduledClass.title = title;
        if (description !== undefined) scheduledClass.description = description;

        // Update date with validation if provided
        if (date !== undefined) {
            if (typeof date !== 'string' || !date.match(/^\d{4}-\d{2}-\d{2}$/)) {
                return res.status(400).json({ success: false, message: 'Invalid class date format. Please use YYYY-MM-DD.' });
            }
            scheduledClass.date = date;
        }

        // Update time with validation if provided
        if (time !== undefined) {
            if (typeof time !== 'string' || !time.match(/^([01]\d|2[0-3]):([0-5]\d)$/)) {
                return res.status(400).json({ success: false, message: 'Invalid class time format. Please use HH:MM (24-hour).' });
            }
            scheduledClass.time = time;
        }

        // Update imageUrl (allow setting to null/empty string)
        if (imageUrl !== undefined) scheduledClass.imageUrl = imageUrl;

        // Update status with validation if provided
        if (status !== undefined) {
            const validStatuses = ['upcoming', 'completed', 'cancelled'];
            if (!validStatuses.includes(status)) {
                 return res.status(400).json({ success: false, message: `Invalid status value. Must be one of: ${validStatuses.join(', ')}.` });
            }
            scheduledClass.status = status;
        }

        // --- Save the Updated Class Document ---
        const updatedClass = await scheduledClass.save();

        // --- Respond with Success ---
        res.status(200).json({
            success: true,
            message: `Class '${updatedClass.title}' updated successfully.`,
            scheduledClass: updatedClass, // Send the fully updated class object
        });

    } catch (error) {
        // Log the error for server diagnostics
        console.error(`Error updating scheduled class ${req.params.classId}:`, error);

        // --- Handle Specific Errors ---
        // Mongoose validation errors
        if (error.name === 'ValidationError') {
            const messages = Object.values(error.errors).map(val => val.message);
            return res.status(400).json({ success: false, message: `Validation Error: ${messages.join(', ')}` });
        }
        // Cast error for invalid ObjectId formats
        if (error.name === 'CastError' && error.kind === 'ObjectId') {
             return res.status(400).json({ success: false, message: 'Invalid ID format.' });
        }
        // Handle other server errors
        res.status(500).json({ success: false, message: 'Server Error: Could not update scheduled class.' });
    }
};

/**
 * @desc Delete a scheduled class from a specific branch
 * @route DELETE /api/branches/:branchId/schedule/:classId
 * @access Private (Gym Owner)
 */
export const deleteScheduledClass = async (req, res) => {
    try {
        // Extract branch and class IDs from parameters, gym owner ID from user
        const { branchId, classId } = req.params;
        const gymOwnerId = req.user._id;

        // Validate branch existence and authorization
        const branch = await Branch.findOne({ _id: branchId, gymOwner: gymOwnerId });
        if (!branch) {
            return res.status(404).json({ success: false, message: 'Branch not found or not authorized.' });
        }

        // Find the class to delete and ensure authorization
        const scheduledClass = await ScheduledClass.findOne({ _id: classId, branchId: branchId, gymOwner: gymOwnerId });
        if (!scheduledClass) {
            return res.status(404).json({ success: false, message: 'Scheduled class not found or not authorized.' });
        }

        // --- Delete the Scheduled Class from the Database ---
        await ScheduledClass.findByIdAndDelete(classId);

        // --- Respond with Success ---
        res.status(200).json({
            success: true,
            message: `Class '${scheduledClass.title}' deleted successfully.`,
            classId: classId // Send back ID for frontend state update
        });

    } catch (error) {
        // Log the error for server diagnostics
        console.error(`Error deleting scheduled class ${req.params.classId}:`, error);

        // --- Handle Specific Errors ---
        // Cast error for invalid ObjectId formats
        if (error.name === 'CastError' && error.kind === 'ObjectId') {
             return res.status(400).json({ success: false, message: 'Invalid ID format.' });
        }
        // Handle other server errors
        res.status(500).json({ success: false, message: 'Server Error: Could not delete scheduled class.' });
    }
};

/**
 * @desc Mark a scheduled class as complete
 * @route PUT /api/branches/:branchId/schedule/:classId/complete
 * @access Private (Gym Owner)
 */
export const markClassAsComplete = async (req, res) => {
    try {
        // Extract branch and class IDs from parameters, gym owner ID from user
        const { branchId, classId } = req.params;
        const gymOwnerId = req.user._id;

        // Validate branch existence and authorization
        const branch = await Branch.findOne({ _id: branchId, gymOwner: gymOwnerId });
        if (!branch) {
            return res.status(404).json({ success: false, message: 'Branch not found or not authorized.' });
        }

        // Find the class to update and ensure authorization
        const scheduledClass = await ScheduledClass.findOne({ _id: classId, branchId: branchId, gymOwner: gymOwnerId });
        if (!scheduledClass) {
            return res.status(404).json({ success: false, message: 'Scheduled class not found or not authorized.' });
        }

        // Check if the class is already complete
        if (scheduledClass.status === 'completed') {
            return res.status(400).json({ success: false, message: 'Class is already marked as complete.' });
        }

        // --- Update Class Status to 'completed' ---
        scheduledClass.status = 'completed';
        const updatedClass = await scheduledClass.save();

        // --- Respond with Success ---
        res.status(200).json({
            success: true,
            message: `Class '${updatedClass.title}' marked as complete.`,
            scheduledClass: updatedClass, // Send the fully updated class object
        });

    } catch (error) {
        // Log the error for server diagnostics
        console.error(`Error marking class ${req.params.classId} as complete:`, error);

        // --- Handle Specific Errors ---
        // Cast error for invalid ObjectId formats
        if (error.name === 'CastError' && error.kind === 'ObjectId') {
             return res.status(400).json({ success: false, message: 'Invalid ID format.' });
        }
        // Handle other server errors
        res.status(500).json({ success: false, message: 'Server Error: Could not mark class as complete.' });
    }
};
