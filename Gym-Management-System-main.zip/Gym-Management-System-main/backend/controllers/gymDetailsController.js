// File: gymsystem/backend/controllers/gymDetailsController.js

// Import the necessary models
import GymRegistrationInfo from '../models/GymRegistrationInfo.js'; // Although imported, this model is not used in the provided function.
import Branch from '../models/Branch.js';

/**
 * @desc Get details for the authenticated gym owner, including their branches
 * @route GET /api/gymdetails
 * @access Private (Gym Owner)
 */
export const getMyGymDetails = async (req, res) => {
  try {
    // Get the authenticated user object from the request
    const gymUser = req.user;

    // Check if the user object exists (authentication middleware should handle this, but a check is included)
    if (gymUser) {
      // Find all branches associated with the authenticated gym owner, sorted by creation date
      const userBranches = await Branch.find({ gymOwner: gymUser._id }).sort({ createdAt: 'asc' });

      // Respond with the gym owner's details and their branches
      res.status(200).json({
        success: true,
        details: {
          id: gymUser._id,
          ownerName: gymUser.ownerName,
          gymName: gymUser.gymName,
          email: gymUser.email,
          branches: userBranches.map(branch => ({
            id: branch._id,
            name: branch.name,
          })),
        },
      });
    } else {
      // If user somehow not found (should be caught by auth middleware)
      res.status(404).json({ success: false, message: 'User not found.' });
    }
  } catch (error) {
    // Log server error for diagnostics
    console.error('Error fetching gym details and branches:', error);

    // Handle server errors
    res.status(500).json({ success: false, message: 'Server error while fetching gym details.' });
  }
};
