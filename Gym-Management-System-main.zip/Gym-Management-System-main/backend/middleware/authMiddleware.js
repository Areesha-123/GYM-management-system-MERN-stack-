// File: gymsystem/backend/middleware/authMiddleware.js

// Import necessary libraries and models
import jwt from 'jsonwebtoken';
import GymRegistrationInfo from '../models/GymRegistrationInfo.js'; // Import your User model

/**
 * @desc Middleware to protect routes, ensuring only authenticated users can access them.
 * Extracts and verifies JWT from the Authorization header.
 * Attaches the authenticated user object to the request (`req.user`).
 * @param {object} req - Express request object
 * @param {object} res - Express response object
 * @param {function} next - Express next middleware function
 * @access Private
 */
export const protectRoute = async (req, res, next) => {
    let token; // Variable to hold the extracted token

    // Check if the Authorization header exists and starts with 'Bearer'
    if (req.headers.authorization && req.headers.authorization.startsWith('Bearer')) {
        try {
            // Extract the token string (remove 'Bearer ' prefix)
            token = req.headers.authorization.split(' ')[1];

            // Verify the token using the JWT secret
            const decodedToken = jwt.verify(token, process.env.JWT_SECRET);

            // Fetch user details from the database using the ID from the decoded token
            // Exclude the password field for security
            req.user = await GymRegistrationInfo.findById(decodedToken.id).select('-password');

            // Check if the user exists (token was valid but user might have been deleted)
            if (!req.user) {
                // Respond with 401 if the user associated with the token is not found
                return res.status(401).json({ success: false, message: 'Not authorized, user for this token no longer exists.' });
            }

            // If token is valid and user exists, proceed to the next middleware or route handler
            next();

        } catch (error) {
            // Log token verification errors (e.g., expired, malformed, invalid signature) for server diagnostics
            console.error('Token verification failed in protectRoute middleware:', error.message);
            // Respond with 401 if token verification fails
            return res.status(401).json({ success: false, message: 'Not authorized, token failed or expired.' });
        }
    }

    // If no token was found in the Authorization header
    if (!token) {
        // Respond with 401 indicating no token was provided
        return res.status(401).json({ success: false, message: 'Not authorized, no token provided.' });
    }
};
