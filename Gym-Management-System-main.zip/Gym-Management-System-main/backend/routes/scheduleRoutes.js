import express from 'express';
import {
    addClassToBranch,
    getClassesByBranch,
    updateScheduledClass,
    deleteScheduledClass,
    markClassAsComplete,
} from '../controllers/scheduleController.js';
import { protectRoute } from '../middleware/authMiddleware.js';

const router = express.Router({ mergeParams: true });

router.use(protectRoute);

router.route('/')
    .post(addClassToBranch)
    .get(getClassesByBranch);

router.route('/:classId')
    .put(updateScheduledClass)
    .delete(deleteScheduledClass);

router.route('/:classId/complete')
    .put(markClassAsComplete);

export default router;
