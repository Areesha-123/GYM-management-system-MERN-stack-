import express from 'express';

import {
  handleNewGymRegistration,
  handleGymUserLogin
} from '../controllers/gymRegistrationHandler.js';

const router = express.Router();

router.post('/submit', handleNewGymRegistration);

router.post('/login', handleGymUserLogin);

export default router;
