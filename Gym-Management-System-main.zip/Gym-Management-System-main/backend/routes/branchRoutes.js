import express from 'express';
import { addBranch, getMyBranches, deleteBranch } from '../controllers/branchController.js';
import { protectRoute } from '../middleware/authMiddleware.js';

import memberRoutes from './memberRoutes.js';
import trainerRoutes from './trainerRoutes.js';
import scheduleRoutes from './scheduleRoutes.js';

const router = express.Router();

router.use('/:branchId/members', memberRoutes);

router.use('/:branchId/trainers', trainerRoutes);

router.use('/:branchId/schedule', scheduleRoutes);

router.route('/')
  .post(protectRoute, addBranch)
  .get(protectRoute, getMyBranches);

router.route('/:branchId')
  .delete(protectRoute, deleteBranch);

export default router;
