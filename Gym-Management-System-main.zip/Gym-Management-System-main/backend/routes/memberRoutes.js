import express from 'express';
import {
    addMemberToBranch,
    getMembersByBranch,
    updateMemberInBranch,
    deleteMemberFromBranch,
    renewMemberSubscription
} from '../controllers/memberController.js';
import { protectRoute } from '../middleware/authMiddleware.js';
import Member from '../models/Member.js';
import mongoose from 'mongoose';

const router = express.Router({ mergeParams: true });

router.use(protectRoute);

router.route('/')
    .post(addMemberToBranch)
    .get(getMembersByBranch);

router.route('/:memberId')
    .get(async (req, res) => {
        try {
            if (!mongoose.Types.ObjectId.isValid(req.params.memberId)) {
                 return res.status(400).json({ success: false, message: 'Invalid Member ID format.' });
            }
            const member = await Member.findOne({
                _id: req.params.memberId,
                branchId: req.params.branchId,
                gymOwner: req.user._id
            });

            if (!member) {
                return res.status(404).json({ success: false, message: 'Member not found or not authorized for this branch.' });
            }
            res.json({ success: true, member });
        } catch (error) {
            res.status(500).json({ success: false, message: "Server error fetching member."});
        }
    })
    .put(updateMemberInBranch)
    .delete(deleteMemberFromBranch);

router.put('/:memberId/renew', renewMemberSubscription);

export default router;
