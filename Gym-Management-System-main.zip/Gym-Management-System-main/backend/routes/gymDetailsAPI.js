import express from 'express';
import { getMyGymDetails } from '../controllers/gymDetailsController.js';
import { protectRoute } from '../middleware/authMiddleware.js'; 

const router = express.Router();

router.get('/details', protectRoute, getMyGymDetails);

export default router;