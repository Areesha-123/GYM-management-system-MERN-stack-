import express from 'express';
import {
    addTrainerToBranch,
    getTrainersForBranch,
    getTrainerDetails,
    updateTrainerInBranch,
    deleteTrainerFromBranch,
    recordTrainerPayment,
    getTrainerPaymentHistory
} from '../controllers/trainerController.js';
import { protectRoute } from '../middleware/authMiddleware.js';

const router = express.Router({ mergeParams: true });

router.use(protectRoute);

router.route('/')
    .post(addTrainerToBranch)
    .get(getTrainersForBranch);

router.route('/:trainerId')
    .get(getTrainerDetails)
    .put(updateTrainerInBranch)
    .delete(deleteTrainerFromBranch);

router.route('/:trainerId/payments')
    .post(recordTrainerPayment)
    .get(getTrainerPaymentHistory);

export default router;
