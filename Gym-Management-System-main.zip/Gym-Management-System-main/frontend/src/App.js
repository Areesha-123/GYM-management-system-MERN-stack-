// App.js (Relevant parts only)
import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import WelcomePage from './pages/WelcomePage';
import LoginPage from './pages/LoginPage';
import RegisterPage from './pages/RegisterPage';
import DashboardScreen from './pages/DashboardScreen';
import Members from './pages/Members';
import Reports from './pages/Reports';
import ScheduleClass from './pages/ScheduleClass';
// *** Import the new Trainers component ***
import Trainers from './pages/Trainers'; // Adjust path if needed

function App() {
    return (
        <Router>
            <Routes>
                {/* --- Public Routes --- */}
                <Route path="/" element={<WelcomePage />} />
                <Route path="/login" element={<LoginPage />} />
                <Route path="/register" element={<RegisterPage />} />

                {/* --- Protected Dashboard Route with Nested Routes --- */}
                <Route path="/dashboard" element={<DashboardScreen />}>
                    {/* The DashboardScreen component uses <Outlet> */}
                    <Route path="members" element={<Members />} />
                    <Route path="reports" element={<Reports />} />
                    <Route path="schedule" element={<ScheduleClass />} />
                    {/* *** Add the route for the Trainers component *** */}
                    <Route path="trainers" element={<Trainers />} />
                    {/* <Route path="billing" element={<Billing />} /> */}
                    {/* Default/index route handled within DashboardScreen */}
                </Route>

                {/* --- Catch-all or Not Found Route (Optional) --- */}
                {/* <Route path="*" element={<NotFoundPage />} /> */}

            </Routes>
        </Router>
    );
}

export default App;