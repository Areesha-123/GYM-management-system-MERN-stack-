// File: frontend/src/pages/Trainers.jsx
import React, { useState, useEffect, useMemo, useCallback } from 'react';
import { useDashboardContext } from './DashboardScreen'; // Assuming DashboardScreen exports useDashboardContext
import '../styles/Trainers.css';
import {
    FiUserPlus, FiEdit, FiTrash2, FiUsers, FiUserCheck, FiUserX, FiBriefcase,
    FiDollarSign, FiCalendar, FiX, FiInfo, FiSearch, FiFilter,
    FiList, FiAward, FiUser, FiCheck, FiAlertTriangle, FiLoader, FiActivity, FiCreditCard,
    FiUserMinus, FiMapPin, FiMail, FiTrendingUp
} from 'react-icons/fi';

// --- UTILITY FUNCTIONS ---
const formatDateLocal = (dateString) => {
    if (!dateString) return 'N/A';
    try {
        let date = new Date(dateString);
        if (!isNaN(date.getTime())) {
            if (!dateString.includes('T') && dateString.match(/^\d{4}-\d{2}-\d{2}$/)) {
                const [year, month, day] = dateString.split('-').map(Number);
                date = new Date(Date.UTC(year, month - 1, day));
            }
            return date.toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric', timeZone: 'UTC' });
        }
        const parts = dateString.split(/[-/]/);
        if (parts.length === 3) {
            const utcDate = new Date(Date.UTC(parseInt(parts[0], 10), parseInt(parts[1], 10) - 1, parseInt(parts[2], 10)));
            if (!isNaN(utcDate.getTime())) {
                return utcDate.toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric', timeZone: 'UTC' });
            }
        }
        return dateString;
    } catch (e) {
        return dateString;
    }
};

const formatDateToYYYYMMDDLocal = (date) => {
    if (!(date instanceof Date) || isNaN(date)) {
        if (typeof date === 'string' && /^\d{4}-\d{2}-\d{2}$/.test(date)) {
            return date;
        }
        return '';
    }
    const year = date.getFullYear();
    const month = String(date.getMonth() + 1).padStart(2, '0');
    const day = String(date.getDate()).padStart(2, '0');
    return `${year}-${month}-${day}`;
};

const getCurrentAssignedMembersWithBranch = (trainerId, allMembersData, gymInfoData) => {
    let membersWithBranch = [];
    if (!trainerId || !allMembersData || !gymInfoData || !gymInfoData.branches) return [];
    for (const branchKey in allMembersData) {
        const branch = gymInfoData.branches.find(b => b.id === branchKey);
        const branchName = branch ? branch.name : 'Unknown Branch';
        // Ensure allMembersData[branchKey] and its list property are valid
        const membersInBranch = Array.isArray(allMembersData[branchKey]?.list) ? allMembersData[branchKey].list : [];

        membersInBranch
            .filter(member => member && member.trainerId === trainerId)
            .forEach(member => {
                membersWithBranch.push({ ...member, branchName });
            });
    }
    return membersWithBranch;
};

const getPastAssignedMembersFromHistory = (trainerHistory) => {
    if (!Array.isArray(trainerHistory)) return [];
    const pastAssignments = {};
    [...trainerHistory]
        .sort((a, b) => {
            try {
                const dateA = new Date(a.date.includes('T') ? a.date : a.date + 'T00:00:00Z');
                const dateB = new Date(b.date.includes('T') ? b.date : b.date + 'T00:00:00Z');
                return dateB.getTime() - dateA.getTime();
            } catch { return 0; }
        })
        .forEach(item => {
            if (item.event === 'Unassigned from Member' && item.memberId && !pastAssignments[item.memberId]) {
                pastAssignments[item.memberId] = {
                    memberId: item.memberId,
                    memberName: item.memberName || 'Unknown Member',
                    unassignedDate: item.date,
                    details: item.details
                };
            } else if (item.event === 'Trainer Unassigned' && item.details && !pastAssignments[item.memberId]) {
                const matchId = item.details.match(/member (\w+)/i);
                const matchName = item.details.match(/member ([^(]+)/i);
                const memberId = matchId ? matchId[1] : null;
                const memberName = matchName ? matchName[1].trim() : 'Unknown Member';
                if(memberId && !pastAssignments[memberId]){
                    pastAssignments[memberId] = {
                        memberId: memberId, memberName: memberName,
                        unassignedDate: item.date, details: item.details
                    };
                }
            }
        });
    return Object.values(pastAssignments)
        .sort((a,b) => {
             try {
                const dateA = new Date(a.unassignedDate.includes('T') ? a.unassignedDate : a.unassignedDate + 'T00:00:00Z');
                const dateB = new Date(b.unassignedDate.includes('T') ? b.unassignedDate : b.unassignedDate + 'T00:00:00Z');
                return dateB.getTime() - dateA.getTime();
            } catch { return 0; }
        });
};

const getCurrentMonthYYYYMM = () => {
    const today = new Date();
    const year = today.getFullYear();
    const month = String(today.getMonth() + 1).padStart(2, '0');
    return `${year}-${month}`;
};

const calculateSalaryDueDate = (yearMonth) => {
    if (!yearMonth || !yearMonth.includes('-')) return 'N/A';
    try {
        const [year, month] = yearMonth.split('-').map(Number);
        const dueDate = new Date(Date.UTC(year, month, 1));
        return dueDate.toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric', timeZone: 'UTC' });
    } catch (e) {
        return 'N/A';
    }
};

const formatCurrencyLocal = (amount, currency = 'PKR') => {
    const numericAmount = Number(amount);
    return new Intl.NumberFormat('en-PK', {
        style: 'currency',
        currency: currency,
        minimumFractionDigits: 0,
        maximumFractionDigits: 2,
    }).format(isNaN(numericAmount) ? 0 : numericAmount);
};
// --- END OF UTILITY FUNCTIONS ---

function Trainers() {
    const {
        gymInfo,
        allTrainers: allTrainersFromContext,
        setAllTrainers, // Used to update the context state
        allMembers,
        setAllMembers, // Used to update member state after trainer deletion
        individualTrainerPayments, // Correct source for specific trainer payments
        handleMarkTrainerSalaryPaid,
        currentBranchId,
        currentBranchData,
        formatCurrency: formatCurrencyFromContext,
        formatDate: formatDateFromContext,
        formatDateToYYYYMMDD: formatDateToYYYYMMDDFromContext,
        fetchPaymentsForSingleTrainer, // To ensure payments are fresh if needed
    } = useDashboardContext();

    const formatCurrencyGlobal = formatCurrencyFromContext || formatCurrencyLocal;
    const formatDateGlobal = formatDateFromContext || formatDateLocal;
    const formatDateToYYYYMMDDGlobal = formatDateToYYYYMMDDFromContext || formatDateToYYYYMMDDLocal;
    const getTodayDateStringGlobal = () => formatDateToYYYYMMDDGlobal(new Date());

    const [searchTerm, setSearchTerm] = useState('');
    const [filterStatus, setFilterStatus] = useState('All');
    const [isAddEditModalOpen, setIsAddEditModalOpen] = useState(false);
    const [modalMode, setModalMode] = useState('add');
    const [isDeleteModalOpen, setIsDeleteModalOpen] = useState(false);
    const [isTrainerDetailsModalOpen, setIsTrainerDetailsModalOpen] = useState(false);
    const [selectedTrainerForModal, setSelectedTrainerForModal] = useState(null);
    const [activeDetailsTab, setActiveDetailsTab] = useState('info');
    
    const [formData, setFormData] = useState({
        name: '', email: '', specialization: '', salary: '', fee: '', status: 'Active',
        dateOfJoining: getTodayDateStringGlobal(),
    });
    const [trainerToDelete, setTrainerToDelete] = useState(null);
    
    const [isLoading, setIsLoading] = useState(false); // Local loading for this component's fetch operations
    const [isSubmitting, setIsSubmitting] = useState(false);
    const [isDeletingTrainer, setIsDeletingTrainer] = useState(false);
    const [isProcessingPayment, setIsProcessingPayment] = useState(false);
    const [actionError, setActionError] = useState('');

    const [isSalaryConfirmModalOpen, setIsSalaryConfirmModalOpen] = useState(false);
    const [salaryConfirmDetails, setSalaryConfirmDetails] = useState({
        trainerId: null,
        amount: 0,
        trainerName: ''
    });

    const fetchTrainersForBranch = useCallback(async () => {
        if (!currentBranchId) return;
        setIsLoading(true);
        setActionError('');
        const token = localStorage.getItem('gymUserToken');
        if (!token) {
            setActionError("Authentication error: No token found.");
            setIsLoading(false);
            return;
        }
        try {
            const response = await fetch(`http://localhost:5001/api/branches/${currentBranchId}/trainers`, {
                method: 'GET',
                headers: { 'Authorization': `Bearer ${token}`, 'Content-Type': 'application/json' },
            });
            const data = await response.json();
            if (!response.ok) throw new Error(data.message || 'Failed to fetch trainers.');
            
            if (data.success && Array.isArray(data.trainers)) {
                 if (setAllTrainers) { // setAllTrainers is from context
                    setAllTrainers(prevAllTrainers => ({
                        ...prevAllTrainers,
                        [currentBranchId]: { // Store in the object structure expected by DashboardScreen
                            list: data.trainers,
                            initialList: data.trainers, // For overview/initial state
                            lastSearchTerm: '' // Reset search term for this branch
                        }
                    }));
                }
            } else {
                if (setAllTrainers) {
                    setAllTrainers(prevAllTrainers => ({
                        ...prevAllTrainers,
                        [currentBranchId]: { list: [], initialList: [], lastSearchTerm: '' }
                    }));
                }
                throw new Error(data.message || 'Invalid trainer data received.');
            }
        } catch (err) {
            setActionError(`Fetch Trainers Error: ${err.message}`);
            if (setAllTrainers) {
                 setAllTrainers(prevAllTrainers => ({
                    ...prevAllTrainers,
                    [currentBranchId]: { list: [], initialList: [], lastSearchTerm: '' }
                }));
            }
        } finally {
            setIsLoading(false);
        }
    }, [currentBranchId, setAllTrainers]);

    useEffect(() => {
        if (currentBranchId && !isLoading) {
            // Fetch if the list for the currentBranchId is not defined or not yet an array (initial state)
            // This ensures we fetch if the structure {list, initialList} is missing or if list itself is undefined.
            if (!allTrainersFromContext?.[currentBranchId]?.list) {
                fetchTrainersForBranch();
            }
        }
    }, [currentBranchId, allTrainersFromContext, fetchTrainersForBranch, isLoading]);

    const trainersForCurrentBranch = useMemo(() => {
        // Read from the .list property of the branch-specific trainer data
        return allTrainersFromContext?.[currentBranchId]?.list || [];
    }, [allTrainersFromContext, currentBranchId]);
    

    const filteredTrainers = useMemo(() => {
        if (!Array.isArray(trainersForCurrentBranch)) return [];
        return trainersForCurrentBranch.filter(trainer => {
            if (!trainer) return false;
            const lowerSearch = searchTerm.toLowerCase();
            const nameMatch = trainer.name?.toLowerCase().includes(lowerSearch) ?? false;
            const emailMatch = trainer.email?.toLowerCase().includes(lowerSearch) ?? false;
            const specializationMatch = trainer.specialization?.toLowerCase().includes(lowerSearch) ?? false;
            const statusMatch = filterStatus === 'All' || trainer.status === filterStatus;
            const idMatch = trainer._id?.toString().toLowerCase().includes(lowerSearch) ?? false;
            return (nameMatch || emailMatch || specializationMatch || idMatch) && statusMatch;
        });
    }, [trainersForCurrentBranch, searchTerm, filterStatus]);

    const trainerCounts = useMemo(() => {
        return filteredTrainers.reduce((acc, trainer) => {
            acc.total++;
            if (trainer.status === 'Active') acc.active++;
            else if (trainer.status === 'On Leave') acc.onLeave++;
            else if (trainer.status === 'Terminated') acc.terminated++;
            else if (trainer.status === 'Inactive') acc.inactive++;
            return acc;
        }, { total: 0, active: 0, onLeave: 0, terminated: 0, inactive: 0 });
    }, [filteredTrainers]);
    
    const modalTrainerDetails = useMemo(() => {
        // Ensure individualTrainerPayments is available from context
        if (!selectedTrainerForModal || !allMembers || !gymInfo || !individualTrainerPayments || !formatCurrencyGlobal || !currentBranchId) {
            return null;
        }
        const trainerId = selectedTrainerForModal._id;
        // Use trainer's own branchId if available, otherwise fallback to currentBranchId from context
        // This is important if trainer data might come from a global list but payments are branch-specific
        const trainerActualBranchId = selectedTrainerForModal.branchId || currentBranchId; 

        const trainerFee = Number(selectedTrainerForModal.fee) || 0;
        const activityHistory = selectedTrainerForModal.history || []; // Trainer's own activity log

        // Get members for the current selected trainer (for salary calculation based on current branch's active members)
        const membersInCurrentContextBranch = (currentBranchId && allMembers[currentBranchId]?.list) ? allMembers[currentBranchId].list : [];
        const activeAssignedMembersInCurrentContextBranch = membersInCurrentContextBranch.filter(m => m.trainerId === trainerId && m.status === 'Active');
        
        // Get members assigned to this trainer globally (for display)
        const currentAssignedMembersGlobally = getCurrentAssignedMembersWithBranch(trainerId, allMembers, gymInfo);
        const pastAssignedMembers = getPastAssignedMembersFromHistory(activityHistory);
        
        const estimatedMonthlyPayFromFees = trainerFee * activeAssignedMembersInCurrentContextBranch.length;
        const currentMonthStr = getCurrentMonthYYYYMM();

        // Get payments for THIS trainer from individualTrainerPayments
        // The key in individualTrainerPayments is `${branchId}_${trainerId}`
        const paymentsKey = `${trainerActualBranchId}_${trainerId}`;
        const paymentsForThisTrainer = individualTrainerPayments[paymentsKey] || [];


        const paidThisMonth = paymentsForThisTrainer
            .filter(p => p.paymentDate && p.paymentDate.startsWith(currentMonthStr))
            .reduce((sum, p) => sum + (Number(p.amount) || 0), 0);

        const actualMonthlySalary = Number(selectedTrainerForModal.salary) || 0;
        const pendingThisMonth = Math.max(0, actualMonthlySalary - paidThisMonth);
        const salaryDueDate = calculateSalaryDueDate(currentMonthStr);

        return {
            currentAssignedMembers: currentAssignedMembersGlobally,
            pastAssignedMembers,
            activeAssignedMembersCount: activeAssignedMembersInCurrentContextBranch.length,
            estimatedMonthlyPayFromFees,
            actualMonthlySalary,
            paidThisMonth,
            pendingThisMonth,
            // Ensure payment history is sorted correctly
            paymentHistory: [...paymentsForThisTrainer].sort((a,b) => new Date(b.paymentDate) - new Date(a.paymentDate)),
            activityHistory: [...activityHistory].sort((a, b) => new Date(b.date) - new Date(a.date)), // Also sort activity history
            salaryDueDate
        };
    }, [selectedTrainerForModal, allMembers, gymInfo, individualTrainerPayments, formatCurrencyGlobal, currentBranchId]);


    const openAddModal = () => {
        if (!currentBranchId) { alert("Please select a branch first."); return; }
        setModalMode('add');
        setSelectedTrainerForModal(null);
        setFormData({
            name: '', email: '', specialization: '', salary: '', fee: '', status: 'Active',
            dateOfJoining: getTodayDateStringGlobal(),
        });
        setActionError('');
        setIsAddEditModalOpen(true);
    };
    const openEditModal = (trainer) => {
        if (!trainer) return;
        setModalMode('edit');
        setSelectedTrainerForModal(trainer);
        setFormData({
            name: trainer.name || '',
            email: trainer.email || '',
            specialization: trainer.specialization || '',
            salary: trainer.salary?.toString() || '',
            fee: trainer.fee?.toString() || '',
            status: trainer.status || 'Active',
            dateOfJoining: trainer.dateOfJoining ? formatDateToYYYYMMDDGlobal(new Date(trainer.dateOfJoining)) : getTodayDateStringGlobal(),
        });
        setActionError('');
        setIsAddEditModalOpen(true);
    };
    const openDeleteModal = (trainer) => { if (!trainer) return; setTrainerToDelete(trainer); setIsDeleteModalOpen(true); };
    
    const openTrainerDetailsModal = async (trainer, defaultTab = 'info') => {
        if (!trainer) return;
        setSelectedTrainerForModal(trainer);
        setActiveDetailsTab(defaultTab);
        setIsTrainerDetailsModalOpen(true);
        // Ensure payments for this specific trainer are fetched/up-to-date when opening details
        // Use trainer.branchId if available, otherwise currentBranchId context
        const trainerBranchForPayments = trainer.branchId || currentBranchId;
        if (trainerBranchForPayments && trainer._id && fetchPaymentsForSingleTrainer) {
            try {
                await fetchPaymentsForSingleTrainer(trainerBranchForPayments, trainer._id, true); // force refresh
            } catch (err) {
                console.error("Error fetching trainer payments on modal open:", err);
                // Optionally set an error message for the user within the modal
            }
        }
    };
    
    const closeModal = () => {
        setIsAddEditModalOpen(false);
        setIsDeleteModalOpen(false);
        setIsTrainerDetailsModalOpen(false);
        setIsSalaryConfirmModalOpen(false);
        setSelectedTrainerForModal(null);
        setTrainerToDelete(null);
        setFormData({ name: '', email: '', specialization: '', salary: '', fee: '', status: 'Active', dateOfJoining: getTodayDateStringGlobal() });
        setActiveDetailsTab('info');
        setSalaryConfirmDetails({ trainerId: null, amount: 0, trainerName: '' });
        setActionError('');
    };
    const handleFormChange = (event) => {
        const { name, value } = event.target;
        setFormData(prev => ({ ...prev, [name]: value }));
    };

    const handleFormSubmit = async (e) => {
        e.preventDefault();
        if (!currentBranchId) {
            alert("No branch selected."); setActionError("No branch selected."); return;
        }
        if (!formData.name || !formData.email || !formData.specialization || 
            formData.salary === '' || isNaN(parseFloat(formData.salary)) || parseFloat(formData.salary) < 0 ||
            formData.fee === '' || isNaN(parseFloat(formData.fee)) || parseFloat(formData.fee) < 0) {
            alert("Please fill in Name, Email, Specialization, a valid non-negative Salary, and a valid non-negative Fee."); return;
        }
        if (!formData.dateOfJoining || !formData.dateOfJoining.match(/^\d{4}-\d{2}-\d{2}$/)) {
            alert("Please provide a valid Join Date in YYYY-MM-DD format."); return;
        }
        if (!/\S+@\S+\.\S+/.test(formData.email)) {
            alert("Please enter a valid email address."); return;
        }

        const trainerPayload = {
            name: formData.name, email: formData.email, specialization: formData.specialization,
            status: formData.status, salary: parseFloat(formData.salary), fee: parseFloat(formData.fee),
            dateOfJoining: formData.dateOfJoining,
        };

        setIsSubmitting(true); setActionError('');
        const token = localStorage.getItem('gymUserToken');
        if (!token) {
            setActionError("Authentication error."); setIsSubmitting(false); return;
        }

        let url = modalMode === 'add' ? `http://localhost:5001/api/branches/${currentBranchId}/trainers`
                    : `http://localhost:5001/api/branches/${currentBranchId}/trainers/${selectedTrainerForModal._id}`;
        let method = modalMode === 'add' ? 'POST' : 'PUT';

        if (modalMode === 'edit' && (!selectedTrainerForModal || !selectedTrainerForModal._id)) {
            setActionError("Invalid mode or missing trainer ID for edit."); setIsSubmitting(false); return;
        }

        try {
            const response = await fetch(url, {
                method: method,
                headers: { 'Authorization': `Bearer ${token}`, 'Content-Type': 'application/json' },
                body: JSON.stringify(trainerPayload),
            });
            const data = await response.json();
            if (!response.ok) throw new Error(data.message || `Failed to ${modalMode} trainer.`);
            
            if (data.success && data.trainer) {
                await fetchTrainersForBranch(); 
                alert(`Trainer ${modalMode === 'add' ? 'added' : 'updated'} successfully!`);
                closeModal();
            } else {
                throw new Error(data.message || `API error during ${modalMode} trainer.`);
            }
        } catch (err) {
            setActionError(`Error ${modalMode === 'add' ? 'adding' : 'updating'} trainer: ${err.message}`);
        } finally {
            setIsSubmitting(false);
        }
    };

    const handleDeleteConfirm = async () => {
        if (!trainerToDelete || !trainerToDelete._id || !currentBranchId) {
            alert("Deletion error: No trainer or branch ID."); closeModal(); return;
        }
        setActionError(''); setIsDeletingTrainer(true);
        const token = localStorage.getItem('gymUserToken');
        if (!token) {
            setActionError("Authentication error."); setIsDeletingTrainer(false); closeModal(); return;
        }

        try {
            const response = await fetch(`http://localhost:5001/api/branches/${currentBranchId}/trainers/${trainerToDelete._id}`, {
                method: 'DELETE', headers: { 'Authorization': `Bearer ${token}` },
            });
            const data = await response.json();
            if (!response.ok) throw new Error(data.message || `Server error ${response.status}`);

            if (data.success) {
                alert(data.message || "Trainer deleted successfully!");
                await fetchTrainersForBranch();
                
                if (setAllMembers && allMembers[currentBranchId]?.list) {
                    setAllMembers(prevAllMembers => {
                        const updatedBranchMembers = (prevAllMembers[currentBranchId]?.list || []).map(member => {
                            if (member.trainerId === trainerToDelete._id) {
                                const newHistoryEntry = {
                                    date: getTodayDateStringGlobal(), event: "Trainer Unassigned",
                                    details: `Trainer ${trainerToDelete.name} (ID: ${trainerToDelete._id}) was deleted.`
                                };
                                return { ...member, trainerId: null, history: [...(member.history || []), newHistoryEntry] };
                            }
                            return member;
                        });
                        return { ...prevAllMembers, [currentBranchId]: { ...(prevAllMembers[currentBranchId] || {}), list: updatedBranchMembers }};
                    });
                }
            } else {
                throw new Error(data.message || "Failed to delete trainer.");
            }
        } catch (err) {
            setActionError(`Delete Trainer Failed: ${err.message}`);
        } finally {
            setIsDeletingTrainer(false); closeModal();
        }
    };
    
    const handleInitiateSalaryPayment = () => {
        if (!modalTrainerDetails || !selectedTrainerForModal) return;
        const amountToPay = modalTrainerDetails.actualMonthlySalary;
        const pendingAmount = modalTrainerDetails.pendingThisMonth;

        if (amountToPay <= 0) {
            alert("Trainer's monthly salary is not set or is zero."); return;
        }
        if (pendingAmount <= 0 && amountToPay > 0) {
            alert("This month's salary appears to be fully paid or overpaid."); return;
        }

        setSalaryConfirmDetails({
            trainerId: selectedTrainerForModal._id,
            amount: amountToPay,
            trainerName: selectedTrainerForModal.name
        });
        setIsSalaryConfirmModalOpen(true);
    };

    const handleConfirmSalaryPayment = async () => {
        const { trainerId, amount, trainerName } = salaryConfirmDetails;
        if (!trainerId || !handleMarkTrainerSalaryPaid) {
            setActionError("Error: Trainer ID or payment handler is missing.");
            closeModal();
            return;
        }

        setIsProcessingPayment(true);
        setActionError('');

        const todayDateString = getTodayDateStringGlobal();
        const monthString = getCurrentMonthYYYYMM();
        const paymentNotes = `Monthly Salary - ${monthString} for ${trainerName} (Branch: ${currentBranchData?.name || 'N/A'})`;
        
        // Use selectedTrainerForModal.branchId if available, otherwise currentBranchId from context
        const paymentBranchId = selectedTrainerForModal?.branchId || currentBranchId;


        try {
            await handleMarkTrainerSalaryPaid({
                trainerId: trainerId,
                branchId: paymentBranchId, // Use the determined branchId for payment
                amount: amount,
                paymentDate: todayDateString,
                paymentMonth: monthString,
                notes: paymentNotes
            });
            // After successful payment, ensure the trainer's payment data is re-fetched for the modal
            if (fetchPaymentsForSingleTrainer && paymentBranchId && trainerId) {
                 await fetchPaymentsForSingleTrainer(paymentBranchId, trainerId, true);
            }

        } catch (error) {
            setActionError(`Salary Payment Failed: ${error.message}`);
        } finally {
            setIsProcessingPayment(false);
            setIsSalaryConfirmModalOpen(false);
            if(isTrainerDetailsModalOpen && selectedTrainerForModal?._id === trainerId) {
                 setActiveDetailsTab('salary');
            }
            setSalaryConfirmDetails({ trainerId: null, amount: 0, trainerName: '' });
        }
    };

    if (!currentBranchId && !isLoading) {
        return (
            <div className="trainers-page-container">
                <div className="dashboard-placeholder-content dashboard-card dashboard-select-branch-prompt">
                    <FiMapPin />
                    <p>Please select a branch from the dashboard header to manage trainers.</p>
                </div>
            </div>
        );
    }

    return (
        <div className="trainers-page-container">
            {(isLoading || isSubmitting || isDeletingTrainer || isProcessingPayment) && !isSalaryConfirmModalOpen && (
                <div className="trainers-loading-overlay">
                    <FiLoader className="trainers-loading-spinner-large" />
                    <span>
                        {isSubmitting ? "Saving Trainer..." 
                         : isDeletingTrainer ? "Deleting Trainer..." 
                         : isProcessingPayment ? "Processing Payment..."
                         : "Loading Trainers..."}
                    </span>
                </div>
            )}
            {actionError && <div className="trainers-action-error-toast">{actionError} <button onClick={() => setActionError('')}>&times;</button></div>}
            
            <header className="trainers-header">
                <h1 className="trainers-title">
                    Trainers {currentBranchData ? `(${currentBranchData.name})` : ''}
                </h1>
                <div className="trainers-actions">
                    <div className="trainers-search-bar">
                        <FiSearch className="trainers-search-icon" />
                        <input
                            type="text"
                            placeholder="Search by name, email, specialization, ID..."
                            value={searchTerm}
                            onChange={(e) => setSearchTerm(e.target.value)}
                            disabled={isLoading || isSubmitting || isDeletingTrainer || isProcessingPayment}
                        />
                    </div>
                    <button 
                        className="trainers-add-button" 
                        onClick={openAddModal}
                        disabled={isLoading || isSubmitting || !currentBranchId || isDeletingTrainer || isProcessingPayment}
                    >
                        <FiUserPlus /> Add Trainer
                    </button>
                </div>
            </header>

            <section className="trainers-stats-grid">
                <div className="trainers-stat-card">
                    <div className="trainers-stat-icon"><FiUsers /></div>
                    <div className="trainers-stat-content">
                        <div className="trainers-stat-value">{trainerCounts.total}</div>
                        <div className="trainers-stat-label">Total (This Branch)</div>
                    </div>
                </div>
                <div className="trainers-stat-card trainers-stat-active">
                    <div className="trainers-stat-icon"><FiUserCheck /></div>
                    <div className="trainers-stat-content">
                        <div className="trainers-stat-value">{trainerCounts.active}</div>
                        <div className="trainers-stat-label">Active</div>
                    </div>
                </div>
                <div className="trainers-stat-card trainers-stat-on-leave">
                    <div className="trainers-stat-icon"><FiBriefcase /></div>
                    <div className="trainers-stat-content">
                        <div className="trainers-stat-value">{trainerCounts.onLeave}</div>
                        <div className="trainers-stat-label">On Leave</div>
                    </div>
                </div>
                <div className="trainers-stat-card trainers-stat-terminated">
                    <div className="trainers-stat-icon"><FiUserX /></div>
                    <div className="trainers-stat-content">
                        <div className="trainers-stat-value">{trainerCounts.terminated}</div>
                        <div className="trainers-stat-label">Terminated</div>
                    </div>
                </div>
            </section>

            <section className="trainers-filter-section">
                <h3 className="trainers-filter-title"><FiFilter /> Filter by Status</h3>
                <div className="trainers-filter-buttons">
                    {['All', 'Active', 'On Leave', 'Terminated'].map(status => (
                        <button 
                            key={status}
                            className={`trainers-filter-button ${filterStatus === status ? 'active' : ''}`} 
                            onClick={() => setFilterStatus(status)} 
                            disabled={isLoading || isSubmitting || isDeletingTrainer || isProcessingPayment}
                        >
                            {status === 'All' && <FiList />}
                            {status === 'Active' && <FiUserCheck />}
                            {status === 'On Leave' && <FiBriefcase />}
                            {status === 'Terminated' && <FiUserX />}
                            {` ${status}`}
                        </button>
                    ))}
                </div>
            </section>

            <div className="trainers-table-container trainers-card-style">
                <h2 className="trainers-table-title">
                    {filterStatus === 'All' ? 'All Trainers' : `${filterStatus} Trainers`} in {currentBranchData?.name || 'Selected Branch'} ({filteredTrainers.length} shown)
                </h2>
                <div className="trainers-table-scroll-wrapper">
                    {isLoading && trainersForCurrentBranch.length === 0 && !allTrainersFromContext?.[currentBranchId]?.list ? (
                        <p className="trainers-no-data-message">Loading trainers...</p>
                    ) :
                     !isLoading && !currentBranchId ? (
                        <p className="trainers-no-data-message">Please select a branch.</p>
                    ) :
                     filteredTrainers.length > 0 ? (
                        <table className="trainers-data-table trainers-table">
                            <thead>
                                <tr>
                                    <th>ID</th><th>Name</th><th>Email</th><th>Specialization</th><th>Status</th>
                                    <th>Salary (Fixed)</th><th>Fee (Client)</th><th>Active Clients</th>
                                    <th>Est. Pay (Fees)</th><th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                {filteredTrainers.map(trainer => {
                                    const membersInCurrentBranch = (currentBranchId && allMembers[currentBranchId]?.list) ? allMembers[currentBranchId].list : [];
                                    const activeAssignedCount = membersInCurrentBranch.filter(m => m.trainerId === trainer._id && m.status === 'Active').length;
                                    const trainerFee = Number(trainer.fee) || 0;
                                    const trainerSalary = Number(trainer.salary) || 0;
                                    const estimatedPayFromFees = trainerFee * activeAssignedCount;
                                    
                                    // Get payments for this specific trainer to calculate paidThisMonthAmount
                                    const trainerActualBranchId = trainer.branchId || currentBranchId;
                                    const paymentsKey = `${trainerActualBranchId}_${trainer._id}`;
                                    const paymentsForThisTrainerInTable = individualTrainerPayments[paymentsKey] || [];
                                    
                                    const paidThisMonthAmount = paymentsForThisTrainerInTable
                                        .filter(p => p.paymentDate && p.paymentDate.startsWith(getCurrentMonthYYYYMM()))
                                        .reduce((sum, p) => sum + (Number(p.amount) || 0), 0);
                                    
                                    const isPaymentPending = trainerSalary > 0 && paidThisMonthAmount < trainerSalary && trainer.status === 'Active';
                                    
                                    return (
                                        <tr key={trainer._id}>
                                            <td>{trainer.id || String(trainer._id).slice(-6).toUpperCase()}</td>
                                            <td className="trainers-trainer-name-cell">
                                                <button className="trainers-name-button" onClick={() => openTrainerDetailsModal(trainer)} disabled={isLoading || isSubmitting || isDeletingTrainer || isProcessingPayment}>
                                                    {trainer.name}
                                                </button>
                                            </td>
                                            <td>{trainer.email}</td>
                                            <td>{trainer.specialization}</td>
                                            <td><span className={`trainers-status-badge trainers-status-${trainer.status?.toLowerCase().replace(/\s+/g, '-')}`}>{trainer.status}</span></td>
                                            <td>{formatCurrencyGlobal(trainerSalary)}</td>
                                            <td>{formatCurrencyGlobal(trainerFee)}</td>
                                            <td>{activeAssignedCount}</td>
                                            <td>{formatCurrencyGlobal(estimatedPayFromFees)}</td>
                                            <td>
                                                <div className="trainers-action-buttons">
                                                    <button className="trainers-action-button trainers-view-button" title="View Details" onClick={() => openTrainerDetailsModal(trainer, 'info')} disabled={isLoading || isSubmitting || isDeletingTrainer || isProcessingPayment}><FiInfo /></button>
                                                    {trainer.status !== 'Terminated' && (
                                                        <button className="trainers-action-button trainers-edit-button" title="Edit Trainer" onClick={() => openEditModal(trainer)} disabled={isLoading || isSubmitting || isDeletingTrainer || isProcessingPayment}><FiEdit /></button>
                                                    )}
                                                    {trainer.status === 'Active' && (
                                                        <button 
                                                            className={`trainers-action-button trainers-salary-button ${isPaymentPending ? 'pending' : (trainerSalary > 0 ? 'paid' : 'zero')}`} 
                                                            title={isPaymentPending ? "Salary Pending - View & Mark Paid" : (trainerSalary > 0 ? "View Salary Details (Paid/Up-to-date)" : "View Salary Details (No Fixed Salary)")} 
                                                            onClick={() => openTrainerDetailsModal(trainer, 'salary')} 
                                                            disabled={isLoading || isSubmitting || isDeletingTrainer || isProcessingPayment}>
                                                            <FiDollarSign />
                                                        </button>
                                                    )}
                                                    <button className="trainers-action-button trainers-delete-button" title="Delete Trainer" onClick={() => openDeleteModal(trainer)} disabled={isLoading || isSubmitting || isDeletingTrainer || isProcessingPayment}><FiTrash2 /></button>
                                                </div>
                                            </td>
                                        </tr>
                                    );
                                })}
                            </tbody>
                        </table>
                    ) : (
                        <p className="trainers-no-data-message">
                            {isLoading ? 'Loading trainers...' : (searchTerm || filterStatus !== 'All' ? 'No trainers found matching search or filter.' : `No trainers added to ${currentBranchData?.name || 'this branch'} yet.`)}
                        </p>
                    )}
                </div>
            </div>

            {isAddEditModalOpen && (
                <div className="trainers-modal-overlay">
                    <div className="trainers-modal-content trainers-fade-in">
                        <div className="trainers-modal-header-section">
                            <h2 className="trainers-modal-title">{modalMode === 'add' ? `Add New Trainer to ${currentBranchData?.name || 'Branch'}` : `Edit Trainer (ID: ${selectedTrainerForModal?._id?.slice(-6).toUpperCase() || 'N/A'})`}</h2>
                            <button className="trainers-modal-close-button" onClick={closeModal} disabled={isSubmitting}><FiX /></button>
                        </div>
                        <form onSubmit={handleFormSubmit} className="trainers-modal-form">
                            <div className="trainers-modal-body-section">
                                <div className="trainers-form-row">
                                    <div className="trainers-form-group"><label htmlFor="trainerName"><FiUser /> Name</label><input type="text" id="trainerName" name="name" value={formData.name} onChange={handleFormChange} required disabled={isSubmitting} /></div>
                                    <div className="trainers-form-group"><label htmlFor="trainerEmail"><FiMail /> Email</label><input type="email" id="trainerEmail" name="email" value={formData.email} onChange={handleFormChange} required disabled={isSubmitting} placeholder="trainer@example.com"/></div>
                                </div>
                                <div className="trainers-form-row">
                                    <div className="trainers-form-group"><label htmlFor="trainerSpecialization"><FiAward /> Specialization</label><input type="text" id="trainerSpecialization" name="specialization" value={formData.specialization} onChange={handleFormChange} placeholder="e.g., Yoga" required disabled={isSubmitting} /></div>
                                    <div className="trainers-form-group"><label htmlFor="trainerSalary"><FiTrendingUp /> Monthly Salary</label><input type="number" id="trainerSalary" name="salary" value={formData.salary} onChange={handleFormChange} min="0" step="100" required placeholder="e.g., 50000" disabled={isSubmitting} /></div>
                                </div>
                                <div className="trainers-form-row">
                                    <div className="trainers-form-group"><label htmlFor="trainerFee"><FiDollarSign /> Fee (per client)</label><input type="number" id="trainerFee" name="fee" value={formData.fee} onChange={handleFormChange} min="0" step="1" required placeholder="e.g., 5000" disabled={isSubmitting} /></div>
                                    <div className="trainers-form-group"><label htmlFor="trainerStatus"><FiBriefcase /> Status</label><select id="trainerStatus" name="status" value={formData.status} onChange={handleFormChange} required disabled={isSubmitting}><option value="Active">Active</option><option value="On Leave">On Leave</option>{modalMode === 'edit' && <option value="Terminated">Terminated</option>}{modalMode === 'edit' && <option value="Inactive">Inactive</option>}</select></div>
                                </div>
                                 <div className="trainers-form-row">
                                    <div className="trainers-form-group"><label htmlFor="dateOfJoining"><FiCalendar /> Join Date</label><input type="date" id="dateOfJoining" name="dateOfJoining" value={formData.dateOfJoining} onChange={handleFormChange} required max={getTodayDateStringGlobal()} disabled={isSubmitting} /></div>
                                </div>
                                {modalMode === 'add' && currentBranchData && (<p className="trainers-info-message"><FiMapPin /> Adding to: <strong>{currentBranchData.name}</strong></p>)}
                            </div>
                            <div className="trainers-modal-footer-section">
                                <div className="trainers-modal-actions">
                                    <button type="submit" className="trainers-modal-button trainers-confirm" disabled={isSubmitting}>{isSubmitting ? <FiLoader className="trainers-button-loader"/> : <><FiCheck /> {modalMode === 'add' ? 'Add Trainer' : 'Save Changes'}</>}</button>
                                    <button type="button" className="trainers-modal-button trainers-cancel" onClick={closeModal} disabled={isSubmitting}><FiX /> Cancel</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            )}

            {isDeleteModalOpen && trainerToDelete && (
                <div className="trainers-modal-overlay trainers-delete-confirm-overlay">
                    <div className="trainers-modal-content trainers-delete-modal-content trainers-fade-in">
                        <div className="trainers-modal-header-section"><h2 className="trainers-modal-title trainers-delete-title"><FiAlertTriangle /> Confirm Deletion</h2><button className="trainers-modal-close-button" onClick={closeModal} disabled={isDeletingTrainer}><FiX /></button></div>
                        <div className="trainers-modal-body-section"><p className="trainers-confirm-message">Delete "<span className="trainers-highlight-name">{trainerToDelete.name}</span>" (ID: <span className="trainers-highlight-id">{trainerToDelete._id}</span>)?<br />This unassigns them from members. Cannot be undone.</p></div>
                        <div className="trainers-modal-footer-section"><div className="trainers-modal-actions trainers-delete-actions"><button type="button" className="trainers-modal-button trainers-delete" onClick={handleDeleteConfirm} disabled={isDeletingTrainer}>{isDeletingTrainer ? <FiLoader className="trainers-button-loader"/> : <><FiTrash2 /> Confirm Delete</>}</button><button type="button" className="trainers-modal-button trainers-cancel" onClick={closeModal} disabled={isDeletingTrainer}><FiX /> Cancel</button></div></div>
                    </div>
                </div>
            )}
            
            {isTrainerDetailsModalOpen && selectedTrainerForModal && modalTrainerDetails && (
                <div className="trainers-modal-overlay trainers-details-modal-overlay">
                    <div className="trainers-modal-content trainers-details-modal-content trainers-fade-in">
                        <div className="trainers-modal-header-section trainers-info-modal-header">
                            <h2 className="trainers-modal-title">{selectedTrainerForModal.name} <span className="trainers-trainer-id-badge">(ID: {selectedTrainerForModal._id?.slice(-6).toUpperCase() || 'N/A'})</span></h2>
                            <span className={`trainers-status-badge trainers-status-${selectedTrainerForModal.status?.toLowerCase().replace(/\s+/g, '-')}`}>{selectedTrainerForModal.status}</span>
                            <button className="trainers-modal-close-button" onClick={closeModal} disabled={isProcessingPayment}><FiX /></button>
                        </div>
                        <div className="trainers-modal-body-section">
                            <div className="trainers-modal-tabs">
                                <button className={`trainers-tab-button ${activeDetailsTab === 'info' ? 'active' : ''}`} onClick={() => setActiveDetailsTab('info')} disabled={isProcessingPayment}> <FiInfo /> Details </button>
                                <button className={`trainers-tab-button ${activeDetailsTab === 'members' ? 'active' : ''}`} onClick={() => setActiveDetailsTab('members')} disabled={isProcessingPayment}> <FiUsers /> Assignments </button>
                                <button className={`trainers-tab-button ${activeDetailsTab === 'salary' ? 'active' : ''}`} onClick={() => setActiveDetailsTab('salary')} disabled={isProcessingPayment}> <FiDollarSign /> Salary </button>
                                <button className={`trainers-tab-button ${activeDetailsTab === 'activity' ? 'active' : ''}`} onClick={() => setActiveDetailsTab('activity')} disabled={isProcessingPayment}> <FiActivity /> Activity Log</button>
                            </div>
                            <div className="trainers-modal-tab-content">
                                {activeDetailsTab === 'info' && (
                                    <div className="trainers-info-section trainers-fade-in-tab">
                                        <div className="trainers-info-grid">
                                            <div className="trainers-info-item"><span className="trainers-info-label"><FiMail /> Email:</span> <span className="trainers-info-value">{selectedTrainerForModal.email}</span></div>
                                            <div className="trainers-info-item"><span className="trainers-info-label"><FiAward /> Specialization:</span> <span className="trainers-info-value">{selectedTrainerForModal.specialization}</span></div>
                                            <div className="trainers-info-item"><span className="trainers-info-label"><FiTrendingUp /> Monthly Salary:</span> <span className="trainers-info-value">{formatCurrencyGlobal(selectedTrainerForModal.salary)}</span></div>
                                            <div className="trainers-info-item"><span className="trainers-info-label"><FiDollarSign /> Fee (client):</span> <span className="trainers-info-value">{formatCurrencyGlobal(selectedTrainerForModal.fee)}</span></div>
                                            <div className="trainers-info-item"><span className="trainers-info-label"><FiBriefcase /> Status:</span> <span className="trainers-info-value">{selectedTrainerForModal.status}</span></div>
                                            <div className="trainers-info-item"><span className="trainers-info-label"><FiCalendar /> Joined:</span> <span className="trainers-info-value">{formatDateGlobal(selectedTrainerForModal.dateOfJoining) || 'N/A'}</span></div>
                                            <div className="trainers-info-item"><span className="trainers-info-label"><FiMapPin /> Branch:</span> <span className="trainers-info-value">{gymInfo.branches.find(b => b.id === selectedTrainerForModal.branchId)?.name || (currentBranchData?.name ||'N/A')}</span></div>
                                        </div>
                                    </div>
                                )}
                                {activeDetailsTab === 'members' && (
                                    <div className="trainers-history-section trainers-fade-in-tab">
                                        <h3 className="trainers-tab-section-title">Current Assignments ({modalTrainerDetails.activeAssignedMembersCount} Active in Branch)</h3>
                                        <div className="trainers-history-list trainers-assigned-members-list">
                                            {modalTrainerDetails.currentAssignedMembers.length > 0 ? (
                                                modalTrainerDetails.currentAssignedMembers.sort((a,b)=>a.name.localeCompare(b.name)).map(member => (
                                                    <div key={`current-${member._id}`} className="trainers-list-item trainers-assigned-member-item">
                                                        <span className="trainers-assigned-member-name">{member.name} (ID: {member.displayMemberId || String(member._id).slice(-6).toUpperCase()})</span>
                                                        <span className="trainers-assigned-member-branch"><FiMapPin /> {member.branchName}</span>
                                                        <span className={`trainers-status-badge trainers-status-${member.status?.toLowerCase().replace(/\s+/g, '-')}`}>{member.status}</span>
                                                    </div>
                                                ))
                                            ) : ( <p className="trainers-no-data-message"><FiUsers /> No members currently assigned.</p> )}
                                        </div>
                                        <h3 className="trainers-tab-section-title trainers-past-assignments-title">Past Assignments (History)</h3>
                                        <div className="trainers-history-list trainers-assigned-members-list">
                                            {modalTrainerDetails.pastAssignedMembers.length > 0 ? (
                                                modalTrainerDetails.pastAssignedMembers.map(pastMember => (
                                                    <div key={`past-${pastMember.memberId}`} className="trainers-list-item trainers-assigned-member-item trainers-past-member-item">
                                                        <span className="trainers-assigned-member-name">{pastMember.memberName} (ID: {pastMember.memberId})</span>
                                                        <span className="trainers-assigned-member-branch"><FiCalendar /> Unassigned: {formatDateGlobal(pastMember.unassignedDate)}</span>
                                                    </div>
                                                ))
                                            ) : ( <p className="trainers-no-data-message"><FiInfo /> No past assignments in history.</p> )}
                                        </div>
                                    </div>
                                )}
                                {activeDetailsTab === 'salary' && (
                                    <div className="trainers-salary-section trainers-fade-in-tab">
                                        <h3 className="trainers-tab-section-title">Salary (Month: {getCurrentMonthYYYYMM()}) for Branch: {currentBranchData?.name || 'N/A'}</h3>
                                        <div className="trainers-salary-grid">
                                            <div className="trainers-salary-item"><span className="trainers-salary-label">Fixed Monthly Salary:</span> <span className="trainers-salary-value">{formatCurrencyGlobal(modalTrainerDetails.actualMonthlySalary)}</span></div>
                                            <div className="trainers-salary-item"><span className="trainers-salary-label">Active Clients (Branch):</span> <span className="trainers-salary-value">{modalTrainerDetails.activeAssignedMembersCount}</span></div>
                                            <div className="trainers-salary-item"><span className="trainers-salary-label">Est. Pay (Fees):</span> <span className="trainers-salary-value">{formatCurrencyGlobal(modalTrainerDetails.estimatedMonthlyPayFromFees)}</span></div>
                                            <div className="trainers-salary-item"><span className="trainers-salary-label">Paid This Month (Salary):</span> <span className="trainers-salary-value trainers-paid">{formatCurrencyGlobal(modalTrainerDetails.paidThisMonth)}</span></div>
                                            <div className="trainers-salary-item"><span className="trainers-salary-label">Pending This Month (Salary):</span> <span className="trainers-salary-value trainers-pending">{formatCurrencyGlobal(modalTrainerDetails.pendingThisMonth)}</span></div>
                                            <div className="trainers-salary-item trainers-due-date-item"><span className="trainers-salary-label">Est. Salary Due:</span> <span className="trainers-salary-value trainers-date-value">{modalTrainerDetails.salaryDueDate}</span></div>
                                        </div>
                                        {selectedTrainerForModal.status === 'Active' && modalTrainerDetails.actualMonthlySalary > 0 && (
                                            <div className="trainers-salary-actions">
                                                <button className="trainers-modal-button trainers-confirm trainers-mark-paid-button" onClick={handleInitiateSalaryPayment} disabled={modalTrainerDetails.pendingThisMonth <= 0 || isProcessingPayment} title={ modalTrainerDetails.pendingThisMonth <= 0 ? "Salary already paid" : `Mark ${formatCurrencyGlobal(modalTrainerDetails.actualMonthlySalary)} as paid` }><FiCheck /> Mark Monthly Salary Paid</button>
                                            </div>
                                        )}
                                        {selectedTrainerForModal.status !== 'Active' && ( <p className="trainers-info-message trainers-centered"><FiInfo/> Salary payment only for Active trainers.</p> )}
                                        {modalTrainerDetails.actualMonthlySalary <= 0 && selectedTrainerForModal.status === 'Active' && ( <p className="trainers-info-message trainers-centered"><FiInfo/> No fixed salary to pay.</p> )}
                                        
                                        <h4 className="trainers-payment-history-title">Payment History (This Branch)</h4>
                                        <div className="trainers-history-list trainers-payment-history-list">
                                            {modalTrainerDetails.paymentHistory.length > 0 ? (
                                                modalTrainerDetails.paymentHistory.map((payment, index) => (
                                                    <div key={`payment-${payment._id || index}`} className="trainers-history-item trainers-payment-item">
                                                        <span className="trainers-history-icon"><FiCreditCard /></span>
                                                        <div className="trainers-history-content">
                                                            <span className="trainers-history-date">{formatDateGlobal(payment.paymentDate)}</span>
                                                            <span className="trainers-history-amount">{formatCurrencyGlobal(payment.amount)}</span>
                                                            <p className="trainers-history-details">{payment.notes || 'Payment Received'}</p>
                                                        </div>
                                                    </div>
                                                ))
                                            ) : ( <p className="trainers-no-history"><FiInfo /> No payment records for this trainer in this branch.</p> )}
                                        </div>
                                    </div>
                                )}
                                {activeDetailsTab === 'activity' && (
                                    <div className="trainers-history-section trainers-fade-in-tab">
                                        <h3 className="trainers-tab-section-title">Trainer Activity Log</h3>
                                        <div className="trainers-history-list trainers-activity-history-list">
                                            {modalTrainerDetails.activityHistory.length > 0 ? (
                                                modalTrainerDetails.activityHistory.map((item, index) => { // Already sorted in modalTrainerDetails
                                                    let icon = <FiActivity />; let eventClass = 'unknown';
                                                    if (item.event) {
                                                        const lowerEvent = item.event.toLowerCase();
                                                        eventClass = lowerEvent.replace(/[^a-z0-9]+/g, '-') ?? 'unknown';
                                                        if (lowerEvent === 'joined') icon = <FiUserPlus />;
                                                        else if (lowerEvent.includes('status change') || lowerEvent.includes('info update') || lowerEvent.includes('profile updated')) icon = <FiEdit />;
                                                        else if (lowerEvent === 'salary paid' || lowerEvent === 'salary paid (api)') icon = <FiDollarSign />;
                                                        else if (lowerEvent === 'deleted' || lowerEvent === 'left' || lowerEvent === 'terminated') icon = <FiUserX />;
                                                        else if (lowerEvent === 'assigned to member') icon = <FiUserCheck />;
                                                        else if (lowerEvent === 'unassigned from member' || lowerEvent === 'trainer unassigned') icon = <FiUserMinus />;
                                                    }
                                                    return (
                                                        <div key={`activity-${item._id || index}-${item.date}`} className="trainers-history-item">
                                                            <span className={`trainers-history-icon trainers-event-icon-${eventClass}`}>{icon}</span>
                                                            <div className="trainers-history-content">
                                                                <span className="trainers-history-date">{formatDateGlobal(item.date)}</span>
                                                                <span className={`trainers-history-event trainers-history-event-${eventClass}`}>{item.event ?? 'Unknown'}</span>
                                                                <p className="trainers-history-details">{item.details}{(item.event === 'Assigned to Member' || item.event === 'Unassigned from Member') && item.memberName && ` (Member: ${item.memberName}${item.memberId ? ` - ID: ${item.memberId}` : ''})`}</p>
                                                            </div>
                                                        </div>
                                                    );
                                                })
                                            ) : ( <p className="trainers-no-history"><FiInfo /> No activity recorded.</p> )}
                                        </div>
                                    </div>
                                )}
                            </div>
                        </div>
                        <div className="trainers-modal-footer-section"><div className="trainers-modal-actions"><button type="button" className="trainers-modal-button trainers-cancel" onClick={closeModal} disabled={isProcessingPayment}>Close</button></div></div>
                    </div>
                </div>
            )}

            {isSalaryConfirmModalOpen && (
                <div className="trainers-modal-overlay trainers-salary-confirm-overlay">
                    <div className="trainers-modal-content trainers-salary-confirm-modal-content trainers-fade-in">
                        <div className="trainers-modal-header-section"><h2 className="trainers-modal-title trainers-confirm-title"><FiAlertTriangle /> Confirm Salary Payment</h2><button className="trainers-modal-close-button" onClick={closeModal} disabled={isProcessingPayment}><FiX /></button></div>
                        <div className="trainers-modal-body-section">
                            <p className="trainers-confirm-message">Pay <span className="trainers-highlight-amount">{formatCurrencyGlobal(salaryConfirmDetails.amount)}</span> to <span className="trainers-highlight-name">{salaryConfirmDetails.trainerName}</span> for {getCurrentMonthYYYYMM()} (Branch: <span className="trainers-highlight-text">{currentBranchData?.name || 'N/A'}</span>)?</p>
                            <p className="trainers-confirm-note">This records a payment via API.</p>
                        </div>
                        <div className="trainers-modal-footer-section"><div className="trainers-modal-actions trainers-confirm-actions"><button type="button" className="trainers-modal-button trainers-confirm" onClick={handleConfirmSalaryPayment} disabled={isProcessingPayment}>{isProcessingPayment ? <FiLoader className="trainers-button-loader"/> : <><FiCheck /> Confirm Payment</>}</button><button type="button" className="trainers-modal-button trainers-cancel" onClick={closeModal} disabled={isProcessingPayment}><FiX /> Cancel</button></div></div>
                    </div>
                </div>
            )}
        </div>
    );
}

export default Trainers;
