import React, { useState, useEffect, useMemo, useCallback } from 'react';
import { useDashboardContext } from './DashboardScreen';
import {
    FiUserPlus, FiEdit, FiTrash2, FiX, FiCheck, FiSearch, FiCalendar,
    FiPackage, FiTag, FiUser, FiUsers, FiClock, FiTrendingUp,
    FiDollarSign, FiInfo, FiList, FiPhone, FiGift, FiActivity,
    FiMail, FiRefreshCw, FiAlertTriangle, FiAward, FiFilter, FiZap,
    FiCheckCircle, FiPauseCircle, FiXCircle, FiUserMinus, FiLoader, FiEye, FiShield
} from 'react-icons/fi';
import '../styles/Members.css';

// Debounce hook
function useDebounce(value, delay) {
    const [debouncedValue, setDebouncedValue] = useState(value);
    useEffect(() => {
        const handler = setTimeout(() => {
            setDebouncedValue(value);
        }, delay);
        return () => {
            clearTimeout(handler);
        };
    }, [value, delay]);
    return debouncedValue;
}

// --- UTILITY FUNCTIONS ---
const subscriptionPacksFromUtils = [
    { id: 'student_1m', type: 'Student', durationMonths: 1, name: 'Student - 1 Month', price: 3000 },
    { id: 'student_3m', type: 'Student', durationMonths: 3, name: 'Student - 3 Months', price: 8000 },
    { id: 'solo_1m', type: 'Solo', durationMonths: 1, name: 'Solo - 1 Month', price: 5000 },
    { id: 'solo_3m', type: 'Solo', durationMonths: 3, name: 'Solo - 3 Months', price: 13500 },
    { id: 'solo_6m', type: 'Solo', durationMonths: 6, name: 'Solo - 6 Months', price: 25000 },
    { id: 'solo_12m', type: 'Solo', durationMonths: 12, name: 'Solo - 1 Year', price: 45000 },
];

const getPackDetailsLocalFallback = (packId) => subscriptionPacksFromUtils.find(p => p.id === packId) || { name: 'N/A', price: 0, durationMonths: 0, type: 'N/A' };

const formatDateToYYYYMMDDForForm = (date) => {
    if (date instanceof Date && !isNaN(date)) {
        const year = date.getFullYear();
        const month = String(date.getMonth() + 1).padStart(2, '0');
        const day = String(date.getDate()).padStart(2, '0');
        return `${year}-${month}-${day}`;
    }
    if (typeof date === 'string' && date.match(/^\d{4}-\d{2}-\d{2}/)) {
        return date.split('T')[0];
    }
    return '';
};

const getTodayDateStringForForm = () => formatDateToYYYYMMDDForForm(new Date());

const calculateAge = (dobString) => {
    if (!dobString) return 'N/A';
    try {
        const birthDate = new Date(dobString.split('T')[0]);
        if (isNaN(birthDate.getTime())) return 'N/A';
        const today = new Date();
        let age = today.getFullYear() - birthDate.getFullYear();
        const m = today.getMonth() - birthDate.getMonth();
        if (m < 0 || (m === 0 && today.getDate() < birthDate.getDate())) { age--; }
        return age >= 0 ? age : 'N/A';
    } catch (e) { return 'N/A'; }
};

const calculateDaysRemaining = (endDateString) => {
    if (!endDateString) return { days: null, text: 'N/A', className: 'days-na' };
    try {
        const endDate = new Date(endDateString.split('T')[0] + 'T00:00:00Z');
        if (isNaN(endDate.getTime())) return { days: null, text: 'Invalid Date', className: 'days-na' };
        const today = new Date();
        const todayUTCStartOfDay = new Date(Date.UTC(today.getUTCFullYear(), today.getUTCMonth(), today.getUTCDate()));
        const diffTime = endDate.getTime() - todayUTCStartOfDay.getTime();
        const diffDays = Math.floor(diffTime / (1000 * 60 * 60 * 24));
        if (diffDays < 0) return { days: diffDays, text: 'Expired', className: 'days-expired' };
        if (diffDays === 0) return { days: diffDays, text: 'Ends Today', className: 'days-ends-today' };
        if (diffDays <= 3) return { days: diffDays, text: `${diffDays} Day${diffDays > 1 ? 's' : ''} Left`, className: 'days-ends-soon' };
        if (diffDays <= 7) return { days: diffDays, text: `${diffDays} Days Left`, className: 'days-ending-soon-mild' };
        return { days: diffDays, text: `${diffDays} Days Left`, className: 'days-active' };
    } catch (e) { return { days: null, text: 'Error', className: 'days-error' }; }
};

function Members() {
    const {
        currentBranchId, gymInfo, allMembers, fetchBranchMembers, isFetchingMembers,
        allTrainers: allTrainersFromContext, getTrainerDetails, formatDate, getPackDetails,
    } = useDashboardContext();

    const getPackInfo = getPackDetails || getPackDetailsLocalFallback;
    const [memberStats, setMemberStats] = useState({ total: 0, active: 0, inactive: 0, expired: 0, frozen: 0 });
    const [searchTerm, setSearchTerm] = useState('');
    const debouncedSearchTerm = useDebounce(searchTerm, 500);
    const [isAddEditModalOpen, setIsAddEditModalOpen] = useState(false);
    const [modalMode, setModalMode] = useState('add');
    const [currentMember, setCurrentMember] = useState(null); // For edit modal context

    const initialFormData = useMemo(() => ({
        name: '', email: '', phone: '', gender: 'Male', dob: '',
        joiningDate: getTodayDateStringForForm(),
        currentPlanId: subscriptionPacksFromUtils[0]?.id || '',
        status: 'Active', trainerId: '', goal: '',
    }), []);
    const [formData, setFormData] = useState(initialFormData);

    const [isInfoModalOpen, setIsInfoModalOpen] = useState(false);
    const [selectedMemberForInfo, setSelectedMemberForInfo] = useState(null); // For info modal
    const [activeInfoTab, setActiveInfoTab] = useState('info');
    const [activeQuickFilter, setActiveQuickFilter] = useState('all');
    const [isDeleteConfirmOpen, setIsDeleteConfirmOpen] = useState(false);
    const [memberToDelete, setMemberToDelete] = useState(null);
    const [isRenewModalOpen, setIsRenewModalOpen] = useState(false);
    const [memberToRenew, setMemberToRenew] = useState(null);
    const [renewalPlanId, setRenewalPlanId] = useState('');
    const [isSubmitting, setIsSubmitting] = useState(false);
    const [isDeleting, setIsDeleting] = useState(false);
    const [isRenewing, setIsRenewing] = useState(false);
    const [actionError, setActionError] = useState('');

    useEffect(() => {
        if (currentBranchId) {
            fetchBranchMembers(currentBranchId, debouncedSearchTerm, true);
        }
    }, [currentBranchId, debouncedSearchTerm, fetchBranchMembers]);

    const membersToDisplayInitially = useMemo(() => (currentBranchId && allMembers[currentBranchId]?.list) ? allMembers[currentBranchId].list : [], [currentBranchId, allMembers]);

    const displayedMembers = useMemo(() => {
        let members = [...membersToDisplayInitially];
        const todayStr = getTodayDateStringForForm();
        members = members.map(mem => ({ ...mem, status: (mem.status === 'Active' && mem.endDate && mem.endDate < todayStr) ? 'Expired' : mem.status }));
        
        switch (activeQuickFilter) {
            case 'endingToday': return members.filter(m => m.status === 'Active' && m.endDate === todayStr);
            case 'endingNext3Days': return members.filter(m => m.status === 'Active' && m.endDate && calculateDaysRemaining(m.endDate).days <= 3 && calculateDaysRemaining(m.endDate).days >= 0);
            case 'active': return members.filter(m => m.status === 'Active');
            case 'inactive': return members.filter(m => m.status === 'Inactive');
            case 'expired': return members.filter(m => m.status === 'Expired');
            case 'frozen': return members.filter(m => m.status === 'Frozen');
            default: return members;
        }
    }, [membersToDisplayInitially, activeQuickFilter]);

    useEffect(() => {
        const initialList = (currentBranchId && allMembers[currentBranchId]?.initialList) ? allMembers[currentBranchId].initialList : [];
        const todayStr = getTodayDateStringForForm();
        const processedList = initialList.map(mem => ({ ...mem, status: (mem.status === 'Active' && mem.endDate && mem.endDate < todayStr) ? 'Expired' : mem.status }));
        setMemberStats({
            total: processedList.length,
            active: processedList.filter(m => m.status === 'Active').length,
            inactive: processedList.filter(m => m.status === 'Inactive').length,
            expired: processedList.filter(m => m.status === 'Expired').length,
            frozen: processedList.filter(m => m.status === 'Frozen').length,
        });
    }, [allMembers, currentBranchId]);
    
    useEffect(() => {
        if (isInfoModalOpen && selectedMemberForInfo?._id && displayedMembers) {
            const updatedSelectedMemberInList = displayedMembers.find(m => m._id === selectedMemberForInfo._id);
            if (updatedSelectedMemberInList) {
                if (updatedSelectedMemberInList !== selectedMemberForInfo ||
                    updatedSelectedMemberInList.trainerName !== selectedMemberForInfo.trainerName ||
                    updatedSelectedMemberInList.trainerId !== selectedMemberForInfo.trainerId ||
                    updatedSelectedMemberInList.status !== selectedMemberForInfo.status) { 
                    setSelectedMemberForInfo(updatedSelectedMemberInList);
                }
            }
        }
    }, [displayedMembers, isInfoModalOpen, selectedMemberForInfo]);


    const openAddModal = () => {
        setModalMode('add'); setCurrentMember(null); setFormData(initialFormData);
        setActionError(''); setIsAddEditModalOpen(true);
    };

    const openEditModal = useCallback((member) => {
        setModalMode('edit'); 
        setCurrentMember(member); 
        setFormData({
            name: member.name || '', email: member.email || '', phone: member.phone || '',
            gender: member.gender || 'Male', dob: member.dob ? formatDateToYYYYMMDDForForm(member.dob) : '',
            joiningDate: member.joiningDate ? formatDateToYYYYMMDDForForm(member.joiningDate) : getTodayDateStringForForm(),
            currentPlanId: member.currentPlanId || (subscriptionPacksFromUtils[0]?.id || ''),
            status: member.status || 'Inactive',
            trainerId: member.trainerId || '', 
            goal: member.goal || '',
        });
        setActionError(''); setIsAddEditModalOpen(true);
    }, [initialFormData]); 

    const closeModal = () => {
        setIsAddEditModalOpen(false); setIsInfoModalOpen(false); setIsDeleteConfirmOpen(false); setIsRenewModalOpen(false);
        setCurrentMember(null); setSelectedMemberForInfo(null); setMemberToDelete(null); setMemberToRenew(null);
        setRenewalPlanId(''); setActionError('');
    };

    const handleFormChange = (event) => {
        const { name, value } = event.target;
        setFormData(prev => ({ ...prev, [name]: value }));
    };

    const openInfoModal = (member) => { setSelectedMemberForInfo(member); setActiveInfoTab('info'); setIsInfoModalOpen(true); };
    const openDeleteConfirmModal = (member) => { setMemberToDelete(member); setIsDeleteConfirmOpen(true); };
    const openRenewModal = (member) => { setMemberToRenew(member); setRenewalPlanId(member.currentPlanId || subscriptionPacksFromUtils[0]?.id || ''); setIsRenewModalOpen(true); setActionError(''); };

    const handleFormSubmit = async (event) => {
        event.preventDefault();
        if (!currentBranchId) { alert("Critical error: No branch selected."); setActionError("No branch selected."); return; }
        setActionError(''); setIsSubmitting(true);
        
        const packDetails = getPackInfo(formData.currentPlanId);
        if (!packDetails || !packDetails.id) { setActionError("Invalid subscription plan."); setIsSubmitting(false); return; }
        
        let validatedJoiningDate = formData.joiningDate || getTodayDateStringForForm();
        if (!validatedJoiningDate.match(/^\d{4}-\d{2}-\d{2}$/)) { setActionError("Invalid joining date (YYYY-MM-DD)."); setIsSubmitting(false); return; }
        if (formData.dob && formData.dob.trim() !== "" && !formData.dob.match(/^\d{4}-\d{2}-\d{2}$/)) { setActionError("Invalid DOB (YYYY-MM-DD)."); setIsSubmitting(false); return; }

        const memberPayload = {
            name: formData.name, email: formData.email || null, phone: formData.phone, gender: formData.gender,
            dob: formData.dob || null, joiningDate: validatedJoiningDate, currentPlanId: formData.currentPlanId,
            status: formData.status,
            trainerId: formData.trainerId || null, 
            goal: formData.goal || null,
        };

        if (modalMode === 'add') {
            memberPayload.status = 'Active'; 
        }

        const token = localStorage.getItem('gymUserToken');
        if (!token) { setActionError("Authentication error. Please log in again."); setIsSubmitting(false); return; }
        
        const url = modalMode === 'add' 
            ? `http://localhost:5001/api/branches/${currentBranchId}/members` 
            : `http://localhost:5001/api/branches/${currentBranchId}/members/${currentMember._id}`;
        const method = modalMode === 'add' ? 'POST' : 'PUT';

        try {
            const response = await fetch(url, { 
                method, 
                headers: { 'Authorization': `Bearer ${token}`, 'Content-Type': 'application/json' }, 
                body: JSON.stringify(memberPayload) 
            });
            const data = await response.json();
            if (!response.ok) throw new Error(data.message || `Server error: ${response.status}`);
            
            if (data.success && data.member) {
                await fetchBranchMembers(currentBranchId, '', true); 
                alert(`Member ${modalMode === 'add' ? 'added' : 'updated'} successfully!`);
                closeModal();
            } else { 
                throw new Error(data.message || `Failed to ${modalMode} member.`); 
            }
        } catch (err) { 
            setActionError(`${modalMode === 'add' ? 'Add' : 'Edit'} Member Failed: ${err.message}`);
        } finally { 
            setIsSubmitting(false); 
        }
    };

    const handleRenewSubmit = async (event) => {
        event.preventDefault();
        if (!memberToRenew || !memberToRenew._id || !currentBranchId || !renewalPlanId) { setActionError("Cannot process renewal: missing information."); return; }
        setActionError(''); setIsRenewing(true);
        const token = localStorage.getItem('gymUserToken');
        if (!token) { setActionError("Authentication error."); setIsRenewing(false); return; }
        try {
            const response = await fetch(`http://localhost:5001/api/branches/${currentBranchId}/members/${memberToRenew._id}/renew`, {
                method: 'PUT', headers: { 'Authorization': `Bearer ${token}`, 'Content-Type': 'application/json' },
                body: JSON.stringify({ newSubscriptionPackId: renewalPlanId })
            });
            const data = await response.json();
            if (!response.ok) throw new Error(data.message || `Server error ${response.status}`);
            if (data.success && data.member) {
                await fetchBranchMembers(currentBranchId, '', true); 
                alert(data.message || "Subscription renewed/updated successfully!");
                closeModal();
            } else { throw new Error(data.message || "Failed to renew subscription."); }
        } catch (err) { setActionError(`Renew Failed: ${err.message}`);
        } finally { setIsRenewing(false); }
    };

    // Function to handle the actual deletion of a member
    const confirmDeleteMember = async () => {
        if (!memberToDelete || !memberToDelete._id || !currentBranchId) {
            alert("No member selected for deletion or branch context is missing.");
            closeModal(); // Close confirmation modal
            return;
        }
        setActionError(''); 
        setIsDeleting(true); // Set loading state for deletion
        const token = localStorage.getItem('gymUserToken');
        if (!token) {
            setActionError("Authentication error. Please log in again.");
            setIsDeleting(false);
            closeModal();
            return;
        }
        try {
            const response = await fetch(`http://localhost:5001/api/branches/${currentBranchId}/members/${memberToDelete._id}`, {
                method: 'DELETE',
                headers: { 'Authorization': `Bearer ${token}` }
            });
            const data = await response.json();
            if (!response.ok) {
                throw new Error(data.message || `Server error: ${response.status}`);
            }
            if (data.success) {
                await fetchBranchMembers(currentBranchId, '', true); // Refresh the member list
                alert("Member deleted successfully!");
                // The modal is closed in the finally block
            } else {
                throw new Error(data.message || "Failed to delete member.");
            }
        } catch (err) {
            setActionError(`Delete Failed: ${err.message}`);
            // Potentially show error to user via toast or modal error message
        } finally {
            setIsDeleting(false); // Reset loading state
            closeModal(); // Ensure modal is closed regardless of outcome
        }
    };


    const activeTrainers = useMemo(() => {
        const trainersData = currentBranchId ? allTrainersFromContext?.[currentBranchId] : null;
        const trainersInBranchList = trainersData?.initialList || []; 
        return Array.isArray(trainersInBranchList) ? trainersInBranchList.filter(t => t.status === 'Active') : [];
    }, [allTrainersFromContext, currentBranchId]);

    const renderTrainerCellContent = useCallback((member) => {
        if (member && member.trainerId && member.trainerName) {
            return member.trainerName;
        }
        if (member && (member.status === 'Active' || member.status === 'Inactive' || member.status === 'Frozen' || !member.trainerId)) {
            return (
                <button
                    className="members-btn-assign-trainer"
                    onClick={(e) => { e.stopPropagation(); openEditModal(member); }}
                    title="Assign/Change Trainer (Edit Member)"
                >
                    <FiUserPlus /> Assign
                </button>
            );
        }
        return <span className="members-text-muted">-</span>; 
    }, [openEditModal]); 


    return (
        <div className="members-component-wrapper">
            <div className="members-page-container">
                {(isFetchingMembers || isSubmitting || isDeleting || isRenewing) && ( <div className="members-loading-overlay"><FiLoader className="members-loading-spinner-large" /><span>{isFetchingMembers && !isSubmitting && !isDeleting && !isRenewing ? 'Fetching Members...' : (isSubmitting ? 'Saving...' : (isDeleting ? 'Deleting...' : (isRenewing ? 'Processing Payment...' : 'Loading...')))}</span></div> )}
                {actionError && <div className="members-action-error-toast">{actionError} <button onClick={() => setActionError('')}>&times;</button></div>}

                <header className="members-header">
                    <h1 className="members-title">Members {currentBranchId ? `(${gymInfo?.branches?.find(b=>b.id === currentBranchId)?.name || 'Current Branch'})` : '(No Branch Selected)'}</h1>
                    <div className="members-actions">
                        <div className="members-search-bar">
                            <FiSearch className="members-search-icon" />
                            <input type="text" placeholder="Search by Exact Name or ID" value={searchTerm} onChange={(e) => setSearchTerm(e.target.value)} disabled={!currentBranchId || isFetchingMembers} className="members-search-input"/>
                        </div>
                        <button className="members-btn members-btn-primary members-add-member-button" onClick={openAddModal} disabled={!currentBranchId || isFetchingMembers}><FiUserPlus /> Add Member</button>
                    </div>
                </header>

                <section className="members-stats-grid">
                    <div className="members-stat-card"><span className="members-stat-value">{memberStats.total}</span><span className="members-stat-label">Total Members</span></div>
                    <div className="members-stat-card members-stat-active"><span className="members-stat-value">{memberStats.active}</span><span className="members-stat-label">Active</span></div>
                    <div className="members-stat-card members-stat-inactive"><span className="members-stat-value">{memberStats.inactive}</span><span className="members-stat-label">Inactive</span></div>
                    <div className="members-stat-card members-stat-expired"><span className="members-stat-value">{memberStats.expired}</span><span className="members-stat-label">Expired</span></div>
                    <div className="members-stat-card members-stat-frozen"><span className="members-stat-value">{memberStats.frozen}</span><span className="members-stat-label">Frozen</span></div>
                </section>

                {currentBranchId && (
                    <section className="members-quick-filter-section members-card-style">
                        <h3 className="members-quick-filter-title"><FiFilter /> Quick Filters</h3>
                        <div className="members-quick-filter-buttons">
                            <button className={`members-quick-filter-button ${activeQuickFilter === 'all' ? 'active' : ''}`} onClick={() => setActiveQuickFilter('all')} disabled={isFetchingMembers}> <FiList /> All </button>
                            <button className={`members-quick-filter-button ${activeQuickFilter === 'endingToday' ? 'active' : ''}`} onClick={() => setActiveQuickFilter('endingToday')} disabled={isFetchingMembers}> <FiZap /> Ending Today </button>
                            <button className={`members-quick-filter-button ${activeQuickFilter === 'endingNext3Days' ? 'active' : ''}`} onClick={() => setActiveQuickFilter('endingNext3Days')} disabled={isFetchingMembers}> <FiAlertTriangle /> Ending in 3 Days </button>
                            <button className={`members-quick-filter-button members-status-filter-active ${activeQuickFilter === 'active' ? 'active' : ''}`} onClick={() => setActiveQuickFilter('active')} disabled={isFetchingMembers}> <FiCheckCircle /> Active </button>
                            <button className={`members-quick-filter-button members-status-filter-inactive ${activeQuickFilter === 'inactive' ? 'active' : ''}`} onClick={() => setActiveQuickFilter('inactive')} disabled={isFetchingMembers}> <FiPauseCircle /> Inactive </button>
                            <button className={`members-quick-filter-button members-status-filter-expired ${activeQuickFilter === 'expired' ? 'active' : ''}`} onClick={() => setActiveQuickFilter('expired')} disabled={isFetchingMembers}> <FiXCircle /> Expired </button>
                             <button className={`members-quick-filter-button members-status-filter-frozen ${activeQuickFilter === 'frozen' ? 'active' : ''}`} onClick={() => setActiveQuickFilter('frozen')} disabled={isFetchingMembers}> <FiShield /> Frozen </button>
                        </div>
                    </section>
                )}

                <div className="members-table-container members-card-style">
                    <h2 className="members-table-title">
                        {activeQuickFilter === 'all' && 'All Members'}
                        {activeQuickFilter === 'endingToday' && 'Memberships Ending Today'}
                        {activeQuickFilter === 'endingNext3Days' && 'Memberships Ending in Next 3 Days'}
                        {activeQuickFilter === 'active' && 'Active Members'}
                        {activeQuickFilter === 'inactive' && 'Inactive Members'}
                        {activeQuickFilter === 'expired' && 'Expired Members'}
                        {activeQuickFilter === 'frozen' && 'Frozen Members'}
                        {currentBranchId ? ` (${displayedMembers.length} shown)`: ''}
                    </h2>
                    <div className="members-table-scroll">
                        {!currentBranchId ? ( <p className="members-no-members-message">Please select a branch to view members.</p> ) :
                        isFetchingMembers && displayedMembers.length === 0 ? (<div className="members-loading-table"><FiLoader className="members-loading-spinner-small"/> Loading members...</div>) :
                        displayedMembers.length > 0 ? (
                            <table className="members-table">
                                <thead><tr><th>ID</th><th>Name</th><th>Trainer</th><th>Joining Date</th><th>Subscription End</th><th>Days Left</th><th>Payment Due</th><th>Status</th><th className="members-actions-column">Actions</th></tr></thead>
                                <tbody>
                                    {displayedMembers.map(member => {
                                        const memberKey = member._id || member.id || member.displayMemberId; 
                                        const daysRemainingInfo = calculateDaysRemaining(member.endDate);
                                        return (
                                            <tr key={memberKey}>
                                                <td>{member.displayMemberId || 'N/A'}</td>
                                                <td><button className="members-member-name-button" onClick={() => openInfoModal(member)}>{member.name}</button></td>
                                                <td>{renderTrainerCellContent(member)}</td>
                                                <td>{formatDate(member.joiningDate)}</td>
                                                <td>{formatDate(member.endDate)}</td>
                                                <td className={`members-days-remaining-cell ${daysRemainingInfo.className}`}><span className={`members-days-remaining-badge ${daysRemainingInfo.className}`}>{daysRemainingInfo.text}</span></td>
                                                <td>{formatDate(member.paymentDueDate)}</td>
                                                <td><span className={`members-status-badge members-status-${member.status?.toLowerCase().replace(' ', '-')}`}>{member.status}</span></td>
                                                <td className="members-action-buttons">
                                                    <button className="members-action-button members-action-view" onClick={() => openInfoModal(member)} title="View Member Info"> <FiEye /> </button>
                                                    {(member.status === 'Active' || member.status === 'Inactive' || member.status === 'Expired' || member.status === 'Frozen') && (
                                                        <button
                                                            className={`members-action-button ${member.status === 'Active' ? 'members-action-pay' : 'members-action-renew'}`}
                                                            onClick={() => openRenewModal(member)}
                                                            title={member.status === 'Active' ? "Mark as Paid & Extend" : "Renew/Reactivate Subscription"}
                                                        >
                                                            {member.status === 'Active' ? <FiDollarSign /> : <FiRefreshCw />}
                                                        </button>
                                                    )}
                                                    <button className="members-action-button members-action-edit" onClick={() => openEditModal(member)} title="Edit Member"> <FiEdit /> </button>
                                                    {/* Delete button calling openDeleteConfirmModal */}
                                                    <button className="members-action-button members-action-delete" onClick={() => openDeleteConfirmModal(member)} title="Delete Member"> <FiTrash2 /> </button>
                                                </td>
                                            </tr>
                                        );
                                    })}
                                </tbody>
                            </table>
                        ) : ( <p className="members-no-members-message">{searchTerm ? 'No members found matching search and filter.' : (activeQuickFilter !== 'all' ? 'No members match the current filter.' : 'No members added to this branch yet.')}</p> )}
                    </div>
                </div>

                {/* Add/Edit Member Modal */}
                {isAddEditModalOpen && (
                    <div className="members-modal-overlay">
                        <div className="members-modal-content members-card-style">
                            <div className="members-modal-header">
                                <h2 className="members-modal-title">{modalMode === 'add' ? 'Add New Member' : `Edit Member (ID: ${currentMember?.displayMemberId || 'N/A'})`}</h2>
                                <button className="members-modal-close-button" onClick={closeModal}><FiX /></button>
                            </div>
                            <div className="members-modal-body">
                                <form onSubmit={handleFormSubmit} className="members-modal-form">
                                    <div className="members-form-grid">
                                        <div className="members-form-group"> <label htmlFor="memberName"><FiUser /> Name*</label> <input type="text" id="memberName" name="name" value={formData.name} onChange={handleFormChange} required className="members-form-input" disabled={isSubmitting}/> </div>
                                        <div className="members-form-group"> <label htmlFor="phone"><FiPhone /> Phone*</label> <input type="tel" id="phone" name="phone" value={formData.phone} onChange={handleFormChange} required className="members-form-input" disabled={isSubmitting}/> </div>
                                        <div className="members-form-group"> <label htmlFor="email"><FiMail /> Email</label> <input type="email" id="email" name="email" value={formData.email} onChange={handleFormChange} className="members-form-input" disabled={isSubmitting}/> </div>
                                        <div className="members-form-group"> <label htmlFor="gender"><FiUsers /> Gender</label> <select id="gender" name="gender" value={formData.gender} onChange={handleFormChange} className="members-form-select" disabled={isSubmitting}><option value="Male">Male</option><option value="Female">Female</option><option value="Other">Other</option></select> </div>
                                        <div className="members-form-group"> <label htmlFor="dob"><FiGift /> Date of Birth</label> <input type="date" id="dob" name="dob" value={formData.dob} onChange={handleFormChange} max={getTodayDateStringForForm()} className="members-form-input" disabled={isSubmitting}/> </div>
                                        <div className="members-form-group"> <label htmlFor="joiningDate"><FiCalendar /> Joining Date*</label> <input type="date" id="joiningDate" name="joiningDate" value={formData.joiningDate} onChange={handleFormChange} required max={getTodayDateStringForForm()} className="members-form-input" disabled={isSubmitting}/> </div>
                                        <div className="members-form-group"> <label htmlFor="currentPlanId"><FiPackage /> Subscription Plan*</label> <select id="currentPlanId" name="currentPlanId" value={formData.currentPlanId} onChange={handleFormChange} required className="members-form-select" disabled={isSubmitting}><option value="" disabled>-- Select Plan --</option>{subscriptionPacksFromUtils.map(pack => (<option key={pack.id} value={pack.id}> {pack.name} - PKR {pack.price.toLocaleString()} </option>))}</select> </div>
                                        {modalMode === 'edit' && (<div className="members-form-group"> <label htmlFor="memberStatus"><FiClock /> Status*</label> <select id="memberStatus" name="status" value={formData.status} onChange={handleFormChange} required className="members-form-select" disabled={isSubmitting}><option value="Active">Active</option><option value="Inactive">Inactive</option><option value="Expired">Expired</option><option value="Frozen">Frozen</option></select></div>)}
                                        <div className="members-form-group"> <label htmlFor="trainerId"><FiAward /> Assign Trainer</label> <select id="trainerId" name="trainerId" value={formData.trainerId} onChange={handleFormChange} className="members-form-select" disabled={isSubmitting}><option value="">-- No Trainer --</option>{activeTrainers.map(trainer => (<option key={trainer._id} value={trainer._id}>{trainer.name}</option>))}</select> </div>
                                        <div className="members-form-group"> <label htmlFor="goal"><FiTrendingUp /> Goal</label> <input type="text" id="goal" name="goal" placeholder="e.g., Weight loss, Muscle gain" value={formData.goal} onChange={handleFormChange} className="members-form-input" disabled={isSubmitting}/> </div>
                                    </div>
                                    <div className="members-modal-actions">
                                        <button type="button" className="members-btn members-btn-secondary" onClick={closeModal} disabled={isSubmitting}> <FiX /> Cancel </button>
                                        <button type="submit" className="members-btn members-btn-primary" disabled={isSubmitting}> {isSubmitting ? (modalMode === 'add' ? 'Adding...' : 'Saving...') : (modalMode === 'add' ? <><FiCheck /> Add Member</> : <><FiCheck /> Save Changes</>)} </button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                )}

                {/* View Info Modal */}
                {isInfoModalOpen && selectedMemberForInfo && (
                     <div className="members-modal-overlay members-info-history-modal-overlay">
                     <div className="members-modal-content members-info-history-modal-content members-card-style">
                           <div className="members-info-modal-header">
                                 <div className="members-info-profile-img-placeholder"><FiUser/></div>
                                 <div>
                                     <h2 className="members-modal-title">{selectedMemberForInfo.name}</h2>
                                     <span className={`members-status-badge members-status-${selectedMemberForInfo.status?.toLowerCase().replace(' ','-') ?? 'unknown'}`}>{selectedMemberForInfo.status ?? 'Unknown'}</span>
                                 </div>
                                 <button className="members-modal-close-button" onClick={closeModal}><FiX /></button>
                           </div>
                           <div className="members-modal-body">
                                 <div className="members-modal-tabs">
                                     <button className={`members-tab-button ${activeInfoTab === 'info' ? 'active' : ''}`} onClick={() => setActiveInfoTab('info')}> <FiInfo /> Details </button>
                                     <button className={`members-tab-button ${activeInfoTab === 'payment' ? 'active' : ''}`} onClick={() => setActiveInfoTab('payment')}> <FiDollarSign /> Payments </button>
                                     <button className={`members-tab-button ${activeInfoTab === 'activity' ? 'active' : ''}`} onClick={() => setActiveInfoTab('activity')}> <FiActivity /> Activity Log</button>
                                 </div>
                                 <div className="members-modal-tab-content">
                                     {activeInfoTab === 'info' && (
                                         <div className="members-info-section">
                                               <div className="members-info-grid">
                                                   <div className="members-info-item"> <span className="members-info-label"><FiTag /> Member ID:</span> <span className="members-info-value">{selectedMemberForInfo.displayMemberId || 'N/A'}</span> </div>
                                                   <div className="members-info-item"> <span className="members-info-label"><FiMail /> Email:</span> <span className="members-info-value">{selectedMemberForInfo.email || <span className="members-text-muted">N/A</span>}</span> </div>
                                                   <div className="members-info-item"> <span className="members-info-label"><FiPhone /> Phone:</span> <span className="members-info-value">{selectedMemberForInfo.phone || <span className="members-text-muted">N/A</span>}</span> </div>
                                                   <div className="members-info-item"> <span className="members-info-label"><FiUsers /> Gender:</span> <span className="members-info-value">{selectedMemberForInfo.gender || <span className="members-text-muted">N/A</span>}</span> </div>
                                                   <div className="members-info-item"> <span className="members-info-label"><FiGift /> Age:</span> <span className="members-info-value">{calculateAge(selectedMemberForInfo.dob)}</span> </div>
                                                   <div className="members-info-item"> <span className="members-info-label"><FiCalendar /> Joined:</span> <span className="members-info-value">{formatDate(selectedMemberForInfo.joiningDate)}</span> </div>
                                                   <div className="members-info-item"> <span className="members-info-label"><FiCalendar /> Expires:</span> <span className="members-info-value">{formatDate(selectedMemberForInfo.endDate)}</span> </div>
                                                   <div className="members-info-item"> <span className="members-info-label"><FiPackage /> Current Plan:</span> <span className="members-info-value">{getPackInfo(selectedMemberForInfo.currentPlanId)?.name || 'N/A'}</span> </div>
                                                   <div className="members-info-item">
                                                        <span className="members-info-label"><FiAward /> Trainer:</span>
                                                        <span className="members-info-value">
                                                            {selectedMemberForInfo.trainerName || 
                                                                (selectedMemberForInfo.trainerId && getTrainerDetails ? 
                                                                    (getTrainerDetails(selectedMemberForInfo.trainerId)?.name || <span className="members-text-muted">N/A (Lookup Failed)</span>) 
                                                                    : <span className="members-text-muted">- None -</span>)
                                                            }
                                                        </span>
                                                    </div>
                                                   <div className="members-info-item"> <span className="members-info-label"><FiDollarSign /> Last Payment:</span> <span className="members-info-value">{formatDate(selectedMemberForInfo.lastPaymentDate)}</span> </div>
                                                   <div className="members-info-item members-info-item-full"> <span className="members-info-label"><FiTrendingUp /> Goal:</span> <span className="members-info-value">{selectedMemberForInfo.goal || <span className="members-text-muted">N/A</span>}</span> </div>
                                               </div>
                                         </div>
                                     )}
                                     {activeInfoTab === 'payment' && ( <div className="members-history-section"> <div className="members-history-list members-payment-history-list"> {(Array.isArray(selectedMemberForInfo.history) && selectedMemberForInfo.history.filter(item => item.event === 'Payment' || item.event === 'Renewal' || item.event === 'Payment & Extension').length > 0) ? ( selectedMemberForInfo.history.filter(item => item.event === 'Payment' || item.event === 'Renewal' || item.event === 'Payment & Extension').sort((a, b) => new Date(b.date + 'T00:00:00Z') - new Date(a.date + 'T00:00:00Z')).map((item, index) => ( <div key={`payment-${item._id || index}`} className="members-history-item members-payment-item"> <span className="members-history-icon members-event-icon-payment"><FiDollarSign /></span> <div className="members-history-content"> <span className="members-history-date">{formatDate(item.date)}</span> {item.amountPaid !== undefined && typeof item.amountPaid === 'number' && ( <span className="members-history-amount">PKR {item.amountPaid.toLocaleString()}</span> )} <p className="members-history-details">{item.details} {item.planName && `(${item.planName})`}</p> </div> </div> ))) : ( <p className="members-no-history"><FiInfo/> No payment records found.</p> )} </div> </div> )}
                                     {activeInfoTab === 'activity' && ( <div className="members-history-section"> <div className="members-history-list members-activity-history-list"> {(Array.isArray(selectedMemberForInfo.history) && selectedMemberForInfo.history.length > 0) ? ( selectedMemberForInfo.history.sort((a, b) => new Date(b.entryCreatedAt || b.date + 'T00:00:00Z') - new Date(a.entryCreatedAt || a.date + 'T00:00:00Z')).map((item, index) => ( <div key={`activity-${item._id || index}`} className="members-history-item"> <span className={`members-history-icon members-event-icon-${item.event?.toLowerCase().replace(/[^a-z0-9]+/g, '-') ?? 'unknown'}`}> {item.event === 'Joined' && <FiUserPlus/>} {item.event === 'Expired' && <FiXCircle/>} {item.event === 'Status Change' && <FiClock/>} {item.event === 'Subscription Change' && <FiPackage/>} {item.event === 'Info Update' && <FiEdit/>} {item.event === 'Trainer Assigned' && <FiAward/>} {item.event === 'Trainer Unassigned' && <FiUserMinus/>} {item.event === 'Payment' && <FiDollarSign/>} {item.event === 'Renewal' && <FiRefreshCw/>} {item.event === 'Payment & Extension' && <FiDollarSign/>} {!(item.event === 'Joined' || item.event === 'Expired' || item.event === 'Status Change' || item.event === 'Subscription Change' || item.event === 'Info Update' || item.event === 'Trainer Assigned' || item.event === 'Trainer Unassigned' || item.event === 'Payment' || item.event === 'Renewal' || item.event === 'Payment & Extension') && <FiActivity/>} </span> <div className="members-history-content"> <span className="members-history-date">{formatDate(item.date)}</span> <span className={`members-history-event members-history-event-${item.event?.toLowerCase().replace(/[^a-z0-9]+/g, '-') ?? 'unknown'}`}>{item.event ?? 'Unknown Event'}</span> <p className="members-history-details">{item.details}</p> </div> </div> ))) : ( <p className="members-no-history"><FiInfo/> No activity recorded.</p> )} </div> </div> )}
                                 </div>
                           </div>
                           <div className="members-modal-actions"> <button type="button" className="members-btn members-btn-secondary" onClick={closeModal}> Close </button> </div>
                     </div>
                   </div>
                )}

                {/* Renew Subscription Modal */}
                {isRenewModalOpen && memberToRenew && (
                    <div className="members-modal-overlay">
                        <div className="members-modal-content members-card-style members-renew-modal-content">
                            <div className="members-modal-header">
                                <h2 className="members-modal-title">Renew Subscription for {memberToRenew.name}</h2>
                                <button className="members-modal-close-button" onClick={closeModal}><FiX /></button>
                            </div>
                            <div className="members-modal-body">
                                <form onSubmit={handleRenewSubmit} className="members-modal-form">
                                    <p className="members-renew-info">
                                        Current Plan: {getPackInfo(memberToRenew.currentPlanId)?.name || 'N/A'} <br />
                                        Expires on: {formatDate(memberToRenew.endDate)}
                                    </p>
                                    <div className="members-form-group">
                                        <label htmlFor="renewalPlanId"><FiPackage /> Select Plan for Renewal</label>
                                        <select
                                            id="renewalPlanId"
                                            name="renewalPlanId"
                                            value={renewalPlanId}
                                            onChange={(e) => setRenewalPlanId(e.target.value)}
                                            required
                                            className="members-form-select"
                                            disabled={isRenewing}
                                        >
                                            {subscriptionPacksFromUtils.map(pack => (
                                                <option key={pack.id} value={pack.id}>
                                                    {pack.name} - PKR {pack.price.toLocaleString()}
                                                </option>
                                            ))}
                                        </select>
                                    </div>
                                    <div className="members-modal-actions">
                                        <button type="button" className="members-btn members-btn-secondary" onClick={closeModal} disabled={isRenewing}>Cancel</button>
                                        <button type="submit" className="members-btn members-btn-primary" disabled={isRenewing}>
                                            {isRenewing ? <FiLoader className="members-button-loader"/> : <FiCheck />}
                                            Renew & Mark Paid (PKR {getPackInfo(renewalPlanId)?.price.toLocaleString() || '0'})
                                        </button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                )}

                {/* Delete Confirmation Modal */}
                {isDeleteConfirmOpen && memberToDelete && (
                    <div className="members-modal-overlay members-delete-confirm-overlay">
                        <div className="members-modal-content members-delete-modal-content members-card-style">
                            <div className="members-modal-header members-delete-modal-header">
                                <div className="members-delete-modal-icon"><FiAlertTriangle/></div>
                                <h2 className="members-modal-title members-delete-title">Confirm Deletion</h2>
                                <button className="members-modal-close-button" onClick={closeModal}><FiX /></button>
                            </div>
                            <div className="members-modal-body">
                                <p className="members-confirm-message">
                                    Are you sure you want to delete member <strong className="members-highlight-name">{memberToDelete.name}</strong> (ID: <strong className="members-highlight-id">{memberToDelete.displayMemberId || memberToDelete._id}</strong>)?
                                    <br /> This action cannot be undone.
                                </p>
                            </div>
                            <div className="members-modal-actions members-delete-actions">
                                <button type="button" className="members-btn members-btn-secondary" onClick={closeModal} disabled={isDeleting}>
                                    <FiX/> Cancel
                                </button>
                                <button type="button" className="members-btn members-btn-danger" onClick={confirmDeleteMember} disabled={isDeleting}>
                                    {isDeleting ? <FiLoader className="members-button-loader"/> : <FiTrash2 />} Confirm Delete
                                </button>
                            </div>
                        </div>
                    </div>
                )}
            </div>
        </div>
    );
}

export default Members;
