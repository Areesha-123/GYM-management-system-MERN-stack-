import React, { useState, useEffect, useMemo, useCallback } from 'react';
import { Outlet, NavLink, useLocation, useNavigate, useOutletContext } from 'react-router-dom';
import '../styles/DashboardScreen.css';
import {
    FiUsers, FiActivity, FiCalendar, FiUser, FiHome, FiBarChart2,
    FiMapPin, FiChevronDown, FiLogOut, FiPlusCircle, FiTrash2, FiX, FiClock, FiImage, FiTrendingUp, FiDollarSign, FiLoader, FiCreditCard, FiAlertTriangle
} from 'react-icons/fi';

// --- UTILITY FUNCTIONS ---
// Defines available subscription plans
const subscriptionPacks = [
    { id: 'student_1m', type: 'Student', durationMonths: 1, name: 'Student - 1 Month', price: 3000 },
    { id: 'student_3m', type: 'Student', durationMonths: 3, name: 'Student - 3 Months', price: 8000 },
    { id: 'solo_1m', type: 'Solo', durationMonths: 1, name: 'Solo - 1 Month', price: 5000 },
    { id: 'solo_3m', type: 'Solo', durationMonths: 3, name: 'Solo - 3 Months', price: 13500 },
    { id: 'solo_6m', type: 'Solo', durationMonths: 6, name: 'Solo - 6 Months', price: 25000 },
    { id: 'solo_12m', type: 'Solo', durationMonths: 12, name: 'Solo - 1 Year', price: 45000 },
];
// Finds details for a given pack ID
const getPackDetails = (packId) => subscriptionPacks.find(p => p.id === packId) || { name: 'N/A', price: 0, durationMonths: 0, type: 'N/A' };

// Formats a date into YYYY-MM-DD string
const formatDateToYYYYMMDD = (date) => {
    if (!(date instanceof Date) || isNaN(date)) {
        if (typeof date === 'string' && /^\d{4}-\d{2}-\d{2}$/.test(date)) { return date; }
        return '';
    }
    const year = date.getFullYear();
    const month = String(date.getMonth() + 1).padStart(2, '0');
    const day = String(date.getDate()).padStart(2, '0');
    return `${year}-${month}-${day}`;
};

// Formats a date string into a more readable format (e.g., DD Mon YYYY)
const formatDate = (dateString, includeTime = false) => {
    if (!dateString) return 'N/A';
    try {
        let date;
        if (dateString.includes('T') || dateString.includes(' ')) {
            date = new Date(dateString);
        } else if (dateString.match(/^\d{4}-\d{2}-\d{2}$/)) {
            const parts = dateString.split('-');
            date = new Date(Date.UTC(parseInt(parts[0], 10), parseInt(parts[1], 10) - 1, parseInt(parts[2], 10)));
        } else {
            date = new Date(dateString);
        }
        if (isNaN(date.getTime())) return dateString;
        const options = {
            day: '2-digit', month: 'short', year: 'numeric',
            timeZone: (dateString.match(/^\d{4}-\d{2}-\d{2}$/) && !dateString.includes('T')) || (dateString.includes('T') && dateString.endsWith('Z')) ? 'UTC' : undefined
        };
        if (includeTime) { options.hour = '2-digit'; options.minute = '2-digit';}
        return date.toLocaleDateString('en-GB', options);
    } catch (e) {
        return dateString;
    }
};

// Gets today's date as a YYYY-MM-DD string
const getTodayDateString = () => formatDateToYYYYMMDD(new Date());
// Gets the first day of the current month as a YYYY-MM-DD string
const getStartOfMonthString = (date = new Date()) => { const year = date.getFullYear(); const month = String(date.getMonth() + 1).padStart(2, '0'); return `${year}-${month}-01`; };
// Gets the current month and year as a YYYY-MM string
const getCurrentMonthYYYYMM = (date = new Date()) => { const year = date.getFullYear(); const month = String(date.getMonth() + 1).padStart(2, '0'); return `${year}-${month}`; };
// Formats a number as currency (PKR)
const formatCurrency = (amount, currency = 'PKR') => { const numericAmount = Number(amount); return new Intl.NumberFormat('en-PK', { style: 'currency', currency: currency, minimumFractionDigits: 0, maximumFractionDigits: 2, }).format(isNaN(numericAmount) ? 0 : numericAmount); };
// --- END OF UTILITY FUNCTIONS ---

// Component to display the dashboard overview content for a selected branch
const DashboardOverviewContent = ({
    currentBranchData, currentBranchId, trainers, allMembers, allScheduledClasses, isOverviewLoading
}) => {
    // Filter upcoming classes for the current branch
    const classesForCurrentBranch = useMemo(() => (currentBranchId && allScheduledClasses[currentBranchId]) ? allScheduledClasses[currentBranchId] : [], [allScheduledClasses, currentBranchId]);
    const upcomingBranchClasses = useMemo(() => Array.isArray(classesForCurrentBranch) ? classesForCurrentBranch.filter(cls => cls.status === 'upcoming') : [], [classesForCurrentBranch]);
    // Get trainers for the current branch
    const branchTrainers = useMemo(() => trainers || [], [trainers]);

    // Placeholder values for trainer payments (logic not present in this component)
    const totalPaidToBranchTrainersThisMonth = 0;
    const totalPendingBranchTrainerSalaryThisMonth = 0;
    const totalTrainersCountInBranch = branchTrainers.length;

    // Show loading spinner if overview data is loading
    if (isOverviewLoading) {
        return (
            <div className="dashboard-loading-container" style={{ gridColumn: '1 / -1', display: 'flex', justifyContent: 'center', alignItems: 'center', minHeight: '300px' }}>
                <FiLoader className="dashboard-loading-spinner" />
                <span>Loading Branch Overview Data...</span>
            </div>
        );
    }

    // Render the overview content
    return (
        <>
            {/* Section for key metrics */}
            <section className="dashboard-metrics-section">
                <h2 className="dashboard-section-title">Key Metrics ({currentBranchData ? currentBranchData.name : 'Loading...'})</h2>
                {/* Display metrics if branch data is available */}
                {currentBranchData ? (
                    <div className="dashboard-metrics-grid">
                        <div className="dashboard-metric-card dashboard-card"><div className="dashboard-metric-icon-container bg-blue-100 text-blue-600"> <FiUsers className="dashboard-metric-icon" /> </div><div className="dashboard-metric-details"><div className="dashboard-metric-value">{currentBranchData.totalMembers?.toLocaleString() ?? '0'}</div><div className="dashboard-metric-label">Total Members</div></div></div>
                        <div className="dashboard-metric-card dashboard-card"><div className="dashboard-metric-icon-container bg-green-100 text-green-600"> <FiActivity className="dashboard-metric-icon" /> </div><div className="dashboard-metric-details"><div className="dashboard-metric-value">{currentBranchData.activeMembers?.toLocaleString() ?? '0'}</div><div className="dashboard-metric-label">Active Members</div></div></div>
                        <div className="dashboard-metric-card dashboard-card"><div className="dashboard-metric-icon-container bg-yellow-100 text-yellow-600"> <FiClock className="dashboard-metric-icon" /> </div><div className="dashboard-metric-details"><div className="dashboard-metric-value">{currentBranchData.paymentsDueToday?.toLocaleString() ?? '0'}</div><div className="dashboard-metric-label">Payments Due Today</div></div></div>
                        <div className="dashboard-metric-card dashboard-card"><div className="dashboard-metric-icon-container bg-purple-100 text-purple-600"> <FiCalendar className="dashboard-metric-icon" /> </div><div className="dashboard-metric-details"><div className="dashboard-metric-value">{currentBranchData.upcomingEvents ?? '0'}</div><div className="dashboard-metric-label">Upcoming Classes</div></div></div>
                        <div className="dashboard-metric-card dashboard-card"><div className="dashboard-metric-icon-container bg-indigo-100 text-indigo-600"> <FiUser className="dashboard-metric-icon" /> </div><div className="dashboard-metric-details"><div className="dashboard-metric-value">{totalTrainersCountInBranch}</div><div className="dashboard-metric-label">Trainers (This Branch)</div></div></div>
                        <div className="dashboard-metric-card dashboard-card"><div className="dashboard-metric-icon-container bg-teal-100 text-teal-600"> <FiCreditCard className="dashboard-metric-icon" /> </div><div className="dashboard-metric-details"><div className="dashboard-metric-value dashboard-metric-value-currency">{formatCurrency(totalPaidToBranchTrainersThisMonth)}</div><div className="dashboard-metric-label">Paid to Trainers (This Month)</div></div></div>
                        <div className="dashboard-metric-card dashboard-card"><div className="dashboard-metric-icon-container bg-red-100 text-red-600"> <FiAlertTriangle className="dashboard-metric-icon" /> </div><div className="dashboard-metric-details"><div className="dashboard-metric-value dashboard-metric-value-currency">{formatCurrency(totalPendingBranchTrainerSalaryThisMonth)}</div><div className="dashboard-metric-label">Pending Salary (This Month)</div></div></div>
                        <div className="dashboard-metric-card dashboard-card dashboard-metric-card-highlight"><div className="dashboard-metric-icon-container bg-cyan-100 text-cyan-600"> <FiTrendingUp className="dashboard-metric-icon" /> </div><div className="dashboard-metric-details"><div className="dashboard-metric-value dashboard-metric-value-currency">{formatCurrency(currentBranchData.thisMonthRevenue ?? 0)}</div><div className="dashboard-metric-label">This Month Revenue</div></div></div>
                        <div className="dashboard-metric-card dashboard-card dashboard-metric-card-highlight"><div className="dashboard-metric-icon-container bg-pink-100 text-pink-600"> <FiDollarSign className="dashboard-metric-icon" /> </div><div className="dashboard-metric-details"><div className="dashboard-metric-value dashboard-metric-value-currency">{formatCurrency(currentBranchData.revenueTillDate ?? 0)}</div><div className="dashboard-metric-label">Revenue Till Date</div></div></div>
                    </div>
                ) : ( <div className="dashboard-placeholder-content dashboard-card"><FiMapPin /><p>Loading branch metrics or select a branch.</p></div> )}
            </section>
            {/* Section for upcoming classes */}
            <section className="dashboard-scheduled-classes-section">
                <h2 className="dashboard-section-title">Upcoming Classes ({currentBranchData ? currentBranchData.name : 'Loading...'})</h2>
                {/* Display classes if branch data is available */}
                {currentBranchData ? (
                    upcomingBranchClasses.length > 0 ? (
                        <div className="dashboard-scheduled-classes-grid">
                            {/* Map through upcoming classes and display each as a card */}
                            {upcomingBranchClasses.map(cls => (
                                <div key={cls._id || cls.id} className="dashboard-class-card dashboard-card">
                                    <div className="dashboard-class-image-container">
                                        {cls.imageUrl ? (
                                            <img src={cls.imageUrl} alt={cls.title} className="dashboard-class-image"
                                                onError={(e) => {
                                                    const imgElement = e.target;
                                                    if (imgElement && imgElement.style) { imgElement.style.display = 'none'; }
                                                    const nextSibling = imgElement.nextElementSibling;
                                                    if (nextSibling && nextSibling.style) { nextSibling.style.display = 'flex'; }
                                                }}
                                            />
                                        ) : null}
                                        {/* Placeholder icon if no image URL */}
                                        <div className="dashboard-class-image-placeholder" style={{ display: !cls.imageUrl ? 'flex' : 'none' }}> <FiImage /> </div>
                                    </div>
                                    {/* Class details */}
                                    <div className="dashboard-class-details">
                                        <h4 className="dashboard-class-title">{cls.title}</h4>
                                        <p className="dashboard-class-description">{cls.description}</p>
                                        <p className="dashboard-class-timing"><strong>Date:</strong> {formatDate(cls.date)}</p>
                                        <p className="dashboard-class-timing"><strong>Time:</strong> {cls.time}</p>
                                    </div>
                                </div>
                            ))}
                        </div>
                    ) : ( <div className="dashboard-placeholder-content dashboard-card"> <FiCalendar /> <p>No upcoming classes scheduled for this branch.</p> </div> )
                ) : ( <div className="dashboard-placeholder-content dashboard-card"> <FiCalendar /> <p>Select a branch to view scheduled classes.</p> </div> )}
            </section>
        </>
    );
};

// Main Dashboard Screen component
function DashboardScreen() {
    // State variables for gym info, selected branch, loading states, and errors
    const [gymInfo, setGymInfo] = useState({ name: "Loading Gym...", branches: [] });
    const [currentBranchId, setCurrentBranchId] = useState(() => localStorage.getItem('lastSelectedBranchId') || null);
    const [isLoading, setIsLoading] = useState(true);
    const [isBranchActionLoading, setIsBranchActionLoading] = useState(false);
    const [error, setError] = useState('');

    // State variables to store data fetched for all branches, keyed by branchId
    const [allScheduledClasses, setAllScheduledClasses] = useState({});
    const [allMembers, setAllMembers] = useState({});
    const [allTrainers, setAllTrainers] = useState({});
    // State to store payment history for individual trainers, keyed by branch_trainerId
    const [individualTrainerPayments, setIndividualTrainerPayments] = useState({});

    // State variables to track loading status for specific data fetches
    const [isFetchingMembers, setIsFetchingMembers] = useState(false);
    const [isFetchingBranchTrainersList, setIsFetchingBranchTrainersList] = useState(false);
    const [isFetchingClasses, setIsFetchingClasses] = useState(false);
    const [isFetchingIndividualTrainerPayments, setIsFetchingIndividualTrainerPayments] = useState(false);

    // Hooks for navigation and location
    const navigate = useNavigate();
    const location = useLocation();

    // --- Data Fetching Functions (Memoized) ---

    // Fetches members for a specific branch
    const fetchBranchMembers = useCallback(async (branchId, searchTerm = '', forceRefresh = false) => {
        if (!branchId) return;
        setIsFetchingMembers(true);
        const token = localStorage.getItem('gymUserToken');
        if (!token) {
            navigate('/login', { replace: true });
            setIsFetchingMembers(false);
            return;
        }
        let url = `http://localhost:5001/api/branches/${branchId}/members`;
        if (searchTerm) {
            url += `?search=${encodeURIComponent(searchTerm)}`;
        }
        try {
            const response = await fetch(url, { headers: { 'Authorization': `Bearer ${token}` } });
            const data = await response.json();
            if (!response.ok) throw new Error(data.message || `Failed to fetch members (HTTP ${response.status})`);
            if (data.success && Array.isArray(data.members)) {
                setAllMembers(prev => {
                    const currentBranchState = prev[branchId] || { list: [], initialList: [], lastSearchTerm: '' };
                    let newInitialList = currentBranchState.initialList;
                    if (!searchTerm && (forceRefresh || currentBranchState.initialList.length === 0)) {
                        newInitialList = data.members;
                    }
                    return {
                        ...prev,
                        [branchId]: {
                            ...currentBranchState,
                            list: data.members,
                            initialList: newInitialList,
                            lastSearchTerm: searchTerm
                        }
                    };
                });
            } else { throw new Error(data.message || "Invalid member data structure"); }
        } catch (err) {
            setError(prevError => `${prevError} FetchMembersErr(${branchId}, search: ${searchTerm}): ${err.message}. `);
            setAllMembers(prev => ({
                ...prev,
                [branchId]: prev[branchId] || { list: [], initialList: [], lastSearchTerm: searchTerm }
            }));
        } finally { setIsFetchingMembers(false); }
    }, [navigate]);

    // Fetches trainers for a specific branch
    const fetchBranchTrainersList = useCallback(async (branchId, searchTerm = '', forceRefresh = false) => {
        if (!branchId) return;
        setIsFetchingBranchTrainersList(true);
        const token = localStorage.getItem('gymUserToken');
        if (!token) {
            navigate('/login', { replace: true });
            setIsFetchingBranchTrainersList(false);
            return;
        }
        let url = `http://localhost:5001/api/branches/${branchId}/trainers`;
        if (searchTerm) {
            url += `?search=${encodeURIComponent(searchTerm)}`;
        }
        try {
            const response = await fetch(url, { headers: { 'Authorization': `Bearer ${token}` } });
            const data = await response.json();
            if (!response.ok) throw new Error(data.message || `Failed to fetch trainers (HTTP ${response.status})`);
            if (data.success && Array.isArray(data.trainers)) {
                setAllTrainers(prev => {
                    const currentBranchState = prev[branchId] || { list: [], initialList: [], lastSearchTerm: '' };
                    let newInitialList = currentBranchState.initialList;
                    if (!searchTerm && (forceRefresh || currentBranchState.initialList.length === 0)) {
                        newInitialList = data.trainers;
                    }
                    return {
                        ...prev,
                        [branchId]: {
                            ...currentBranchState,
                            list: data.trainers,
                            initialList: newInitialList,
                            lastSearchTerm: searchTerm
                        }
                    };
                });
            } else { throw new Error(data.message || "Invalid trainers data structure"); }
        } catch (err) {
            setError(prevError => `${prevError} FetchTrainersErr(${branchId}, search: ${searchTerm}): ${err.message}. `);
            setAllTrainers(prev => ({
                ...prev,
                [branchId]: prev[branchId] || { list: [], initialList: [], lastSearchTerm: searchTerm }
            }));
        } finally { setIsFetchingBranchTrainersList(false); }
    }, [navigate]);

    // Fetches scheduled classes for a specific branch
    const fetchBranchScheduledClasses = useCallback(async (branchId, forceRefresh = false) => {
        if (!branchId) return;
        setIsFetchingClasses(true);
        const token = localStorage.getItem('gymUserToken');
        if (!token) {
            navigate('/login', { replace: true });
            setIsFetchingClasses(false);
            return;
        }
        try {
            const response = await fetch(`http://localhost:5001/api/branches/${branchId}/schedule`, { headers: { 'Authorization': `Bearer ${token}` } });
            const data = await response.json();
            if (!response.ok) throw new Error(data.message || `Failed to fetch schedule (HTTP ${response.status})`);
            if (data.success && Array.isArray(data.scheduledClasses)) {
                setAllScheduledClasses(prev => ({ ...prev, [branchId]: data.scheduledClasses }));
            } else { throw new Error(data.message || "Invalid schedule data structure"); }
        } catch (err) {
            setError(prevError => `${prevError} FetchScheduleErr(${branchId}): ${err.message}. `);
            setAllScheduledClasses(prev => ({ ...prev, [branchId]: prev[branchId] || [] }));
        } finally { setIsFetchingClasses(false); }
    }, [navigate]);

    // Fetches payment history for a single trainer
    const fetchPaymentsForSingleTrainer = useCallback(async (branchId, trainerId, forceRefresh = false) => {
        if (!branchId || !trainerId) return;
        setIsFetchingIndividualTrainerPayments(true);
        const token = localStorage.getItem('gymUserToken');
        if (!token) {
            navigate('/login', { replace: true });
            setIsFetchingIndividualTrainerPayments(false);
            return [];
        }
        try {
            const response = await fetch(`http://localhost:5001/api/branches/${branchId}/trainers/${trainerId}/payments`, { headers: { 'Authorization': `Bearer ${token}` } });
            const data = await response.json();
            if (!response.ok) throw new Error(data.message || `Failed to fetch payments for trainer ${trainerId} (HTTP ${response.status})`);
            if (data.success && Array.isArray(data.payments)) {
                setIndividualTrainerPayments(prev => ({ ...prev, [`${branchId}_${trainerId}`]: data.payments })); // Key by branch_trainerId
                return data.payments;
            } else { throw new Error(data.message || "Invalid single trainer payments data structure"); }
        } catch (err) {
            setError(prevError => `${prevError} FetchSingleTrainerPaymentsErr(${trainerId}): ${err.message}. `);
            setIndividualTrainerPayments(prev => ({ ...prev, [`${branchId}_${trainerId}`]: prev[`${branchId}_${trainerId}`] || [] }));
            return [];
        } finally { setIsFetchingIndividualTrainerPayments(false); }
    }, [navigate]);

    // Fetches the initial dashboard data (gym details and branches)
    const fetchInitialDashboardData = useCallback(async (branchIdToSelectAfterAction = null) => {
        setIsLoading(true); setError(''); const token = localStorage.getItem('gymUserToken');
        if (!token) { navigate('/login', { replace: true }); setIsLoading(false); return; }
        try {
            const response = await fetch('http://localhost:5001/api/my-gym/details', { method: 'GET', headers: { 'Authorization': `Bearer ${token}` }});
            const data = await response.json();
            if (!response.ok) throw new Error(data.message || `Failed to fetch gym details (HTTP ${response.status})`);
            if (data.success && data.details) {
                const { gymName, branches: fetchedBranches = [] } = data.details;
                setGymInfo({ name: gymName, branches: fetchedBranches });
                let idToSet = branchIdToSelectAfterAction;
                if (!idToSet || !fetchedBranches.some(b => b.id === idToSet)) {
                    const lastSelected = localStorage.getItem('lastSelectedBranchId');
                    if (lastSelected && fetchedBranches.some(b => b.id === lastSelected)) {
                        idToSet = lastSelected;
                    } else if (fetchedBranches.length > 0) {
                        idToSet = fetchedBranches[0].id;
                    } else {
                        idToSet = null;
                    }
                }
                setCurrentBranchId(idToSet);
                if (idToSet) {
                    localStorage.setItem('lastSelectedBranchId', idToSet);
                } else {
                    localStorage.removeItem('lastSelectedBranchId');
                    setAllMembers({}); setAllTrainers({}); setAllScheduledClasses({});
                    setIndividualTrainerPayments({});
                }
            } else { throw new Error(data.message || "Invalid gym details data structure"); }
        } catch (err) {
            setError(err.message || "Could not load dashboard data.");
            if (String(err.message).toLowerCase().includes('token') || String(err.message).toLowerCase().includes('unauthorized')) {
                localStorage.clear(); navigate('/login', { replace: true });
            }
        } finally { setIsLoading(false); }
    }, [navigate]);

    // --- Effects ---

    // Effect to fetch initial dashboard data on component mount
    useEffect(() => {
        fetchInitialDashboardData();
    }, [fetchInitialDashboardData]);

    // Effect to fetch data for the currently selected branch when it changes or after initial load
    useEffect(() => {
        if (currentBranchId && !isLoading) {
            fetchBranchMembers(currentBranchId, '', true);
            fetchBranchTrainersList(currentBranchId, '', true);
            fetchBranchScheduledClasses(currentBranchId, true);
        }
    }, [currentBranchId, isLoading, fetchBranchMembers, fetchBranchTrainersList, fetchBranchScheduledClasses]);

    // --- Memoized Data for Overview ---

    // Calculates and memoizes data needed for the dashboard overview section
    const currentBranchDataForOverview = useMemo(() => {
        if (!currentBranchId || !gymInfo.branches.length) return null;
        const branchInfo = gymInfo.branches.find(branch => branch.id === currentBranchId);
        if (!branchInfo) return null;

        const membersForBranch = (allMembers[currentBranchId]?.initialList) || [];
        const todayStr = getTodayDateString();
        const startOfMonthStr = getStartOfMonthString();

        const totalMembers = membersForBranch.length;
        const activeMembers = membersForBranch.filter(m => m.status === 'Active').length;
        const paymentsDueToday = membersForBranch.filter(m => m.paymentDueDate === todayStr && m.status === 'Active').length;

        let revenueTillDate = 0;
        let thisMonthRevenue = 0;
        membersForBranch.forEach(member => {
            if (Array.isArray(member.history)) {
                member.history.forEach(histEntry => {
                    if ((histEntry.event === 'Payment' || histEntry.event === 'Renewal') && typeof histEntry.amountPaid === 'number') {
                        revenueTillDate += histEntry.amountPaid;
                        if (histEntry.date && histEntry.date >= startOfMonthStr && histEntry.date <= todayStr) {
                            thisMonthRevenue += histEntry.amountPaid;
                        }
                    }
                });
            }
        });
        const classesForCurrentBranch = allScheduledClasses[currentBranchId] || [];
        const upcomingEvents = classesForCurrentBranch.filter(cls => cls.status === 'upcoming').length;
        return { ...branchInfo, totalMembers, activeMembers, paymentsDueToday, thisMonthRevenue, revenueTillDate, upcomingEvents };
    }, [currentBranchId, gymInfo.branches, allMembers, allScheduledClasses]);

    // --- Handlers ---

    // Handles user logout
    const handleLogoutClick = () => { localStorage.clear(); navigate('/login', { replace: true }); };

    // State for Add Branch popup and confirmation
    const [isAddBranchPopupOpen, setIsAddBranchPopupOpen] = useState(false);
    const [newBranchName, setNewBranchName] = useState('');
    const [isAddConfirmOpen, setIsAddConfirmOpen] = useState(false);

    // Opens the Add Branch confirmation modal
    const openAddConfirm = () => { if (newBranchName.trim()) { setIsAddBranchPopupOpen(false); setIsAddConfirmOpen(true); } else { window.alert("Branch name cannot be empty.");} };

    // Handles confirming and adding a new branch
    const confirmAddBranch = async () => {
        if (!newBranchName.trim()) { window.alert("Branch name cannot be empty."); setIsAddConfirmOpen(false); return; }
        setIsBranchActionLoading(true); setError(''); const token = localStorage.getItem('gymUserToken');
        if (!token) { navigate('/login', { replace: true }); setIsBranchActionLoading(false); return; }
        try {
            const response = await fetch('http://localhost:5001/api/branches', { method: 'POST', headers: { 'Authorization': `Bearer ${token}`, 'Content-Type': 'application/json' }, body: JSON.stringify({ name: newBranchName.trim() }) });
            const data = await response.json();
            if (!response.ok) throw new Error(data.message || 'Failed to add branch.');
            if (data.success && data.branch) {
                await fetchInitialDashboardData(data.branch.id);
                window.alert("Branch added successfully!");
            } else { throw new Error(data.message || 'Backend reported failure.'); }
        } catch (err) { setError(`Add Branch Error: ${err.message}`); window.alert(`Error: ${err.message}`);}
        finally { setIsAddConfirmOpen(false); setNewBranchName(''); setIsBranchActionLoading(false); }
    };

    // State for Delete Branch confirmation
    const [isDeleteConfirmOpen, setIsDeleteConfirmOpen] = useState(false);
    const [branchToDeleteId, setBranchToDeleteId] = useState(null);

    // Opens the Delete Branch confirmation modal
    const openDeleteConfirm = (branchId) => { if (gymInfo.branches.length <= 1) { window.alert("Cannot delete the last branch."); return; } setBranchToDeleteId(branchId); setIsDeleteConfirmOpen(true); };

    // Handles confirming and deleting a branch
    const handleDeleteBranch = async () => {
        if (!branchToDeleteId) return;
        setIsBranchActionLoading(true); setError(''); const token = localStorage.getItem('gymUserToken');
        if (!token) { navigate('/login', { replace: true }); setIsBranchActionLoading(false); return; }
        try {
            const response = await fetch(`http://localhost:5001/api/branches/${branchToDeleteId}`, { method: 'DELETE', headers: { 'Authorization': `Bearer ${token}` } });
            const data = await response.json();
            if (!response.ok) throw new Error(data.message || 'Failed to delete branch.');
            if (data.success) {
                window.alert("Branch deleted successfully!");
                // Clear data associated with the deleted branch from state
                const clearDataForBranch = (prevData, idToDelete) => {
                    const newState = {...prevData}; delete newState[idToDelete]; return newState;
                };
                setAllMembers(prev => clearDataForBranch(prev, branchToDeleteId));
                setAllTrainers(prev => clearDataForBranch(prev, branchToDeleteId));
                setAllScheduledClasses(prev => clearDataForBranch(prev, branchToDeleteId));
                // Refetch initial dashboard data to get updated branch list
                await fetchInitialDashboardData();
            } else { throw new Error(data.message || 'Backend reported failure to delete.'); }
        } catch (err) { setError(`Delete Branch Error: ${err.message}`); window.alert(`Error: ${err.message}`); }
        finally { setIsDeleteConfirmOpen(false); setBranchToDeleteId(null); setIsBranchActionLoading(false); }
    };

    // Handles selecting a different branch from the dropdown
    const handleBranchSelect = (event) => {
        const newBranchId = event.target.value;
        setCurrentBranchId(newBranchId);
        // Store the selected branch ID in local storage
        if (newBranchId) {
            localStorage.setItem('lastSelectedBranchId', newBranchId);
        } else {
            localStorage.removeItem('lastSelectedBranchId');
        }
    };

    // Retrieves details for a specific trainer by ID
    const getTrainerDetails = useCallback((trainerId) => {
        const currentBranchTrainersData = currentBranchId ? allTrainers[currentBranchId] : null;
        const listToSearch = currentBranchTrainersData?.initialList || [];
        return listToSearch.find(t => t._id === trainerId) || null;
    }, [currentBranchId, allTrainers]);

    // Handles marking a trainer's salary as paid
    const handleMarkTrainerSalaryPaid = useCallback(async (paymentDetails) => {
        const { trainerId, branchId, amount, paymentDate, paymentMonth, notes } = paymentDetails;

        if (!branchId || !trainerId) {
            window.alert("Branch or Trainer ID missing for salary payment.");
            throw new Error("Branch or Trainer ID missing for salary payment.");
        }
        if (!paymentMonth || !paymentMonth.match(/^\d{4}-\d{2}$/)) {
            window.alert("Payment month (YYYY-MM) is required for salary payment.");
            throw new Error("Payment month (YYYY-MM) is required for salary payment.");
        }
        if (!paymentDate || !paymentDate.match(/^\d{4}-\d{2}-\d{2}$/)) {
            window.alert("Payment date (YYYY-MM-DD) is required for salary payment.");
            throw new Error("Payment date (YYYY-MM-DD) is required for salary payment.");
        }

        const token = localStorage.getItem('gymUserToken');
        if (!token) {
            navigate('/login', { replace: true });
            throw new Error("Authentication token not found.");
        }

        setIsBranchActionLoading(true);
        setError('');

        try {
            const payload = {
                amount: parseFloat(amount),
                paymentDate: paymentDate,
                paymentMonth: paymentMonth,
                notes: notes
            };

            const response = await fetch(`http://localhost:5001/api/branches/${branchId}/trainers/${trainerId}/payments`, {
                method: 'POST',
                headers: { 'Authorization': `Bearer ${token}`, 'Content-Type': 'application/json' },
                body: JSON.stringify(payload),
            });
            const data = await response.json();
            if (!response.ok) throw new Error(data.message || "Failed to record payment.");

            if (data.success && data.payment) {
                window.alert("Trainer salary payment recorded!");
                // Refresh payments for this specific trainer
                await fetchPaymentsForSingleTrainer(branchId, trainerId, true);

                // Optimistically update the trainer's history in the allTrainers state
                setAllTrainers(prevAllTrainers => {
                    const updatedAllTrainers = { ...prevAllTrainers };
                    if (updatedAllTrainers[branchId] && updatedAllTrainers[branchId].list) {
                        const updateList = (list) => list.map(t => {
                            if (t._id === trainerId) {
                                const newHistoryEntry = {
                                    date: payload.paymentDate,
                                    event: "Salary Paid",
                                    details: `Payment of ${payload.amount} for ${payload.paymentMonth}. Notes: ${payload.notes || 'N/A'}`,
                                    amount: payload.amount
                                };
                                return { ...t, history: [newHistoryEntry, ...(t.history || [])] };
                            }
                            return t;
                        });
                        updatedAllTrainers[branchId].list = updateList(updatedAllTrainers[branchId].list);
                        if (updatedAllTrainers[branchId].initialList) {
                             updatedAllTrainers[branchId].initialList = updateList(updatedAllTrainers[branchId].initialList);
                        }
                    }
                    return updatedAllTrainers;
                });

            } else { throw new Error(data.message || "API reported failure for payment."); }
        } catch (err) {
            setError(`Mark Salary Paid Error: ${err.message}`);
            window.alert(`Error: ${err.message}`);
            throw err;
        } finally {
            setIsBranchActionLoading(false);
        }
    }, [navigate, fetchPaymentsForSingleTrainer, setAllTrainers, setIsBranchActionLoading, setError]);

    // Navigation handlers for different sections (Trainers, Schedule)
    const handleAddTrainer = useCallback(() => navigate('/dashboard/trainers?action=add'), [navigate]);
    const handleUpdateTrainer = useCallback((trainerId) => navigate(`/dashboard/trainers?action=edit&id=${trainerId}`), [navigate]);
    const handleDeleteTrainer = useCallback(async (trainerId) => {
        // Placeholder for deletion logic handled in child components
    }, []);

    const handleAddClass = useCallback(() => navigate('/dashboard/schedule?action=add'), [navigate]);
    const handleUpdateClass = useCallback((classId) => navigate(`/dashboard/schedule?action=edit&id=${classId}`), [navigate]);
    const handleDeleteClass = useCallback(async (classId) => {
        // Placeholder for deletion logic handled in child components
    }, []);
    const handleMarkClassComplete = useCallback(async (classId) => {
        // Placeholder for marking complete logic handled in child components
    }, []);

    // Checks if the current location is the dashboard base path
    const isBasePath = location.pathname === '/dashboard' || location.pathname === '/dashboard/';

    // Determines if the overview content is currently loading
    const isOverviewContentLoading = useMemo(() => {
        if (!currentBranchId) return false;
        if (isLoading) return true;
        const membersAvailable = allMembers[currentBranchId]?.initialList;
        const trainersAvailable = allTrainers[currentBranchId]?.initialList;
        const classesAvailable = allScheduledClasses[currentBranchId];
        return (isFetchingMembers && !membersAvailable) ||
               (isFetchingBranchTrainersList && !trainersAvailable) ||
               (isFetchingClasses && !classesAvailable);
    }, [ currentBranchId, isLoading, isFetchingMembers, allMembers, isFetchingBranchTrainersList, allTrainers, isFetchingClasses, allScheduledClasses ]);

    // --- Context Value for Child Routes ---

    // Memoizes the context value provided to child routes via Outlet
    const outletContextValue = useMemo(() => ({
        gymInfo, currentBranchId, currentBranchData: currentBranchDataForOverview,
        allMembers, setAllMembers, fetchBranchMembers, isFetchingMembers,
        allTrainers, setAllTrainers, fetchBranchTrainersList, isFetchingBranchTrainersList,
        allScheduledClasses, setAllScheduledClasses, fetchBranchScheduledClasses, isFetchingClasses,
        individualTrainerPayments, fetchPaymentsForSingleTrainer, isFetchingIndividualTrainerPayments,
        getPackDetails, getTrainerDetails,
        formatCurrency, formatDateToYYYYMMDD, getTodayDateString, formatDate, getCurrentMonthYYYYMM,
        setError,
        handleAddTrainer, handleUpdateTrainer, handleDeleteTrainer,
        handleAddClass, handleUpdateClass, handleDeleteClass, handleMarkClassComplete,
        handleMarkTrainerSalaryPaid,
    }), [
        gymInfo, currentBranchId, currentBranchDataForOverview,
        allMembers, setAllMembers, fetchBranchMembers, isFetchingMembers,
        allTrainers, setAllTrainers, fetchBranchTrainersList, isFetchingBranchTrainersList,
        allScheduledClasses, setAllScheduledClasses, fetchBranchScheduledClasses, isFetchingClasses,
        individualTrainerPayments, fetchPaymentsForSingleTrainer, isFetchingIndividualTrainerPayments,
        getTrainerDetails, handleMarkTrainerSalaryPaid,
        handleAddTrainer, handleUpdateTrainer, handleDeleteTrainer,
        handleAddClass, handleUpdateClass, handleDeleteClass, handleMarkClassComplete,
        setError, formatDateToYYYYMMDD, formatDate, getCurrentMonthYYYYMM, formatCurrency
    ]);

    // --- Render Logic ---

    // Show initial loading state if no branches are loaded and no error
    if (isLoading && !gymInfo.branches.length && !error) {
        return ( <div className="dashboard-loading-container"><FiLoader className="dashboard-loading-spinner" /><span>Loading Dashboard Data...</span></div> );
    }
    // Show a global error message if loading failed and no branches are available
    if (error && !gymInfo.branches.length && !currentBranchId && !isLoading) {
        return (
            <div className="dashboard-loading-container dashboard-error-container">
                <FiAlertTriangle className="dashboard-error-icon" /> <p className="dashboard-error-text">Error: {error}</p>
                <button onClick={handleLogoutClick} className="dashboard-button-primary">Go to Login</button>
            </div>
        );
    }

    // Main dashboard layout
    return (
        <div className="dashboard-container">
            {/* Sidebar Navigation */}
            <aside className="dashboard-sidebar">
                <div className="dashboard-sidebar-header"> <h1 className="dashboard-sidebar-gym-name">{gymInfo.name || "Gym Name"}</h1> </div>
                {/* Button to add a new branch */}
                <div className="dashboard-sidebar-branch-section"> <button className="dashboard-add-branch-button" onClick={() => setIsAddBranchPopupOpen(true)} disabled={isBranchActionLoading || isLoading}><FiPlusCircle /> Add New Branch</button> </div>
                {/* Navigation links */}
                <nav className="dashboard-sidebar-nav">
                    <ul>
                        <li> <NavLink to="/dashboard" end className={({ isActive }) => `dashboard-nav-link ${isActive ? 'active' : ''}`}> <FiHome className="dashboard-nav-icon" /> <span className="dashboard-nav-text">Dashboard</span> </NavLink> </li>
                        <li> <NavLink to="/dashboard/members" className={({ isActive }) => `dashboard-nav-link ${isActive ? 'active' : ''}`}> <FiUsers className="dashboard-nav-icon" /> <span className="dashboard-nav-text">Members</span> </NavLink> </li>
                        <li> <NavLink to="/dashboard/schedule" className={({ isActive }) => `dashboard-nav-link ${isActive ? 'active' : ''}`}> <FiCalendar className="dashboard-nav-icon" /> <span className="dashboard-nav-text">Schedule</span> </NavLink> </li>
                        <li> <NavLink to="/dashboard/trainers" className={({ isActive }) => `dashboard-nav-link ${isActive ? 'active' : ''}`}> <FiUser className="dashboard-nav-icon" /> <span className="dashboard-nav-text">Trainers</span> </NavLink> </li>
                        <li> <NavLink to="/dashboard/reports" className={({ isActive }) => `dashboard-nav-link ${isActive ? 'active' : ''}`}> <FiBarChart2 className="dashboard-nav-icon" /> <span className="dashboard-nav-text">Reports</span> </NavLink> </li>
                    </ul>
                </nav>
                {/* Logout button */}
                <div className="dashboard-sidebar-footer"> <button className="dashboard-logout-button-sidebar" onClick={handleLogoutClick}> <FiLogOut className="dashboard-nav-icon" /> <span className="dashboard-nav-text">Logout</span> </button> </div>
            </aside>
            {/* Main Content Area */}
            <main className="dashboard-main-content">
                {/* Header with page title and branch selector */}
                <header className="dashboard-main-header">
                    <div className="dashboard-header-left"> <h1 className="dashboard-page-title"> {isBasePath ? 'Dashboard Overview' : location.pathname.split('/').pop().replace(/-/g, ' ').replace(/\b\w/g, l => l.toUpperCase())} </h1> </div>
                    <div className="dashboard-header-right">
                        {/* Branch selector dropdown */}
                        {gymInfo.branches.length > 0 ? (
                            <div className="dashboard-branch-selector-wrapper">
                                <FiMapPin className="dashboard-branch-selector-icon" />
                                <label htmlFor="branch-select" className="dashboard-visually-hidden">Select Branch</label>
                                <select id="branch-select" className="dashboard-select-branch-dropdown" onChange={handleBranchSelect} value={currentBranchId || ''}
                                    disabled={isLoading || isBranchActionLoading || isFetchingMembers || isFetchingBranchTrainersList || isFetchingClasses || isFetchingIndividualTrainerPayments}>
                                    {gymInfo.branches.map(branch => (<option key={branch.id} value={branch.id}>{branch.name}</option>))}
                                </select>
                                <FiChevronDown className="dashboard-dropdown-arrow-icon" />
                            </div>
                        ) : ( !isLoading && !isBranchActionLoading && <div className="dashboard-no-branch-message">No branches. Add one.</div> )}
                        {/* Delete branch button (shown if more than one branch exists) */}
                        {currentBranchDataForOverview && gymInfo.branches.length > 1 && ( <button className="dashboard-delete-branch-button" onClick={() => openDeleteConfirm(currentBranchDataForOverview.id)} title={`Delete ${currentBranchDataForOverview.name}`} aria-label={`Delete ${currentBranchDataForOverview.name}`} disabled={isLoading || isBranchActionLoading || isFetchingMembers || isFetchingBranchTrainersList || isFetchingClasses || isFetchingIndividualTrainerPayments}><FiTrash2 /></button> )}
                    </div>
                </header>
                {/* Area for rendering specific route content */}
                <div className="dashboard-content-area">
                    {/* Display global error message */}
                    {error && (gymInfo.branches.length > 0 || currentBranchId) && <p className="error-message dashboard-global-error">{error}</p>}
                    {/* Render Dashboard Overview or nested route content */}
                    {isBasePath ? (
                        currentBranchId ? (
                            <DashboardOverviewContent
                                currentBranchData={currentBranchDataForOverview}
                                currentBranchId={currentBranchId}
                                trainers={allTrainers[currentBranchId]?.initialList || []}
                                allMembers={allMembers}
                                allScheduledClasses={allScheduledClasses}
                                isOverviewLoading={isOverviewContentLoading}
                            />
                        ) : (
                            // Placeholder if no branch is selected for overview
                            <div className="dashboard-placeholder-content dashboard-card dashboard-select-branch-prompt">
                                <FiMapPin />
                                <p>{isLoading ? "Loading..." : (gymInfo.branches.length === 0 && !isBranchActionLoading ? "No branches. Please add one." : "Select a branch for overview.")}</p>
                            </div>
                        )
                    ) : (
                        // Render nested route component and provide context
                        <Outlet context={outletContextValue} />
                    )}
                </div>
            </main>
            {/* Add Branch Popup Modal */}
            {isAddBranchPopupOpen && ( <div className="dashboard-popup-overlay"> <div className="dashboard-popup-content dashboard-card"> <button className="dashboard-modal-close-button" onClick={() => {setIsAddBranchPopupOpen(false); setNewBranchName(''); setError('');}}><FiX /></button> <h3 className="dashboard-popup-title">Add New Branch</h3> <input type="text" className="dashboard-popup-input" placeholder="Enter Branch Name" value={newBranchName} onChange={(e) => setNewBranchName(e.target.value)} autoFocus /> <div className="dashboard-popup-buttons"> <button className="dashboard-popup-button dashboard-cancel-button" onClick={() => { setIsAddBranchPopupOpen(false); setNewBranchName(''); setError(''); }}>Cancel</button> <button className="dashboard-popup-button dashboard-confirm-button" onClick={openAddConfirm} disabled={isBranchActionLoading}>{isBranchActionLoading? 'Validating...' : 'Add Branch'}</button> </div> </div> </div> )}
            {/* Add Branch Confirmation Modal */}
            {isAddConfirmOpen && ( <div className="dashboard-popup-overlay"> <div className="dashboard-popup-content dashboard-card"> <button className="dashboard-modal-close-button" onClick={() => setIsAddConfirmOpen(false)}><FiX /></button> <h3 className="dashboard-popup-title">Confirm Add Branch</h3> <p className="dashboard-popup-message">Are you sure you want to create a new branch named "<span className="dashboard-highlight-text">{newBranchName}</span>"?</p> <div className="dashboard-popup-buttons"> <button className="dashboard-popup-button dashboard-cancel-button" onClick={() => setIsAddConfirmOpen(false)}>Cancel</button> <button className="dashboard-popup-button dashboard-confirm-button" onClick={confirmAddBranch} disabled={isBranchActionLoading}>{isBranchActionLoading ? 'Adding...' : 'Confirm Add'}</button> </div> </div> </div> )}
            {/* Delete Branch Confirmation Modal */}
            {isDeleteConfirmOpen && ( <div className="dashboard-popup-overlay"> <div className="dashboard-popup-content dashboard-card"> <button className="dashboard-modal-close-button" onClick={() => { setIsDeleteConfirmOpen(false); setBranchToDeleteId(null); setError('');}}><FiX /></button> <h3 className="dashboard-popup-title">Confirm Delete Branch</h3> <p className="dashboard-popup-message"> Are you sure you want to delete the branch "<span className="dashboard-highlight-text">{gymInfo.branches.find(b => b.id === branchToDeleteId)?.name || 'this branch'}</span>"? <br/> <strong style={{color: 'red'}}>This action is irreversible and will delete the branch. Associated data might need manual handling or might be orphaned.</strong> </p> <div className="dashboard-popup-buttons"> <button className="dashboard-popup-button dashboard-cancel-button" onClick={() => { setIsDeleteConfirmOpen(false); setBranchToDeleteId(null); setError(''); }}>Cancel</button> <button className="dashboard-popup-button dashboard-delete-button" onClick={handleDeleteBranch} disabled={isBranchActionLoading}>{isBranchActionLoading ? 'Deleting...' : 'Confirm Delete'}</button> </div> </div> </div> )}
        </div>
    );
}

export default DashboardScreen;

// Custom hook to access the dashboard context provided via Outlet
export function useDashboardContext() {
    const context = useOutletContext();
    // Provide default values if context is not available (e.g., component not rendered inside Outlet)
    if (context === undefined) {
        return {
            gymInfo: { name: "Gym", branches: [] }, currentBranchId: null, currentBranchData: null,
            allMembers: {}, setAllMembers: () => {}, fetchBranchMembers: async () => ({list: [], initialList: []}), isFetchingMembers: false,
            allTrainers: {}, setAllTrainers: () => {}, fetchBranchTrainersList: async () => ({list: [], initialList: []}), isFetchingBranchTrainersList: false,
            allScheduledClasses: {}, setAllScheduledClasses: () => {}, fetchBranchScheduledClasses: async () => [], isFetchingClasses: false,
            individualTrainerPayments: {}, fetchPaymentsForSingleTrainer: async () => [], isFetchingIndividualTrainerPayments: false,
            getPackDetails: () => ({ name: 'N/A', price: 0, durationMonths: 0, type: 'N/A' }), getTrainerDetails: () => null,
            formatCurrency: (a) => `${a}`, formatDateToYYYYMMDD: () => '', getTodayDateString: () => '', formatDate: (d) => `${d}`, getCurrentMonthYYYYMM: () => '',
            setError: () => {},
            handleAddTrainer: () => {}, handleUpdateTrainer: () => {}, handleDeleteTrainer: async () => {},
            handleAddClass: () => {}, handleUpdateClass: () => {}, handleDeleteClass: async () => {}, handleMarkClassComplete: async () => {},
            handleMarkTrainerSalaryPaid: async () => {},
        };
    }
    return context;
}
