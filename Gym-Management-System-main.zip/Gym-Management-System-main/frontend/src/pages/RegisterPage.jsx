import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom'; // Import useNavigate for redirection
import '../styles/RegisterPage.css'; // Make sure this path is correct
import { FiUserPlus, FiUser, FiMail, FiLock, FiHome, FiMapPin } from 'react-icons/fi';

function RegisterPage() {
  const [ownerName, setOwnerName] = useState('');
  const [gymName, setGymName] = useState('');
  const [branchName, setBranchName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');

  // State variables to handle API call feedback
  const [isLoading, setIsLoading] = useState(false);
  const [errorMessage, setErrorMessage] = useState('');
  const [successMessage, setSuccessMessage] = useState('');

  const navigate = useNavigate(); // Hook to allow programmatic navigation (e.g., redirecting after success)

  const handleRegister = async (event) => {
    event.preventDefault(); // Prevent the default browser form submission behavior

    // Clear any previous messages
    setErrorMessage('');
    setSuccessMessage('');

    // --- Client-Side Validation ---
    if (password !== confirmPassword) {
      setErrorMessage("Passwords don't match. Please check them.");
      return; // Stop the function if passwords don't match
    }
    if (password.length < 6) {
      setErrorMessage("Password should be at least 6 characters long.");
      return; // Stop if password is too short
    }

    // All good, let's prepare to send data to the backend
    setIsLoading(true); // Show a loading state in the UI

    const gymRegistrationData = {
      ownerName,
      gymName,
      branchName,
      email,
      password,
    };

    try {
      // Send the data to your backend API endpoint
      const response = await fetch('http://localhost:5001/api/register-my-gym/submit', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json', // Tell the backend we're sending JSON data
        },
        body: JSON.stringify(gymRegistrationData), // Convert the JavaScript object to a JSON string
      });

      const responseData = await response.json(); // Read the response from the backend (which should also be JSON)

      if (!response.ok) {
        // If the backend responded with an error status (e.g., 400, 500)
        // Use the message from the backend if available, otherwise a generic error
        throw new Error(responseData.message || `Error: ${response.status} - ${response.statusText}`);
      }

      // --- Registration was successful! ---
      setSuccessMessage(responseData.message || 'Gym registered successfully! Redirecting to login...');

      // Clear the form fields
      setOwnerName('');
      setGymName('');
      setBranchName('');
      setEmail('');
      setPassword('');
      setConfirmPassword('');

      // Wait a couple of seconds to show the success message, then redirect to login
      setTimeout(() => {
        navigate('/login'); // Redirect to your login page route
      }, 2500); // 2.5 seconds delay

    } catch (err) {
      // If anything went wrong with the fetch call or if we threw an error above
      setErrorMessage(err.message || 'Registration failed. Please try again later.');
      console.error("Registration submission error:", err);
    } finally {
      // This will run whether the try block succeeded or failed
      setIsLoading(false); // Hide the loading state
    }
  };

  return (
    <div className="register-container">
      <div className="register-content fade-in">
        <h1 className="register-heading">Register Your Gym</h1>

        {/* Display error messages if any */}
        {errorMessage && <p className="error-message" style={{color: 'red', textAlign: 'center', marginBottom: '10px'}}>{errorMessage}</p>}
        {/* Display success messages if any */}
        {successMessage && <p className="success-message" style={{color: 'green', textAlign: 'center', marginBottom: '10px'}}>{successMessage}</p>}

        <form onSubmit={handleRegister} className="register-form">
          <div className="input-group">
            <FiUser className="input-icon" />
            <input type="text" placeholder="Gym Owner Name" value={ownerName} onChange={(e) => setOwnerName(e.target.value)} required disabled={isLoading} />
          </div>
          <div className="input-group">
            <FiHome className="input-icon" />
            <input type="text" placeholder="Gym Name" value={gymName} onChange={(e) => setGymName(e.target.value)} required disabled={isLoading} />
          </div>
          <div className="input-group">
            <FiMapPin className="input-icon" />
            <input type="text" placeholder="Branch Name" value={branchName} onChange={(e) => setBranchName(e.target.value)} required disabled={isLoading} />
          </div>
            <div className="input-group">
            <FiMail className="input-icon" />
            <input type="email" placeholder="Email Address" value={email} onChange={(e) => setEmail(e.target.value)} required disabled={isLoading} />
          </div>
          <div className="input-group">
            <FiLock className="input-icon" />
            <input type="password" placeholder="Password" value={password} onChange={(e) => setPassword(e.target.value)} required disabled={isLoading} />
          </div>
          <div className="input-group">
            <FiLock className="input-icon" />
            <input type="password" placeholder="Confirm Password" value={confirmPassword} onChange={(e) => setConfirmPassword(e.target.value)} required disabled={isLoading} />
          </div>

          <button type="submit" className="register-submit-button" disabled={isLoading}>
            {isLoading ? (
              'Registering...' // Simple text while loading
            ) : (
              <>
                <FiUserPlus className="button-icon" /> Register Gym
              </>
            )}
          </button>
        </form>

        <div className="register-links">
          <p>
            Already registered? <Link to="/login">Login Here</Link>
          </p>
        </div>
      </div>
      <div className="back-link-container">
        <Link to="/" className="back-link">Back to Welcome</Link>
      </div>
    </div>
  );
}

export default RegisterPage;