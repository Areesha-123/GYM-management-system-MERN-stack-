// File: frontend/src/pages/ScheduleClass.jsx
import React, { useState, useMemo, useEffect, useCallback } from 'react';
import { useOutletContext } from 'react-router-dom';
import {
    FiEdit, FiTrash2, FiCheckSquare, FiImage, FiX, FiPlus, FiChevronUp, FiCalendar, FiClock, FiInfo, FiLoader
    // Removed FiChevronDown, FiUpload, FiDelete as they were unused
} from 'react-icons/fi';

import '../styles/ScheduleClass.css';

const ClassCard = ({ classInfo, onEdit, onDelete, onMarkComplete, isLoading }) => {
    // Removed _id from destructuring as it's accessed via classInfo._id in handlers
    const { title, description, date, time, imageUrl, status } = classInfo;

    const formatDateDisplay = (dateString) => {
        if (!dateString) return 'N/A';
        try {
            const dateObj = new Date(dateString.includes('T') ? dateString : dateString + 'T00:00:00Z');
            if (isNaN(dateObj.getTime())) return dateString;
            return dateObj.toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric', timeZone: 'UTC' });
        } catch (e) {
            return dateString;
        }
    };

    const formatTimeDisplay = (timeString) => {
        if (!timeString || !timeString.includes(':')) return 'N/A';
        try {
            const [hours, minutes] = timeString.split(':');
            const dateObj = new Date(); // Create a dummy date object
            dateObj.setUTCHours(parseInt(hours, 10));
            dateObj.setUTCMinutes(parseInt(minutes, 10));
            if (isNaN(dateObj.getTime())) return timeString; // Check if date is valid after setting
            return dateObj.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit', hour12: true, timeZone: 'UTC' });
        } catch (e) {
            return timeString;
        }
    };

    return (
        <div className={`schedule-class-item ${status === 'completed' ? 'schedule-class-item-completed' : ''}`}>
            <div className="schedule-class-item-image-wrapper">
                {imageUrl ? (
                    <img
                        src={imageUrl}
                        alt={title}
                        className="schedule-class-item-image"
                        onError={(e) => {
                            const imgElement = e.target;
                            if (imgElement) imgElement.style.display = 'none'; // Hide broken image
                            const placeholder = imgElement?.nextElementSibling; // Get the next sibling (placeholder)
                            if (placeholder) placeholder.style.display = 'flex'; // Show placeholder
                        }}
                    />
                ) : null}
                {/* Fallback placeholder, shown if imageUrl is null/undefined or if image fails to load */}
                <div className="schedule-class-item-image-placeholder" style={{ display: imageUrl ? 'none' : 'flex' }}>
                    <FiImage />
                </div>
            </div>
            <div className="schedule-class-item-content">
                <h4 className="schedule-class-item-title">{title}</h4>
                <p className="schedule-class-item-description">{description}</p>
                <div className="schedule-class-item-timing">
                    <span><FiCalendar /> {formatDateDisplay(date)}</span>
                    <span><FiClock /> {formatTimeDisplay(time)}</span>
                </div>
                {status === 'completed' && <p className="schedule-class-item-status"><FiCheckSquare /> Completed</p>}
            </div>
            <div className="schedule-class-item-actions">
                {status === 'upcoming' && (
                    <>
                        <button onClick={() => onEdit(classInfo)} className="schedule-action-button schedule-edit-button" title="Edit Class" disabled={isLoading}> <FiEdit /> <span>Edit</span> </button>
                        <button onClick={() => onMarkComplete(classInfo._id)} className="schedule-action-button schedule-complete-button" title="Mark as Complete" disabled={isLoading}> <FiCheckSquare /> <span>Complete</span> </button>
                    </>
                )}
                <button onClick={() => onDelete(classInfo._id, title)} className="schedule-action-button schedule-delete-button" title="Delete Class" disabled={isLoading}> <FiTrash2 /> <span>Delete</span> </button>
            </div>
        </div>
    );
};

function ScheduleClass() {
    const context = useOutletContext() || {}; // Ensure context is an object even if null/undefined
    const {
        currentBranchId,
        currentBranchData,
        allScheduledClasses: allScheduledClassesFromContext = {}, // Default to empty object
        setAllScheduledClasses, // Function to update scheduled classes in context
    } = context;

    const [showAddForm, setShowAddForm] = useState(false);
    const [title, setTitle] = useState('');
    const [description, setDescription] = useState('');
    const [date, setDate] = useState('');
    const [time, setTime] = useState('');
    const [imageDataUrl, setImageDataUrl] = useState(null); // For the add form image preview
    
    const [isSubmitting, setIsSubmitting] = useState(false); // General submitting state for add, edit, delete, complete
    const [actionError, setActionError] = useState('');
    const [actionSuccessMessage, setActionSuccessMessage] = useState('');

    // States for Edit Modal
    const [isEditModalOpen, setIsEditModalOpen] = useState(false);
    const [classToEdit, setClassToEdit] = useState(null);
    const [editFormData, setEditFormData] = useState({ title: '', description: '', date: '', time: '', imageDataUrl: null });
    
    // States for Delete Confirmation Modal
    const [isDeleteConfirmOpen, setIsDeleteConfirmOpen] = useState(false);
    const [classToDelete, setClassToDelete] = useState({ id: null, title: '' }); // Store id and title for confirmation message
    const [isLoading, setIsLoading] = useState(false); // Specifically for fetching the list of classes

    // Function to fetch scheduled classes for the current branch
    const fetchClassesForBranch = useCallback(async () => {
        if (!currentBranchId) {
            if (setAllScheduledClasses) { // Check if setter from context is available
                setAllScheduledClasses(prev => ({ ...prev, [currentBranchId || 'no-branch-schedule']: [] }));
            }
            return;
        }
        setIsLoading(true);
        setActionError('');
        const token = localStorage.getItem('gymUserToken');
        if (!token) {
            setActionError("Authentication error: No token.");
            setIsLoading(false);
            return;
        }

        try {
            const response = await fetch(`http://localhost:5001/api/branches/${currentBranchId}/schedule`, {
                method: 'GET',
                headers: {
                    'Authorization': `Bearer ${token}`,
                    'Content-Type': 'application/json'
                },
            });
            const data = await response.json();
            if (!response.ok) {
                throw new Error(data.message || 'Failed to fetch scheduled classes.');
            }
            if (data.success && Array.isArray(data.scheduledClasses)) {
                if (setAllScheduledClasses) { // Check if setter from context is available
                    setAllScheduledClasses(prev => ({ ...prev, [currentBranchId]: data.scheduledClasses }));
                }
            } else {
                throw new Error(data.message || 'Invalid data structure for scheduled classes.');
            }
        } catch (err) {
            setActionError(`Fetch Classes Error: ${err.message}`);
            if (setAllScheduledClasses) { // Check if setter from context is available
                setAllScheduledClasses(prev => ({ ...prev, [currentBranchId]: [] })); // Set to empty on error
            }
        } finally {
            setIsLoading(false);
        }
    }, [currentBranchId, setAllScheduledClasses]); // setAllScheduledClasses is a dependency

    // Effect to fetch classes when branch changes or on initial load with a branch
    useEffect(() => {
        if (currentBranchId) {
            // Optionally, check if classes for this branch are already in allScheduledClassesFromContext
            // to avoid re-fetching, but for simplicity, always fetching if branchId is present.
            fetchClassesForBranch();
        } else {
            // If no branch is selected, ensure the context is updated appropriately (e.g., clear specific branch data)
             if (setAllScheduledClasses) { // Added missing dependency
                setAllScheduledClasses(prev => ({...prev, 'no-branch-schedule': [] })); // Clear or set a default for no branch
            }
        }
    }, [currentBranchId, fetchClassesForBranch, setAllScheduledClasses]); // Added setAllScheduledClasses


    // Memoized computation for upcoming and completed classes
    const { upcomingClasses, completedClasses } = useMemo(() => {
        const classesForBranch = (currentBranchId && allScheduledClassesFromContext && allScheduledClassesFromContext[currentBranchId])
            ? allScheduledClassesFromContext[currentBranchId]
            : [];
        
        // Ensure classesForBranch is always an array before filtering/sorting
        const safeClasses = Array.isArray(classesForBranch) ? classesForBranch : [];

        // Helper to get a valid Date object for sorting, defaults to epoch if invalid
        const getDateTime = (cls) => {
            try {
                // Ensure time is valid, default to midnight if not provided or malformed
                const timePart = (cls.time && cls.time.includes(':')) ? cls.time : '00:00:00';
                const dateObj = new Date(`${cls.date}T${timePart}Z`); // Assume date is YYYY-MM-DD, time is HH:MM
                return isNaN(dateObj.getTime()) ? new Date(0) : dateObj;
            } catch {
                return new Date(0); // Fallback for any parsing errors
            }
        };
        
        return {
            upcomingClasses: safeClasses
                .filter(cls => cls.status === 'upcoming')
                .sort((a, b) => getDateTime(a) - getDateTime(b)), // Sort upcoming: oldest first
            completedClasses: safeClasses
                .filter(cls => cls.status === 'completed')
                .sort((a, b) => getDateTime(b) - getDateTime(a)) // Sort completed: newest first
        };
    }, [currentBranchId, allScheduledClassesFromContext]);

    // Effect to clear form and messages when branch changes
    useEffect(() => {
        setTitle('');
        setDescription('');
        setDate('');
        setTime('');
        setImageDataUrl(null);
        setActionError('');
        setActionSuccessMessage('');
        setShowAddForm(false); // Optionally hide form on branch change
        // Clear file input if it exists
        const fileInput = document.getElementById('add-class-image-file');
        if (fileInput) fileInput.value = '';

    }, [currentBranchId]);

    // Function to clear the add form fields
    const clearAddForm = () => {
        setTitle('');
        setDescription('');
        setDate('');
        setTime('');
        setImageDataUrl(null);
        setActionError(''); // Also clear any errors specific to the add form
        // Reset the file input visually
        const fileInput = document.getElementById('add-class-image-file');
        if (fileInput) {
            fileInput.value = ''; // This clears the selected file name
        }
    };

    // Handle file input change for both add and edit forms
    const handleFileChange = (event, formType = 'add') => {
        const file = event.target.files[0];
        if (file) {
            // Basic validation for file type and size (optional)
            if (!file.type.startsWith('image/')) {
                setActionError("Invalid file type. Please select an image.");
                return;
            }
            if (file.size > 2 * 1024 * 1024) { // 2MB limit
                setActionError("File is too large. Maximum size is 2MB.");
                return;
            }

            const reader = new FileReader();
            reader.onloadend = () => {
                if (formType === 'add') {
                    setImageDataUrl(reader.result);
                } else { // 'edit'
                    setEditFormData(prev => ({ ...prev, imageDataUrl: reader.result }));
                }
                setActionError(''); // Clear error on successful read
            };
            reader.onerror = () => {
                setActionError("Failed to read image file.");
                if (formType === 'add') setImageDataUrl(null);
                else setEditFormData(prev => ({ ...prev, imageDataUrl: null }));
            }
            reader.readAsDataURL(file);
        } else { // No file selected or file removed
            if (formType === 'add') {
                setImageDataUrl(null);
            } else { // 'edit'
                setEditFormData(prev => ({ ...prev, imageDataUrl: null }));
            }
        }
    };

    // Handle submission of the "Add New Class" form
    const handleAddSubmit = async (event) => {
        event.preventDefault();
        setActionError('');
        setActionSuccessMessage('');

        if (!title || !description || !date || !time) {
            setActionError('Please fill in Title, Description, Date, and Time.');
            return;
        }
        if (!currentBranchId) {
            setActionError('Cannot schedule class: No branch selected.');
            return;
        }
        
        setIsSubmitting(true);
        const token = localStorage.getItem('gymUserToken');
        if (!token) {
            setActionError("Authentication error. Please log in again.");
            setIsSubmitting(false);
            return;
        }

        const classPayload = {
            branchId: currentBranchId, // Ensure branchId is included
            title: title.trim(),
            description: description.trim(),
            date: date, // Assuming YYYY-MM-DD format from input type="date"
            time: time, // Assuming HH:MM format from input type="time"
            imageUrl: imageDataUrl, // This will be the base64 data URL or null
            status: 'upcoming' // Default status for new classes
        };

        try {
            const response = await fetch(`http://localhost:5001/api/branches/${currentBranchId}/schedule`, {
                method: 'POST',
                headers: {
                    'Authorization': `Bearer ${token}`,
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(classPayload),
            });
            const data = await response.json();
            if (!response.ok) {
                throw new Error(data.message || "Failed to schedule class.");
            }

            if (data.success && data.scheduledClass) {
                await fetchClassesForBranch(); // Re-fetch to update the list
                setActionSuccessMessage(`Class "${title}" scheduled successfully!`);
                clearAddForm();
                setShowAddForm(false); // Hide form after successful submission
                setTimeout(() => setActionSuccessMessage(''), 4000); // Clear success message after a delay
            } else {
                throw new Error(data.message || "Failed to schedule class (API success false).");
            }
        } catch (err) {
            setActionError(`Schedule Class Failed: ${err.message}`);
        } finally {
            setIsSubmitting(false);
        }
    };

    // Functions for Edit Modal
    const openEditModal = (classInfo) => {
        setClassToEdit(classInfo);
        setEditFormData({
            title: classInfo.title,
            description: classInfo.description,
            date: classInfo.date, // Assuming date is already in YYYY-MM-DD
            time: classInfo.time, // Assuming time is already in HH:MM
            imageDataUrl: classInfo.imageUrl || null // Existing image URL or null
        });
        setIsEditModalOpen(true);
        setActionError(''); // Clear any previous errors
    };
    const closeEditModal = () => {
        setIsEditModalOpen(false);
        setClassToEdit(null);
        setActionError(''); // Clear errors when closing modal
    };
    const handleEditFormChange = (e) => {
        const { name, value } = e.target;
        setEditFormData(prev => ({ ...prev, [name]: value }));
    };
    const handleRemoveEditImage = () => {
        setEditFormData(prev => ({ ...prev, imageDataUrl: null }));
        // Also clear the file input field if it exists
        const fileInput = document.getElementById('edit-class-image-file');
        if (fileInput) fileInput.value = '';
    };

    // Handle submission of the "Edit Class" form
    const handleEditSubmit = async (event) => {
        event.preventDefault();
        setActionError(''); // Clear previous errors
        const { title, description, date, time, imageDataUrl } = editFormData;

        if (!title || !description || !date || !time) {
            setActionError('Please fill in Title, Description, Date, and Time for editing.');
            return;
        }
        if (!classToEdit || !classToEdit._id || !currentBranchId) {
             setActionError('Cannot update class: Missing class ID or branch ID.');
             return;
        }
        
        setIsSubmitting(true);
        const token = localStorage.getItem('gymUserToken');
        if (!token) {
            setActionError("Authentication error.");
            setIsSubmitting(false);
            return;
        }

        const classPayload = {
            // Only send fields that can be changed. Backend should handle partial updates.
            title: title.trim(),
            description: description.trim(),
            date: date,
            time: time,
            imageUrl: imageDataUrl, // Send new base64, existing URL, or null if removed
            // status: classToEdit.status, // Keep original status unless explicitly changing it through another action
        };

        try {
            const response = await fetch(`http://localhost:5001/api/branches/${currentBranchId}/schedule/${classToEdit._id}`, {
                method: 'PUT',
                headers: {
                    'Authorization': `Bearer ${token}`,
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(classPayload),
            });
            const data = await response.json();
            if (!response.ok) {
                throw new Error(data.message || "Failed to update class.");
            }
            if (data.success && data.scheduledClass) {
                await fetchClassesForBranch(); // Re-fetch to update list
                setActionSuccessMessage("Class updated successfully!");
                setTimeout(() => setActionSuccessMessage(''), 4000);
                closeEditModal();
            } else {
                throw new Error(data.message || "Failed to update class (API success false).");
            }
        } catch (err) {
            setActionError(`Update Class Failed: ${err.message}`);
        } finally {
            setIsSubmitting(false);
        }
    };

    // Functions for Delete Confirmation Modal
    const openDeleteConfirmModal = (id, title) => {
        setClassToDelete({ id, title });
        setIsDeleteConfirmOpen(true);
    };
    const closeDeleteConfirmModal = () => {
        setIsDeleteConfirmOpen(false);
        setClassToDelete({ id: null, title: '' }); // Reset
    };
    
    // Handle actual deletion of a class
    const confirmDelete = async () => {
        if (!classToDelete.id || !currentBranchId) { 
            alert("Class ID or Branch ID missing for deletion."); 
            closeDeleteConfirmModal(); 
            return; 
        }
        setActionError(''); // Clear previous errors
        setIsSubmitting(true); // Use general submitting state
        const token = localStorage.getItem('gymUserToken');
        if (!token) {
            setActionError("Authentication error.");
            setIsSubmitting(false);
            closeDeleteConfirmModal();
            return;
        }

        try {
            const response = await fetch(`http://localhost:5001/api/branches/${currentBranchId}/schedule/${classToDelete.id}`, {
                method: 'DELETE',
                headers: { 'Authorization': `Bearer ${token}`},
            });
            const data = await response.json(); // Try to parse JSON even on error for messages
            if (!response.ok) {
                throw new Error(data.message || "Failed to delete class.");
            }
            if (data.success) {
                await fetchClassesForBranch(); // Re-fetch to update list
                setActionSuccessMessage("Class deleted successfully!");
                setTimeout(() => setActionSuccessMessage(''), 4000);
            } else {
                throw new Error(data.message || "Failed to delete class (API success false).");
            }
        } catch (err) {
            setActionError(`Delete Class Failed: ${err.message}`);
        } finally {
            setIsSubmitting(false);
            closeDeleteConfirmModal(); // Close modal regardless of outcome
        }
    };

    // Handle marking a class as complete
    const handleMarkCompleteClick = async (classId) => {
        if (!classId || !currentBranchId) {
            alert("Class ID or Branch ID missing for marking complete.");
            return;
        }
        setActionError(''); // Clear previous errors
        setIsSubmitting(true); // Use general submitting state
        const token = localStorage.getItem('gymUserToken');
        if (!token) {
            setActionError("Authentication error.");
            setIsSubmitting(false);
            return;
        }
        
        try {
            const response = await fetch(`http://localhost:5001/api/branches/${currentBranchId}/schedule/${classId}/complete`, {
                method: 'PUT', // Or PATCH, depending on API design
                headers: {
                    'Authorization': `Bearer ${token}`,
                    'Content-Type': 'application/json' // Though body might be empty, good practice
                },
                // body: JSON.stringify({ status: 'completed' }) // If API expects a body
            });
            const data = await response.json();
            if (!response.ok) {
                throw new Error(data.message || "Failed to mark class as complete.");
            }
            if (data.success && data.scheduledClass) {
                await fetchClassesForBranch(); // Re-fetch to update list
                setActionSuccessMessage("Class marked as complete!");
                setTimeout(() => setActionSuccessMessage(''), 4000);
            } else {
                throw new Error(data.message || "Failed to mark complete (API success false).");
            }
        } catch (err) {
            setActionError(`Mark Complete Failed: ${err.message}`);
        } finally {
            setIsSubmitting(false);
        }
    };

    return (
        <div className="schedule-class-page">
            <h2 className="schedule-page-title">
                Manage Schedule {currentBranchData ? ` - ${currentBranchData.name}` : ''}
            </h2>

            {/* Unified Loading Overlay and Messages */}
            {(isLoading || isSubmitting) && <div className="schedule-loading-overlay"><FiLoader className="schedule-loading-spinner" /><span>Processing...</span></div>}
            {actionError && <p className="schedule-message schedule-error-message">{actionError} <button onClick={() => setActionError('')} className="schedule-message-close-btn">&times;</button></p>}
            {actionSuccessMessage && <p className="schedule-message schedule-success-message">{actionSuccessMessage} <button onClick={() => setActionSuccessMessage('')} className="schedule-message-close-btn">&times;</button></p>}

            {/* Prompt to select branch if none is selected */}
            {!currentBranchId && !isLoading && ( // Show only if not loading and no branch
                <div className="schedule-info-message">
                    <FiInfo /> Please select a branch to manage schedules.
                </div>
            )}

            {currentBranchId && (
                <>
                    <div className="schedule-add-section">
                        <button
                            onClick={() => setShowAddForm(!showAddForm)}
                            className="schedule-toggle-button"
                            aria-expanded={showAddForm}
                            disabled={isSubmitting} // Disable while any form is submitting
                        >
                            {showAddForm ? <FiChevronUp /> : <FiPlus />}
                            {showAddForm ? 'Hide Form' : 'Schedule New Class'}
                        </button>
                        {showAddForm && (
                            <form onSubmit={handleAddSubmit} className="schedule-form schedule-add-form">
                                <h3 className="schedule-form-title">New Class Details</h3>
                                
                                <div className="schedule-form-group">
                                    <label htmlFor="add-class-title">Class Title *</label>
                                    <input type="text" id="add-class-title" value={title} onChange={(e) => setTitle(e.target.value)} required className="schedule-form-input" disabled={isSubmitting} />
                                </div>
                                <div className="schedule-form-group">
                                    <label htmlFor="add-class-description">Description *</label>
                                    <textarea id="add-class-description" value={description} onChange={(e) => setDescription(e.target.value)} required rows="3" className="schedule-form-input" disabled={isSubmitting} />
                                </div>
                                <div className="schedule-form-group schedule-form-group-inline">
                                    <div className="schedule-inline-item">
                                        <label htmlFor="add-class-date">Date *</label>
                                        <input type="date" id="add-class-date" value={date} onChange={(e) => setDate(e.target.value)} required className="schedule-form-input" disabled={isSubmitting} />
                                    </div>
                                    <div className="schedule-inline-item">
                                        <label htmlFor="add-class-time">Time *</label>
                                        <input type="time" id="add-class-time" value={time} onChange={(e) => setTime(e.target.value)} required className="schedule-form-input" disabled={isSubmitting} />
                                    </div>
                                </div>
                                <div className="schedule-form-group">
                                        <label htmlFor="add-class-image-file">Class Image (Optional)</label>
                                        <div className="schedule-image-upload-wrapper">
                                            <input type="file" id="add-class-image-file" accept="image/*" onChange={(e) => handleFileChange(e, 'add')} className="schedule-form-input-file" disabled={isSubmitting} />
                                            {imageDataUrl && (
                                                <div className="schedule-image-preview-container">
                                                    <img src={imageDataUrl} alt="Preview" className="schedule-image-preview" />
                                                    <button type="button" onClick={() => { setImageDataUrl(null); const fileInput = document.getElementById('add-class-image-file'); if (fileInput) fileInput.value = ''; }} className="schedule-remove-image-button" title="Remove Image" disabled={isSubmitting} > <FiTrash2 /> </button>
                                                </div>
                                            )}
                                        </div>
                                </div>
                                <div className="schedule-form-actions">
                                    <button type="submit" className="schedule-button schedule-button-primary" disabled={isSubmitting}>{isSubmitting ? <FiLoader className="schedule-button-loader"/> : "Schedule Class"}</button>
                                    <button type="button" className="schedule-button schedule-button-secondary" onClick={clearAddForm} disabled={isSubmitting}>Clear Form</button>
                                </div>
                            </form>
                        )}
                    </div>

                    {/* Upcoming Classes Section */}
                    <section className="schedule-list-section">
                        <h3 className="schedule-list-title">Upcoming Classes ({upcomingClasses.length})</h3>
                        {isLoading && upcomingClasses.length === 0 && <p className="schedule-empty-message">Loading upcoming classes...</p>}
                        {!isLoading && upcomingClasses.length === 0 && (
                            <p className="schedule-empty-message">No upcoming classes scheduled.</p>
                        )}
                        {upcomingClasses.length > 0 && (
                            <div className="schedule-class-list">
                                {upcomingClasses.map(cls => (
                                    <ClassCard key={cls._id || cls.id /* Fallback if _id isn't present */} classInfo={cls} onEdit={openEditModal} onDelete={openDeleteConfirmModal} onMarkComplete={handleMarkCompleteClick} isLoading={isSubmitting} />
                                ))}
                            </div>
                        )}
                    </section>

                    {/* Completed Classes Section */}
                    <section className="schedule-list-section">
                        <h3 className="schedule-list-title">Past / Completed Classes ({completedClasses.length})</h3>
                        {/* Show loading for completed only if upcoming is also empty and still loading */}
                        {isLoading && completedClasses.length === 0 && upcomingClasses.length === 0 && <p className="schedule-empty-message">Loading completed classes...</p> }
                        {!isLoading && completedClasses.length === 0 && (
                            <p className="schedule-empty-message">No past or completed classes found.</p>
                        )}
                        {completedClasses.length > 0 && (
                             <div className="schedule-class-list">
                                {completedClasses.map(cls => (
                                    <ClassCard key={cls._id || cls.id} classInfo={cls} onEdit={openEditModal} onDelete={openDeleteConfirmModal} onMarkComplete={() => { /* No action or view only */}} isLoading={isSubmitting} />
                                ))}
                            </div>
                        )}
                    </section>
                </>
            )}

            {/* Edit Class Modal */}
            {isEditModalOpen && classToEdit && (
                <div className="schedule-modal-overlay">
                    <div className="schedule-modal-content">
                        <button className="schedule-modal-close" onClick={closeEditModal} disabled={isSubmitting}><FiX /></button>
                        <h3 className="schedule-modal-title">Edit Class: {classToEdit.title}</h3>
                        {actionError && <p className="schedule-message schedule-error-message">{actionError}</p>} {/* Error message inside modal */}
                        <form onSubmit={handleEditSubmit} className="schedule-form schedule-edit-form">
                            <div className="schedule-form-group">
                                <label htmlFor="edit-class-title">Class Title *</label>
                                <input type="text" id="edit-class-title" name="title" value={editFormData.title} onChange={handleEditFormChange} required className="schedule-form-input" disabled={isSubmitting}/>
                            </div>
                            <div className="schedule-form-group">
                                <label htmlFor="edit-class-description">Description *</label>
                                <textarea id="edit-class-description" name="description" value={editFormData.description} onChange={handleEditFormChange} required rows="3" className="schedule-form-input" disabled={isSubmitting}/>
                            </div>
                            <div className="schedule-form-group schedule-form-group-inline">
                                <div className="schedule-inline-item">
                                    <label htmlFor="edit-class-date">Date *</label>
                                    <input type="date" id="edit-class-date" name="date" value={editFormData.date} onChange={handleEditFormChange} required className="schedule-form-input" disabled={isSubmitting}/>
                                </div>
                                <div className="schedule-inline-item">
                                    <label htmlFor="edit-class-time">Time *</label>
                                    <input type="time" id="edit-class-time" name="time" value={editFormData.time} onChange={handleEditFormChange} required className="schedule-form-input" disabled={isSubmitting}/>
                                </div>
                            </div>
                            <div className="schedule-form-group">
                                <label htmlFor="edit-class-image-file">Class Image (Optional)</label>
                                <div className="schedule-image-upload-wrapper">
                                    <input type="file" id="edit-class-image-file" accept="image/*" onChange={(e) => handleFileChange(e, 'edit')} className="schedule-form-input-file" disabled={isSubmitting}/>
                                    {editFormData.imageDataUrl && (
                                        <div className="schedule-image-preview-container">
                                            <img src={editFormData.imageDataUrl} alt="Preview" className="schedule-image-preview" />
                                            <button type="button" onClick={handleRemoveEditImage} className="schedule-remove-image-button" title="Remove Image" disabled={isSubmitting}><FiTrash2 /></button>
                                        </div>
                                    )}
                                </div>
                            </div>
                            <div className="schedule-modal-actions">
                                <button type="submit" className="schedule-button schedule-button-primary" disabled={isSubmitting}>{isSubmitting ? <FiLoader className="schedule-button-loader"/> : "Save Changes"}</button>
                                <button type="button" className="schedule-button schedule-button-secondary" onClick={closeEditModal} disabled={isSubmitting}>Cancel</button>
                            </div>
                        </form>
                    </div>
                </div>
            )}

            {/* Delete Confirmation Modal */}
            {isDeleteConfirmOpen && (
                <div className="schedule-modal-overlay">
                    <div className="schedule-modal-content schedule-confirm-modal">
                        <button className="schedule-modal-close" onClick={closeDeleteConfirmModal} disabled={isSubmitting}><FiX /></button>
                        <h3 className="schedule-modal-title">Confirm Delete</h3>
                        <p className="schedule-modal-text">Are you sure you want to delete the class "{classToDelete.title || 'this class'}"? This action cannot be undone.</p>
                        <div className="schedule-modal-actions">
                            <button onClick={confirmDelete} className="schedule-button schedule-button-danger" disabled={isSubmitting}>{isSubmitting ? <FiLoader className="schedule-button-loader"/> : "Confirm Delete"}</button>
                            <button onClick={closeDeleteConfirmModal} className="schedule-button schedule-button-secondary" disabled={isSubmitting}>Cancel</button>
                        </div>
                    </div>
                </div>
            )}
        </div>
    );
}

export default ScheduleClass;
