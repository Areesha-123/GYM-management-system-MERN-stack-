import React from 'react';
import { Link } from 'react-router-dom';
import '../styles/WelcomePage.css';
import { FiLogIn, FiUserPlus } from 'react-icons/fi';

function WelcomePage() {

  return (
    <div className="welcome-container">
      <div className="welcome-content fade-in">
        <h1 className="welcome-heading">
          Smart Gym System
        </h1>
        <div className="button-container">
          <Link to="/login" className="welcome-button login-button">
            <FiLogIn className="button-icon" />
            Continue to Login
          </Link>
          <Link to="/register" className="welcome-button register-button">
            <FiUserPlus className="button-icon" />
            Register your Gym
          </Link>
        </div>
      </div>
    </div>
  );
}

export default WelcomePage;