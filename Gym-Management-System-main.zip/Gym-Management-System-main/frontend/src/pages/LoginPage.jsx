import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import '../styles/LoginPage.css'; // Make sure this path is correct
import { FiLogIn, FiMail, FiLock } from 'react-icons/fi';

function LoginPage() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');

  const [isLoading, setIsLoading] = useState(false);
  const [errorMessage, setErrorMessage] = useState('');

  const [successMessage, setSuccessMessage] = useState('');


  const navigate = useNavigate();

  const handleLogin = async (event) => {
    event.preventDefault();
    setErrorMessage('');
    setSuccessMessage('');
    setIsLoading(true);

    const loginCredentials = {
      email,
      password,
    };

    try {
      const response = await fetch('http://localhost:5001/api/register-my-gym/login', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(loginCredentials),
      });

      const responseData = await response.json();

      if (!response.ok) {
        // Use the message from backend if available, otherwise a generic error
        throw new Error(responseData.message || `Error: ${response.status} - ${response.statusText}`);
      }

      // --- Login was successful! ---
      setSuccessMessage(responseData.message || 'Login successful! Redirecting...');

      localStorage.setItem('gymUserToken', responseData.token);
      localStorage.setItem('gymUserDetails', JSON.stringify(responseData.userDetails)); // Store user details as a string

      // Clear form (optional)
      setEmail('');
      setPassword('');

      // Redirect to the dashboard after a short delay
      setTimeout(() => {
        navigate('/dashboard'); // Make sure you have a '/dashboard' route defined in your App.js
      }, 1500); // 1.5 seconds delay

    } catch (err) {
      setErrorMessage(err.message || 'Login failed. Please check your credentials or try again later.');
      console.error("Login error:", err);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="login-container">
      <div className="login-content fade-in">
        <h1 className="login-heading">Gym Owner Login</h1> {/* Changed from Member Login for clarity */}

        {errorMessage && <p className="error-message" style={{color: 'red', textAlign: 'center', marginBottom: '10px'}}>{errorMessage}</p>}
        {successMessage && <p className="success-message" style={{color: 'green', textAlign: 'center', marginBottom: '10px'}}>{successMessage}</p>}

        <form onSubmit={handleLogin} className="login-form">
          <div className="input-group">
            <FiMail className="input-icon" />
            <input
              type="email"
              placeholder="Email Address"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              required
              disabled={isLoading}
            />
          </div>

          <div className="input-group">
            <FiLock className="input-icon" />
            <input
              type="password"
              placeholder="Password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              required
              disabled={isLoading}
            />
          </div>

          <button type="submit" className="login-submit-button" disabled={isLoading}>
            {isLoading ? (
              'Logging In...' // Simple text while loading
            ) : (
              <>
                <FiLogIn className="button-icon" />
                Login
              </>
            )}
          </button>
        </form>

        <div className="login-links">
          {/* <Link to="/forgot-password">Forgot Password?</Link> Commented out if not implemented yet */}
          <p style={{ marginTop: '15px' }}>
            Don't have an account? <Link to="/register">Register Your Gym</Link>
          </p>
        </div>
      </div>
      <div className="back-link-container">
        <Link to="/" className="back-link">Back to Welcome</Link>
      </div>
    </div>
  );
}

export default LoginPage;