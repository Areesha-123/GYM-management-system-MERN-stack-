import React, { useState, useEffect, useMemo, useCallback } from 'react';
import { useDashboardContext } from './DashboardScreen'; // Adjust path if needed
import '../styles/Reports.css';
import {
    FiUser, FiUsers, FiCalendar, FiDollarSign, FiPrinter, FiLoader, FiAlertCircle,
    FiMail, FiPhone, FiBriefcase, FiCheckSquare, FiXSquare, FiActivity, FiCreditCard, 
    FiClipboard, FiTrendingUp, FiSearch, FiPlayCircle, FiX
} from 'react-icons/fi';

// Debounce hook (can be removed if not using for typing-based filtering)
function useDebounce(value, delay) {
    const [debouncedValue, setDebouncedValue] = useState(value);
    useEffect(() => {
        const handler = setTimeout(() => {
            setDebouncedValue(value);
        }, delay);
        return () => {
            clearTimeout(handler);
        };
    }, [value, delay]);
    return debouncedValue;
}

const TrainerReportSection = () => {
    const {
        currentBranchId,
        allTrainers,
        fetchBranchTrainersList,
        isFetchingBranchTrainersList,
        individualTrainerPayments,
        fetchPaymentsForSingleTrainer,
        isFetchingIndividualTrainerPayments,
        formatCurrency,
        formatDate,
        getCurrentMonthYYYYMM,
        allMembers, 
    } = useDashboardContext();

    const [selectedTrainerId, setSelectedTrainerId] = useState('');
    const [reportError, setReportError] = useState('');
    const [isLoadingReportContent, setIsLoadingReportContent] = useState(false);
    
    // State for the search input field - this is where the typed value is stored.
    const [trainerSearchInput, setTrainerSearchInput] = useState('');
    // State for the search term that was actually submitted and used for fetching.
    const [activeSearchTerm, setActiveSearchTerm] = useState('');

    // Effect to fetch trainers when active search term or branchId changes
    useEffect(() => {
        if (currentBranchId) {
            // `activeSearchTerm` is passed to the fetch function.
            // If `activeSearchTerm` contains the file content, the API call will be malformed.
            fetchBranchTrainersList(currentBranchId, activeSearchTerm, true);
        }
    }, [currentBranchId, activeSearchTerm, fetchBranchTrainersList]);

    // Effect to clear search and selection when branch changes
    useEffect(() => {
        if (currentBranchId) {
            setTrainerSearchInput(''); 
            setActiveSearchTerm('');   
            setSelectedTrainerId('');  
        }
    }, [currentBranchId]);

    const handleTrainerSearchClick = () => {
        if (currentBranchId) {
            // When search is clicked, `trainerSearchInput` (from the input field)
            // becomes the `activeSearchTerm`.
            setActiveSearchTerm(trainerSearchInput);
            setSelectedTrainerId(''); 
        }
    };
    
    const handleClearTrainerSearch = () => {
        setTrainerSearchInput('');
        setActiveSearchTerm(''); 
        setSelectedTrainerId('');
    };

    const currentBranchFilteredTrainers = useMemo(() => {
        return (currentBranchId && allTrainers[currentBranchId]?.list) ? allTrainers[currentBranchId].list : [];
    }, [allTrainers, currentBranchId]);

    const selectedTrainerDetails = useMemo(() => {
        if (!selectedTrainerId || !currentBranchFilteredTrainers) return null;
        return currentBranchFilteredTrainers.find(t => t._id === selectedTrainerId);
    }, [selectedTrainerId, currentBranchFilteredTrainers]);

    const trainerPaymentsHistory = useMemo(() => {
        if (!selectedTrainerId || !individualTrainerPayments[selectedTrainerId]) return [];
        return [...individualTrainerPayments[selectedTrainerId]].sort((a, b) => {
            const dateA = new Date(a.paymentDate).getTime();
            const dateB = new Date(b.paymentDate).getTime();
            if (dateB !== dateA) return dateB - dateA;
            const createdAtA = new Date(a.createdAt).getTime();
            const createdAtB = new Date(b.createdAt).getTime();
            return createdAtB - createdAtA;
        });
    }, [selectedTrainerId, individualTrainerPayments]);

    const handleTrainerSelect = useCallback(async (trainerId) => {
        setSelectedTrainerId(trainerId);
        setReportError('');
        if (trainerId && currentBranchId) {
            setIsLoadingReportContent(true);
            try {
                await fetchPaymentsForSingleTrainer(currentBranchId, trainerId, true);
            } catch (error) {
                console.error("Error fetching trainer payments for report:", error);
                setReportError(`Failed to load payment details for trainer: ${error.message}`);
            } finally {
                setIsLoadingReportContent(false);
            }
        }
    }, [currentBranchId, fetchPaymentsForSingleTrainer]); // Removed state setters from deps as they are stable

    // Effect to auto-select if search yields a single result
    useEffect(() => {
        if (activeSearchTerm && currentBranchFilteredTrainers.length === 1 && !selectedTrainerId) {
            handleTrainerSelect(currentBranchFilteredTrainers[0]._id);
        }
    }, [activeSearchTerm, currentBranchFilteredTrainers, selectedTrainerId, handleTrainerSelect]);

    useEffect(() => {
        if (selectedTrainerId && !currentBranchFilteredTrainers.some(t => t._id === selectedTrainerId)) {
            setSelectedTrainerId('');
        }
    }, [currentBranchFilteredTrainers, selectedTrainerId]);


    const calculateTrainerFinancials = useMemo(() => {
        if (!selectedTrainerDetails) {
            return { totalPaid: 0, pendingThisMonth: 0, expectedThisMonth: 0 };
        }
        const currentPayments = (selectedTrainerId && individualTrainerPayments[selectedTrainerId])
            ? individualTrainerPayments[selectedTrainerId]
            : [];
        const totalPaid = currentPayments.reduce((sum, p) => sum + (Number(p.amount) || 0), 0);
        const currentMonthStr = getCurrentMonthYYYYMM();
        const fixedSalary = Number(selectedTrainerDetails.salary) || 0;
        let feeBasedIncomeThisMonth = 0;
        if (Number(selectedTrainerDetails.fee) > 0 && currentBranchId && allMembers && allMembers[currentBranchId]?.initialList) {
            const membersForFeeCalc = allMembers[currentBranchId].initialList || [];
            const activeAssignedCount = membersForFeeCalc.filter(
                member => member.trainerId === selectedTrainerDetails._id && member.status === 'Active'
            ).length;
            feeBasedIncomeThisMonth = (Number(selectedTrainerDetails.fee) || 0) * activeAssignedCount;
        }
        const expectedThisMonth = fixedSalary + feeBasedIncomeThisMonth;
        const paidThisMonth = currentPayments
            .filter(p => p.paymentMonth === currentMonthStr)
            .reduce((sum, p) => sum + (Number(p.amount) || 0), 0);
        const pendingThisMonth = Math.max(0, expectedThisMonth - paidThisMonth);
        return { totalPaid, pendingThisMonth, expectedThisMonth };
    }, [selectedTrainerId, selectedTrainerDetails, individualTrainerPayments, getCurrentMonthYYYYMM, allMembers, currentBranchId]);

    const noTrainersInBranchInitially = currentBranchId && allTrainers[currentBranchId]?.initialList?.length === 0 && !isFetchingBranchTrainersList && !activeSearchTerm;

    if (noTrainersInBranchInitially) {
        return <div className="reports-placeholder">No trainers found in the current branch. You can add trainers in the 'Trainers' section.</div>;
    }

    return (
        <div className="report-type-section">
            <div className="reports-controls report-section-controls">
                 <div className="search-input-group">
                    <FiSearch className="search-input-icon" />
                    {/* This input's value is bound to trainerSearchInput */}
                    {/* Its onChange handler updates trainerSearchInput with what the user types (e.target.value) */}
                    <input
                        type="text"
                        placeholder="Search Trainer by Name, Email, ID..."
                        className="reports-search-input"
                        value={trainerSearchInput}
                        onChange={(e) => setTrainerSearchInput(e.target.value)}
                        onKeyPress={(e) => e.key === 'Enter' && handleTrainerSearchClick()}
                        disabled={isFetchingBranchTrainersList}
                    />
                    {trainerSearchInput && (
                        <button onClick={handleClearTrainerSearch} className="search-clear-button" title="Clear search">
                            <FiX />
                        </button>
                    )}
                    <button 
                        onClick={handleTrainerSearchClick} 
                        className="search-action-button"
                        disabled={isFetchingBranchTrainersList || !trainerSearchInput.trim()}
                    >
                        Search
                    </button>
                </div>
                <select
                    value={selectedTrainerId}
                    onChange={(e) => handleTrainerSelect(e.target.value)}
                    className="reports-select-filter"
                    disabled={isLoadingReportContent || isFetchingBranchTrainersList || currentBranchFilteredTrainers.length === 0}
                >
                    <option value="">-- Select Trainer --</option>
                    {currentBranchFilteredTrainers.map(trainer => (
                        <option key={trainer._id} value={trainer._id}>{trainer.name} ({trainer.specialization})</option>
                    ))}
                </select>
            </div>
            
            {isFetchingBranchTrainersList && <div className="reports-loading-container"><FiLoader className="reports-loading-spinner" /><p>Searching trainers...</p></div>}

            {!isFetchingBranchTrainersList && activeSearchTerm && currentBranchFilteredTrainers.length === 0 && (
                <div className="reports-placeholder">No trainers found matching your search "{activeSearchTerm}".</div>
            )}

            {reportError && <div className="reports-error-message"><FiAlertCircle /> {reportError}</div>}
            
            {(isLoadingReportContent || (selectedTrainerId && isFetchingIndividualTrainerPayments && !individualTrainerPayments[selectedTrainerId])) && (
                <div className="reports-loading-container"> <FiLoader className="reports-loading-spinner" /> <p>Loading trainer payment details...</p> </div>
            )}

            {!selectedTrainerId && !isLoadingReportContent && !isFetchingBranchTrainersList && (
                activeSearchTerm && currentBranchFilteredTrainers.length > 1 ? ( 
                    <div className="reports-placeholder">Select a trainer from the search results to view their report.</div>
                ) : (
                    !activeSearchTerm && currentBranchFilteredTrainers.length > 0 ? ( 
                         <div className="reports-placeholder">Select a trainer or search to view their report.</div>
                    ) : null 
                )
            )}

            {selectedTrainerId && selectedTrainerDetails && !isLoadingReportContent && !(isFetchingIndividualTrainerPayments && !individualTrainerPayments[selectedTrainerId]) && (
                <div className="report-content-details">
                    {/* Trainer details sections... (same as before) */}
                    <section className="report-section trainer-details-section">
                        <h3><FiUser /> Trainer Information</h3>
                        <div className="details-grid">
                            <p><strong>Name:</strong> {selectedTrainerDetails.name}</p>
                            <p><strong><FiMail /> Email:</strong> {selectedTrainerDetails.email}</p>
                            <p><strong><FiPhone /> Phone:</strong> {selectedTrainerDetails.phone || 'N/A'}</p>
                            <p><strong><FiBriefcase /> Specialization:</strong> {selectedTrainerDetails.specialization}</p>
                            <p><strong>Status:</strong> <span className={`status-badge status-${selectedTrainerDetails.status?.toLowerCase().replace(' ', '-')}`}>{selectedTrainerDetails.status}</span></p>
                            <p><strong><FiCalendar /> Joined:</strong> {formatDate(selectedTrainerDetails.dateOfJoining)}</p>
                            <p><strong><FiDollarSign /> Base Salary:</strong> {formatCurrency(selectedTrainerDetails.salary)} / month</p>
                            {Number(selectedTrainerDetails.fee) > 0 && <p><strong>Fee per Member:</strong> {formatCurrency(selectedTrainerDetails.fee)}</p>}
                            <p><strong>CNIC:</strong> {selectedTrainerDetails.cnic || 'N/A'}</p>
                            <p><strong>Address:</strong> {selectedTrainerDetails.address ? `${selectedTrainerDetails.address.street || ''}${selectedTrainerDetails.address.street && selectedTrainerDetails.address.city ? ', ' : ''}${selectedTrainerDetails.address.city || ''}` : 'N/A'}</p>
                        </div>
                    </section>
                    <section className="report-section financial-summary-section">
                        <h3><FiDollarSign /> Financial Summary</h3>
                        <div className="details-grid">
                            <p><strong>Expected Salary (This Month):</strong> {formatCurrency(calculateTrainerFinancials.expectedThisMonth)}</p>
                            <p><strong>Total Paid (All Time):</strong> {formatCurrency(calculateTrainerFinancials.totalPaid)}</p>
                            <p><strong>Pending (This Month - {getCurrentMonthYYYYMM()}):</strong> <span style={{color: calculateTrainerFinancials.pendingThisMonth > 0 ? '#ef4444' : '#22c55e', fontWeight: 'bold'}}>{formatCurrency(calculateTrainerFinancials.pendingThisMonth)}</span> {calculateTrainerFinancials.pendingThisMonth <= 0 && <FiCheckSquare style={{ color: '#22c55e', marginLeft: '5px', verticalAlign: 'middle'}}/>} {calculateTrainerFinancials.pendingThisMonth > 0 && <FiXSquare style={{ color: '#ef4444', marginLeft: '5px', verticalAlign: 'middle'}}/>}</p>
                        </div>
                    </section>
                    <section className="report-section payment-history-section">
                        <h3><FiCreditCard /> Payment History ({trainerPaymentsHistory.length})</h3>
                        {trainerPaymentsHistory.length > 0 ? (<div className="table-responsive"><table className="reports-table"><thead><tr><th>Payment Date</th><th>Payment Month</th><th>Amount Paid</th><th>Notes</th><th>Recorded At</th></tr></thead><tbody>{trainerPaymentsHistory.map(payment => (<tr key={payment._id}><td>{formatDate(payment.paymentDate)}</td><td>{payment.paymentMonth}</td><td>{formatCurrency(payment.amount)}</td><td className="notes-cell">{payment.notes || 'N/A'}</td><td>{formatDate(payment.createdAt, true)}</td></tr>))}</tbody></table></div>) : (<p className="reports-no-data">No payment history found for this trainer.</p>)}
                    </section>
                    <section className="report-section trainer-activity-history-section">
                        <h3><FiActivity /> Trainer Activity Log</h3>
                        {selectedTrainerDetails.history && selectedTrainerDetails.history.length > 0 ? (<div className="table-responsive"><table className="reports-table"><thead><tr><th>Date</th><th>Event</th><th>Details</th></tr></thead><tbody>{[...(selectedTrainerDetails.history || [])].sort((a,b) => new Date(b.date).getTime() - new Date(a.date).getTime()).map((event, index) => (<tr key={event._id || index}><td>{formatDate(event.date)}</td><td>{event.event}</td><td className="notes-cell">{event.details || 'N/A'}</td></tr>))}</tbody></table></div>) : (<p className="reports-no-data">No activity history found for this trainer.</p>)}
                    </section>
                </div>
            )}
        </div>
    );
};

// MemberReportSection remains the same as in "Reports_jsx_autoselect_single_search_result"
// ... (MemberReportSection code) ...
const MemberReportSection = () => {
    const {
        currentBranchId,
        allMembers,
        fetchBranchMembers,
        isFetchingMembers,
        formatCurrency,
        formatDate,
        getPackDetails,
    } = useDashboardContext();

    const [selectedMemberId, setSelectedMemberId] = useState('');
    const [memberSearchInput, setMemberSearchInput] = useState('');
    const [activeSearchTerm, setActiveSearchTerm] = useState('');
    const [reportError, setReportError] = useState(''); // Added for consistency
    const [isLoadingReportContent, setIsLoadingReportContent] = useState(false); // Added for consistency


    useEffect(() => {
        if (currentBranchId) {
            fetchBranchMembers(currentBranchId, activeSearchTerm, true);
        }
    }, [currentBranchId, activeSearchTerm, fetchBranchMembers]);

     useEffect(() => {
        if (currentBranchId) {
            setMemberSearchInput(''); 
            setActiveSearchTerm('');   
            setSelectedMemberId('');  
        }
    }, [currentBranchId]);

    const handleMemberSearchClick = () => {
        if (currentBranchId) {
            setActiveSearchTerm(memberSearchInput);
            setSelectedMemberId(''); 
        }
    };
    
    const handleClearMemberSearch = () => {
        setMemberSearchInput('');
        setActiveSearchTerm('');
        setSelectedMemberId('');
    };

    const currentBranchFilteredMembers = useMemo(() => {
        return (currentBranchId && allMembers[currentBranchId]?.list) ? allMembers[currentBranchId].list : [];
    }, [allMembers, currentBranchId]);

    const selectedMemberDetails = useMemo(() => {
        if (!selectedMemberId || !currentBranchFilteredMembers) return null;
        return currentBranchFilteredMembers.find(m => m._id === selectedMemberId);
    }, [selectedMemberId, currentBranchFilteredMembers]);
    
    const handleMemberSelect = useCallback((memberId) => { // No async needed if just setting state
        setSelectedMemberId(memberId);
        setReportError(''); // Clear previous errors
        // Data for member details is already part of selectedMemberDetails via allMembers context
        // No separate fetch needed here unless member details are extremely large and fetched on demand
    }, [setSelectedMemberId, setReportError]);


    useEffect(() => {
        if (activeSearchTerm && currentBranchFilteredMembers.length === 1 && !selectedMemberId) {
            handleMemberSelect(currentBranchFilteredMembers[0]._id);
        }
    }, [activeSearchTerm, currentBranchFilteredMembers, selectedMemberId, handleMemberSelect]);
    
    useEffect(() => {
        if (selectedMemberId && !currentBranchFilteredMembers.some(m => m._id === selectedMemberId)) {
            setSelectedMemberId('');
        }
    }, [currentBranchFilteredMembers, selectedMemberId]);
    

    const memberPaymentHistory = useMemo(() => {
        if (!selectedMemberDetails || !Array.isArray(selectedMemberDetails.history)) return [];
        return selectedMemberDetails.history
            .filter(h => h.event === 'Payment' || h.event === 'Renewal')
            .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
    }, [selectedMemberDetails]);
    
    const memberGeneralHistory = useMemo(() => {
        if (!selectedMemberDetails || !Array.isArray(selectedMemberDetails.history)) return [];
        return selectedMemberDetails.history
            .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
    }, [selectedMemberDetails]);

    
    const noMembersInBranchInitially = currentBranchId && allMembers[currentBranchId]?.initialList?.length === 0 && !isFetchingMembers && !activeSearchTerm;

    if (noMembersInBranchInitially) {
        return <div className="reports-placeholder">No members found in the current branch. You can add members in the 'Members' section.</div>;
    }
    
    return (
        <div className="report-type-section">
            <div className="reports-controls report-section-controls">
                <div className="search-input-group">
                    <FiSearch className="search-input-icon" />
                    <input
                        type="text"
                        placeholder="Search Member by Name, Email, ID, Phone..."
                        className="reports-search-input"
                        value={memberSearchInput}
                        onChange={(e) => setMemberSearchInput(e.target.value)}
                        onKeyPress={(e) => e.key === 'Enter' && handleMemberSearchClick()}
                        disabled={isFetchingMembers}
                    />
                    {memberSearchInput && (
                        <button onClick={handleClearMemberSearch} className="search-clear-button" title="Clear search">
                            <FiX />
                        </button>
                    )}
                    <button 
                        onClick={handleMemberSearchClick} 
                        className="search-action-button"
                        disabled={isFetchingMembers || !memberSearchInput.trim()}
                    >
                        Search
                    </button>
                </div>
                <select
                    value={selectedMemberId}
                    onChange={(e) => handleMemberSelect(e.target.value)}
                    className="reports-select-filter"
                    disabled={isFetchingMembers || currentBranchFilteredMembers.length === 0}
                >
                    <option value="">-- Select Member --</option>
                    {currentBranchFilteredMembers.map(member => (
                        <option key={member._id} value={member._id}>{member.name} ({member.displayMemberId})</option>
                    ))}
                </select>
            </div>

            {isFetchingMembers && <div className="reports-loading-container"><FiLoader className="reports-loading-spinner" /><p>Searching members...</p></div>}
            
            {!isFetchingMembers && activeSearchTerm && currentBranchFilteredMembers.length === 0 && (
                <div className="reports-placeholder">No members found matching your search "{activeSearchTerm}".</div>
            )}
            
            {reportError && <div className="reports-error-message"><FiAlertCircle /> {reportError}</div>}


            {!selectedMemberId && !isLoadingReportContent && !isFetchingMembers && (
                 activeSearchTerm && currentBranchFilteredMembers.length > 1 ? ( 
                    <div className="reports-placeholder">Select a member from the search results to view their report.</div>
                ) : (
                    !activeSearchTerm && currentBranchFilteredMembers.length > 0 ? ( 
                         <div className="reports-placeholder">Select a member or search to view their report.</div>
                    ) : null 
                )
            )}


            {selectedMemberId && selectedMemberDetails && !isFetchingMembers && (
                <div className="report-content-details">
                    {/* Member details sections... (same as before) */}
                    <section className="report-section member-details-section">
                        <h3><FiUser /> Member Information</h3>
                        <div className="details-grid">
                            <p><strong>Name:</strong> {selectedMemberDetails.name}</p>
                            <p><strong>Member ID:</strong> {selectedMemberDetails.displayMemberId}</p>
                            <p><strong><FiMail /> Email:</strong> {selectedMemberDetails.email || 'N/A'}</p>
                            <p><strong><FiPhone /> Phone:</strong> {selectedMemberDetails.phone}</p>
                            <p><strong>Status:</strong> <span className={`status-badge status-${selectedMemberDetails.status?.toLowerCase().replace(' ', '-')}`}>{selectedMemberDetails.status}</span></p>
                            <p><strong><FiCalendar /> Joined:</strong> {formatDate(selectedMemberDetails.joiningDate)}</p>
                            <p><strong><FiClipboard /> Plan:</strong> {getPackDetails(selectedMemberDetails.currentPlanId)?.name || 'N/A'}</p>
                            <p><strong><FiCalendar /> Plan Expiry:</strong> {formatDate(selectedMemberDetails.paymentDueDate)}</p>
                               <p><strong>Gender:</strong> {selectedMemberDetails.gender || 'N/A'}</p>
                            <p><strong>Goal:</strong> {selectedMemberDetails.goal || 'N/A'}</p>
                        </div>
                    </section>

                    <section className="report-section member-financial-summary-section">
                        <h3><FiTrendingUp /> Financial Summary</h3>
                        <div className="details-grid">
                           <p><strong>Total Amount Paid:</strong> {formatCurrency(memberPaymentHistory.reduce((sum, p) => sum + (Number(p.amountPaid) || 0), 0))}</p>
                           <p><strong>Last Payment Date:</strong> {memberPaymentHistory.length > 0 ? formatDate(memberPaymentHistory[0].date) : 'N/A'}</p>
                           <p><strong>Last Payment Amount:</strong> {memberPaymentHistory.length > 0 ? formatCurrency(memberPaymentHistory[0].amountPaid) : 'N/A'}</p>
                        </div>
                    </section>

                    <section className="report-section member-payment-history-section">
                        <h3><FiCreditCard /> Payment History ({memberPaymentHistory.length})</h3>
                        {memberPaymentHistory.length > 0 ? (
                            <div className="table-responsive">
                                <table className="reports-table">
                                    <thead>
                                        <tr>
                                            <th>Payment Date</th>
                                            <th>Amount Paid</th>
                                            <th>Plan</th>
                                            <th>Details/Notes</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        {memberPaymentHistory.map((item, index) => (
                                            <tr key={item._id || index}>
                                                <td>{formatDate(item.date)}</td>
                                                <td>{formatCurrency(item.amountPaid)}</td>
                                                <td>{getPackDetails(item.planId)?.name || 'N/A'}</td>
                                                <td className="notes-cell">{item.details || item.event || 'N/A'}</td>
                                            </tr>
                                        ))}
                                    </tbody>
                                </table>
                            </div>
                        ) : (
                            <p className="reports-no-data">No payment history found for this member.</p>
                        )}
                    </section>
                    <section className="report-section member-activity-history-section">
                        <h3><FiActivity /> Member Activity Log</h3>
                        {memberGeneralHistory.length > 0 ? (
                             <div className="table-responsive">
                                <table className="reports-table">
                                    <thead>
                                        <tr>
                                            <th>Date</th>
                                            <th>Event</th>
                                            <th>Details</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        {memberGeneralHistory.map((event, index) => (
                                            <tr key={event._id || index}>
                                                <td>{formatDate(event.date)}</td>
                                                <td>{event.event}</td>
                                                <td className="notes-cell">{event.details || 'N/A'}</td>
                                            </tr>
                                        ))}
                                    </tbody>
                                </table>
                            </div>
                        ) : (
                            <p className="reports-no-data">No activity history found for this member.</p>
                        )}
                    </section>
                </div>
            )}
        </div>
    );
};


const ReportsPage = () => {
    const { currentBranchId, currentBranchData } = useDashboardContext();
    const [reportType, setReportType] = useState('trainer'); 

    const printReport = () => {
        window.print();
    };

    if (!currentBranchId) {
        return (
            <div className="reports-container">
                <div className="reports-header">
                    <h2>Reports</h2>
                </div>
                <p className="reports-placeholder">Please select a branch first from the dashboard header to generate reports.</p>
            </div>
        );
    }

    return (
        <div className="reports-container">
            <header className="reports-header">
                <h2>
                    {reportType === 'trainer' ? 'Trainer Report' : 'Member Report'}
                    {currentBranchData && ` - ${currentBranchData.name}`}
                </h2>
                <div className="reports-controls main-controls">
                       <div className="report-type-switcher">
                            <button 
                                onClick={() => setReportType('trainer')} 
                                className={reportType === 'trainer' ? 'active' : ''}
                            >
                                <FiUser /> Trainer Reports
                            </button>
                            <button 
                                onClick={() => setReportType('member')} 
                                className={reportType === 'member' ? 'active' : ''}
                            >
                                <FiUsers /> Member Reports
                            </button>
                        </div>
                    <button onClick={printReport} className="reports-print-button">
                        <FiPrinter /> Print Current Report
                    </button>
                </div>
            </header>
            {reportType === 'trainer' && <TrainerReportSection />}
            {reportType === 'member' && <MemberReportSection />}
        </div>
    );
};

export default ReportsPage;
